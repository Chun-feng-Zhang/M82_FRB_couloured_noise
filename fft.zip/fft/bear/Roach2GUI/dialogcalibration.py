# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'dialogcalibration.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialogcalibration(object):
    def setupUi(self, Dialogcalibration):
        Dialogcalibration.setObjectName(_fromUtf8("Dialogcalibration"))
        Dialogcalibration.resize(400, 300)
        self.verticalLayout = QtGui.QVBoxLayout(Dialogcalibration)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.groupBoxMMCM = QtGui.QGroupBox(Dialogcalibration)
        self.groupBoxMMCM.setObjectName(_fromUtf8("groupBoxMMCM"))
        self.gridLayout = QtGui.QGridLayout(self.groupBoxMMCM)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.labelMMCMPhase = QtGui.QLabel(self.groupBoxMMCM)
        self.labelMMCMPhase.setObjectName(_fromUtf8("labelMMCMPhase"))
        self.gridLayout.addWidget(self.labelMMCMPhase, 0, 0, 1, 1)
        self.lineEditMMCMPhase = QtGui.QLineEdit(self.groupBoxMMCM)
        self.lineEditMMCMPhase.setObjectName(_fromUtf8("lineEditMMCMPhase"))
        self.gridLayout.addWidget(self.lineEditMMCMPhase, 0, 1, 1, 1)
        self.radioButtonTestMode = QtGui.QRadioButton(self.groupBoxMMCM)
        self.radioButtonTestMode.setObjectName(_fromUtf8("radioButtonTestMode"))
        self.gridLayout.addWidget(self.radioButtonTestMode, 0, 2, 1, 1)
        self.verticalLayout.addWidget(self.groupBoxMMCM)
        self.groupBoxADC5g = QtGui.QGroupBox(Dialogcalibration)
        self.groupBoxADC5g.setObjectName(_fromUtf8("groupBoxADC5g"))
        self.gridLayout_2 = QtGui.QGridLayout(self.groupBoxADC5g)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.tableViewADC5g = QtGui.QTableView(self.groupBoxADC5g)
        self.tableViewADC5g.setObjectName(_fromUtf8("tableViewADC5g"))
        self.gridLayout_2.addWidget(self.tableViewADC5g, 0, 0, 1, 1)
        self.verticalLayout.addWidget(self.groupBoxADC5g)
        self.buttonBoxCalibration = QtGui.QDialogButtonBox(Dialogcalibration)
        self.buttonBoxCalibration.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBoxCalibration.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.buttonBoxCalibration.setObjectName(_fromUtf8("buttonBoxCalibration"))
        self.verticalLayout.addWidget(self.buttonBoxCalibration)

        self.retranslateUi(Dialogcalibration)
        QtCore.QObject.connect(self.buttonBoxCalibration, QtCore.SIGNAL(_fromUtf8("accepted()")), Dialogcalibration.accept)
        QtCore.QObject.connect(self.buttonBoxCalibration, QtCore.SIGNAL(_fromUtf8("rejected()")), Dialogcalibration.reject)
        QtCore.QMetaObject.connectSlotsByName(Dialogcalibration)

    def retranslateUi(self, Dialogcalibration):
        Dialogcalibration.setWindowTitle(_translate("Dialogcalibration", "Dialog", None))
        self.groupBoxMMCM.setTitle(_translate("Dialogcalibration", "MMCM Calibration", None))
        self.labelMMCMPhase.setText(_translate("Dialogcalibration", "MMCM Phase", None))
        self.radioButtonTestMode.setText(_translate("Dialogcalibration", "Test &Mode", None))
        self.groupBoxADC5g.setTitle(_translate("Dialogcalibration", "ADC Calibration", None))

