# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'dialogload.ui'
#
# Created by: PyQt4 UI code generator 4.12.1
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialogload(object):
    def setupUi(self, Dialogload):
        Dialogload.setObjectName(_fromUtf8("Dialogload"))
        Dialogload.resize(292, 373)
        self.verticalLayout = QtGui.QVBoxLayout(Dialogload)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.labelIp = QtGui.QLabel(Dialogload)
        self.labelIp.setObjectName(_fromUtf8("labelIp"))
        self.horizontalLayout.addWidget(self.labelIp)
        self.lineEditIp = QtGui.QLineEdit(Dialogload)
        self.lineEditIp.setObjectName(_fromUtf8("lineEditIp"))
        self.horizontalLayout.addWidget(self.lineEditIp)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.labelPort = QtGui.QLabel(Dialogload)
        self.labelPort.setObjectName(_fromUtf8("labelPort"))
        self.horizontalLayout_2.addWidget(self.labelPort)
        self.lineEditPort = QtGui.QLineEdit(Dialogload)
        self.lineEditPort.setObjectName(_fromUtf8("lineEditPort"))
        self.horizontalLayout_2.addWidget(self.lineEditPort)
        self.verticalLayout.addLayout(self.horizontalLayout_2)
        self.horizontalLayout_3 = QtGui.QHBoxLayout()
        self.horizontalLayout_3.setObjectName(_fromUtf8("horizontalLayout_3"))
        self.labelFlow = QtGui.QLabel(Dialogload)
        self.labelFlow.setObjectName(_fromUtf8("labelFlow"))
        self.horizontalLayout_3.addWidget(self.labelFlow)
        self.lineEditFlow = QtGui.QLineEdit(Dialogload)
        self.lineEditFlow.setObjectName(_fromUtf8("lineEditFlow"))
        self.horizontalLayout_3.addWidget(self.lineEditFlow)
        self.verticalLayout.addLayout(self.horizontalLayout_3)
        self.horizontalLayout_4 = QtGui.QHBoxLayout()
        self.horizontalLayout_4.setObjectName(_fromUtf8("horizontalLayout_4"))
        self.labelFhigh = QtGui.QLabel(Dialogload)
        self.labelFhigh.setObjectName(_fromUtf8("labelFhigh"))
        self.horizontalLayout_4.addWidget(self.labelFhigh)
        self.lineEditFhigh = QtGui.QLineEdit(Dialogload)
        self.lineEditFhigh.setObjectName(_fromUtf8("lineEditFhigh"))
        self.horizontalLayout_4.addWidget(self.lineEditFhigh)
        self.verticalLayout.addLayout(self.horizontalLayout_4)
        self.horizontalLayout_5 = QtGui.QHBoxLayout()
        self.horizontalLayout_5.setObjectName(_fromUtf8("horizontalLayout_5"))
        self.labelAcc = QtGui.QLabel(Dialogload)
        self.labelAcc.setObjectName(_fromUtf8("labelAcc"))
        self.horizontalLayout_5.addWidget(self.labelAcc)
        self.lineEditAcc = QtGui.QLineEdit(Dialogload)
        self.lineEditAcc.setObjectName(_fromUtf8("lineEditAcc"))
        self.horizontalLayout_5.addWidget(self.lineEditAcc)
        self.verticalLayout.addLayout(self.horizontalLayout_5)
        self.horizontalLayout_6 = QtGui.QHBoxLayout()
        self.horizontalLayout_6.setObjectName(_fromUtf8("horizontalLayout_6"))
        self.labelGain = QtGui.QLabel(Dialogload)
        self.labelGain.setObjectName(_fromUtf8("labelGain"))
        self.horizontalLayout_6.addWidget(self.labelGain)
        self.lineEditGain = QtGui.QLineEdit(Dialogload)
        self.lineEditGain.setObjectName(_fromUtf8("lineEditGain"))
        self.horizontalLayout_6.addWidget(self.lineEditGain)
        self.verticalLayout.addLayout(self.horizontalLayout_6)
        self.buttonBoxLoad = QtGui.QDialogButtonBox(Dialogload)
        self.buttonBoxLoad.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBoxLoad.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.buttonBoxLoad.setObjectName(_fromUtf8("buttonBoxLoad"))
        self.verticalLayout.addWidget(self.buttonBoxLoad)

        self.retranslateUi(Dialogload)
        QtCore.QObject.connect(self.buttonBoxLoad, QtCore.SIGNAL(_fromUtf8("accepted()")), Dialogload.accept)
        QtCore.QObject.connect(self.buttonBoxLoad, QtCore.SIGNAL(_fromUtf8("rejected()")), Dialogload.reject)
        QtCore.QMetaObject.connectSlotsByName(Dialogload)

    def retranslateUi(self, Dialogload):
        Dialogload.setWindowTitle(_translate("Dialogload", "Load Configure", None))
        self.labelIp.setText(_translate("Dialogload", "dest_ip", None))
        self.labelPort.setText(_translate("Dialogload", "dest_port", None))
        self.labelFlow.setText(_translate("Dialogload", "flow", None))
        self.labelFhigh.setText(_translate("Dialogload", "fhigh", None))
        self.labelAcc.setText(_translate("Dialogload", "acc_len", None))
        self.labelGain.setText(_translate("Dialogload", "gain", None))

