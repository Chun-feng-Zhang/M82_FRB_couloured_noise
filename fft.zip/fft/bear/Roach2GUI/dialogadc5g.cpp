#include "dialogadc5g.h"
#include "ui_dialogadc5g.h"

Dialogadc5g::Dialogadc5g(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialogadc5g)
{
    ui->setupUi(this);
}

Dialogadc5g::~Dialogadc5g()
{
    delete ui;
}
