#!/usr/bin/env python

import casperfpga
from corr import katcp_wrapper
import adc5g
import time,socket,struct

import matplotlib
matplotlib.use("QT4Agg")
from matplotlib.backends.backend_qt4agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt4agg import NavigationToolbar2QT as NavigationToolbar
import matplotlib.pyplot as plt
import numpy as np

import sys
import os
import copy
from PyQt4 import QtGui, QtCore, QtXml
from roach2ui import Ui_MainWindow
from dialogcalibration import Ui_Dialogcalibration
from dialogprog import Ui_Dialogprog
from dialogload import Ui_Dialogload

SettingPath = os.path.expanduser('~') + '/.config/bear/roach2'


def mkdir(path):
    path = os.path.abspath(path)
    try:
        tmp = []
        while not os.path.exists(path):
            tmp.append(path)
            path = os.path.split(path)[0]
        while len(tmp) > 0:
            os.mkdir(tmp.pop())
        return True
    except:
        return False


class xmlsettings():

    """
    This class is used for settings by xml file
    """

    def __init__(self, fname):
        self.fname = os.path.abspath(fname)
        mkdir(os.path.split(self.fname)[0])
        self.__settings = {}

    def get(self, key):
        try:
            return self.__settings[key]
        except:
            print 'No parameter', key

    def set(self, key, value):
        self.__settings[key] = value

    def update(self, settings):
        self.__settings = settings

    def readXML(self):
        try:
            xmlfile = QtCore.QFile(self.fname)
            if not xmlfile.open(QtCore.QIODevice.ReadOnly):
                return False
            doc = QtXml.QDomDocument()
            doc.setContent(xmlfile)
            xmlfile.close()
            root = doc.documentElement()
            node = root.firstChild()
            while not node.isNull():
                element = node.toElement()
                self.set(str(element.tagName()), str(element.text()))
                node = node.nextSibling()
            return True
        except:
            return False

    def writeXML(self):
        try:
            xmlfile = QtCore.QFile(self.fname)
            if not xmlfile.open(QtCore.QIODevice.WriteOnly | QtCore.QIODevice.Truncate):
                return False
            out = QtCore.QTextStream(xmlfile)
            doc = QtXml.QDomDocument()
            instruction = doc.createProcessingInstruction(
                'xml', 'version = \'1.0\' encoding=\'UTF-8\'')
            doc.appendChild(instruction)
            root = doc.createElement('settings')
            try:
                for key in self.__settings.keys():
                    element = doc.createElement(key)
                    text = doc.createTextNode(self.get(key))
                    element.appendChild(text)
                    root.appendChild(element)
            except:
                pass
            doc.appendChild(root)
            doc.save(out, 4)
            xmlfile.close()
            return True
        except:
            print 'Failed to write XML file!'
            return False


class dialogprog(QtGui.QDialog):

    def __init__(self):
        super(dialogprog, self).__init__()
        self.ui = Ui_Dialogprog()
        self.ui.setupUi(self)
        self.dlload = dialogload()
        self.figure = plt.figure()
        self.canvas = FigureCanvas(self.figure)
        self.toolbarPlot = NavigationToolbar(self.canvas, self)
        self.ui.verticalLayoutScreen.addWidget(self.canvas)
        self.ui.verticalLayoutScreen.addWidget(self.toolbarPlot)
        # connections
        self.connect(self.ui.pushButtonConnect,
                     QtCore.SIGNAL('clicked()'), self.onpbConnectClicked)
        self.connect(
            self.ui.comboBoxRegisters, QtCore.SIGNAL(
                'currentIndexChanged(const QString&)'),
                     self, QtCore.SLOT('oncbRegistersChanged(const QString&)'))
        self.connect(self.ui.lineEditRegisters, QtCore.SIGNAL(
            'returnPressed()'), self.onleRegistersRp)
        self.connect(self.ui.toolButtonFpg,
                     QtCore.SIGNAL('clicked()'), self.ontbFpgClicked)
        self.connect(self.ui.pushButtonFpg,
                     QtCore.SIGNAL('clicked()'), self.onpbFpgClicked)
        self.connect(self.ui.pushButtonBof,
                     QtCore.SIGNAL('clicked()'), self.onpbBofClicked)
        self.connect(self.ui.pushButtonLoad,
                     QtCore.SIGNAL('clicked()'), self.onpbLoadClicked)
        self.connect(self.ui.pushButtonFlush, QtCore.SIGNAL('clicked()'), self.onpbFlushClicked)
        self.connect(self.ui.pushButtonStart, QtCore.SIGNAL('clicked()'), self.onpbStartClicked)
        self.connect(self.ui.pushButtonStop, QtCore.SIGNAL('clicked()'), self.onpbStopClicked)
        self.connect(self.ui.pushButtonReceive, QtCore.SIGNAL('clicked()'), self.onpbReceiveClicked)
        self.connect(
            self.ui.buttonBoxProg, QtCore.SIGNAL('accepted()'), self.onbbProgAccepted)
        self.connect(self.ui.buttonBoxProg, QtCore.SIGNAL('rejected()'), self.onbbProgRejected)
        self.connect(self.dlload.ui.buttonBoxLoad, QtCore.SIGNAL('accepted()'), self.onbbLoadAccepted)

        settings = xmlsettings(SettingPath)
        if settings.readXML():
            try:
                self.ui.lineEditIP.setText(settings.get('ip'))
                self.ui.lineEditPort.setText(settings.get('port'))
                self.ui.lineEditFpg.setText(settings.get('fpg'))
            except:
                pass

    def exproc(self, e):
        etype = repr(e).split('(')[0]
        emessage = e.message
        QtGui.QMessageBox.question(
            self, etype, emessage, QtGui.QMessageBox.Yes)
#        self.ui.statusBar.showMessage(emessage)

    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_Enter or event.key() == QtCore.Qt.Key_Return:
            return
        QtGui.QDialog.keyPressEvent(event)

    def onpbReceiveClicked(self):
        if self.ui.pushButtonReceive.isChecked():
            try:
                #set up socket
                self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                settings = xmlsettings(SettingPath)
		settings.readXML()
                host=(settings.get('dest_ip'), int(settings.get('dest_port')))
                self.socket.bind(host)
                self.nifs = 4
                self.nchans = int(settings.get('fhigh'))-int(settings.get('flow'))+1
                self.frame = self.nifs*self.nchans+8
                self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, self.frame)
		self.socket.settimeout(5)
                #start timer
                self.m_timerReceive = self.startTimer(1000)
            except Exception, e:
                self.exproc(e)
        else:
            try:
                self.killTimer(self.m_timerReceive)
            except Exception, e:
                self.exproc(e)

    def closeEvent(self, event):
        try:
            self.killTimer(self.m_timerReceive)
        except:
            pass
        event.accept()

    def timerEvent(self, event):
        if event.timerId() == self.m_timerReceive:
            self.ReceiveUdp()

    def ReceiveUdp(self):
        try:
            data, addr=self.socket.recvfrom(self.frame)
            self.figure.clf()
            for i in range(self.nifs):
                dat = data[self.nchans*i:self.nchans*(i+1)]
                da=struct.unpack('>'+str(self.nchans)+'b',dat)
		da = np.array(da[1:])
                ax0 = self.figure.add_subplot(4,1,1+i)
                ax0.plot(da)
                text = 'Max:'+str(da.max())+'\n'+'Min:'+str(da.min())+'\n'+'Mean:'+str(da.mean())+'\n'+'Std:'+str(da.std())
                ax0.annotate(text, xy=(0.9,0.1),xycoords='axes fraction',fontsize='small')
            self.canvas.draw()
        except Exception, e:
            self.exproc(e)
            self.killTimer(self.m_timerReceive)

    def onpbFlushClicked(self):
        try:
            registers = self.fpga.registers.names()
            #write registers
            if 'one_GbE_tx_rst' in registers:
                self.fpga.write_int('one_GbE_tx_rst', 1)
                time.sleep(0.1)
                self.fpga.write_int('one_GbE_tx_rst', 0)
        except Exception, e:
            self.exproc(e)

    def onpbStartClicked(self):
        try:
            registers = self.fpga.registers.names()
            #write registers
            if 'one_GbE_tx_start' in registers:
                self.fpga.write_int('one_GbE_tx_start', 1)
        except Exception, e:
            self.exproc(e)

    def onpbStopClicked(self):
        try:
            registers = self.fpga.registers.names()
            #write registers
            if 'one_GbE_tx_start' in registers:
                self.fpga.write_int('one_GbE_tx_start', 0)
        except Exception, e:
            self.exproc(e)

    def onbbLoadAccepted(self):
        try:
            IPlist = self.dlload.ui.lineEditIp.text().split('.')
            IPlist = [int(i) for i in IPlist]
            IP = IPlist[0]*2**24+IPlist[1]*2**16+IPlist[2]*2**8+IPlist[3]
            registers = self.fpga.registers.names()
            #write registers
            if 'one_GbE_dest_ip' in registers:
                self.fpga.write_int('one_GbE_dest_ip', IP)
            if 'one_GbE_dest_port' in registers:
                self.fpga.write_int('one_GbE_dest_port', eval(str(self.dlload.ui.lineEditPort.text())))
            if 'one_GbE_flow' in registers:
                self.fpga.write_int('one_GbE_flow', eval(str(self.dlload.ui.lineEditFlow.text())))
            if 'one_GbE_fhigh' in registers:
                self.fpga.write_int('one_GbE_fhigh', eval(str(self.dlload.ui.lineEditFhigh.text())))
            if 'acc_len' in registers:
                self.fpga.write_int('acc_len', eval(str(self.dlload.ui.lineEditAcc.text())))
            if 'gain' in registers:
                self.fpga.write_int('gain', eval(str(self.dlload.ui.lineEditGain.text())))

            value = self.fpga.read_int(str(self.ui.comboBoxRegisters.currentText()))
            self.ui.lineEditRegisters.setText(str(value))
        except Exception, e:
            self.exproc(e)

    def onbbProgRejected(self):
        try:
            self.killTimer(self.m_timerReceive)
        except:
            pass

    def onbbProgAccepted(self):
        try:
            self.killTimer(self.m_timerReceive)
        except:
            pass
        try:
            settings = xmlsettings(SettingPath)
            settings.readXML()
            settings.set('ip', str(self.ui.lineEditIP.text()))
            settings.set('port', str(self.ui.lineEditPort.text()))
            settings.set('fpg', str(self.ui.lineEditFpg.text()))
            settings.writeXML()
        except:
            pass

    def onpbBofClicked(self):
        try:
            if self.fpgacorr.is_connected():
                bof = self.ui.comboBoxBof.currentText()
                self.fpgacorr.progdev(str(bof))
            else:
                raise Exception('Can not connect to roach2!')
            if self.fpga.is_running():
#                self.ui.statusBar.showMessage('Programed!')
		QtGui.QMessageBox.question(self, 'Information', 'Program Sucessfully!', QtGui.QMessageBox.Yes)
                self.fpga.get_system_information()
                registers = self.fpga.registers.names()
                self.ui.comboBoxRegisters.clear()
                self.ui.comboBoxRegisters.addItems(registers)
            else:
                raise Exception('fpga is not programed!')
        except Exception, e:
            self.exproc(e)

    def onpbFpgClicked(self):
        try:
            fpg = self.ui.lineEditFpg.text()
            self.fpga.upload_to_ram_and_program(str(fpg))
            if self.fpga.is_running():
#                self.ui.statusBar.showMessage('Programed!')
		QtGui.QMessageBox.question(self, 'Information', 'Program Sucessfully!', QtGui.QMessageBox.Yes)
                self.fpga.get_system_information()
                registers = self.fpga.registers.names()
                self.ui.comboBoxRegisters.clear()
                self.ui.comboBoxRegisters.addItems(registers)
            else:
                raise Exception('fpga is not programed!')
        except Exception, e:
            self.exproc(e)

    def ontbFpgClicked(self):
        fpg = QtGui.QFileDialog.getOpenFileName(
            self, str('Open File'), os.path.expanduser('~'), str('(*.fpg)'))
        if fpg != '':
            self.ui.lineEditFpg.setText(fpg)

    def onleRegistersRp(self):
        try:
            name = str(self.ui.comboBoxRegisters.currentText())
            value = eval(str(self.ui.lineEditRegisters.text()))
            self.fpga.write_int(name, value)
            value2 = self.fpga.read_int(name)
            # if value2 != value:
                # raise Exception('Register is not set correctly!')
#            self.ui.statusBar.showMessage(name + '=' + str(value2))
        except Exception, e:
            self.exproc(e)

    @QtCore.pyqtSlot('const QString&')
    def oncbRegistersChanged(self, reg):
        name = str(reg)
        try:
            value = self.fpga.read_int(name)
            self.ui.lineEditRegisters.setText(str(value))
        except:
            pass

    def onpbConnectClicked(self):
        self.ip = self.ui.lineEditIP.text()
        self.port = self.ui.lineEditPort.text()
        try:
            try:
                self.fpga.stop()
                self.fpgacorr.stop()
            except:
                pass
            self.fpga = casperfpga.katcp_fpga.KatcpFpga(
                str(self.ip), str(self.port))
            self.fpga.wait_connected()
            self.fpgacorr = katcp_wrapper.FpgaClient(
                str(self.ip), str(self.port))
            self.fpgacorr.wait_connected()
            if self.fpga.is_connected():
#                self.ui.statusBar.showMessage('connect!')
                bofs = self.fpga.listbof()
                self.ui.comboBoxBof.clear()
                self.ui.comboBoxBof.addItems(bofs)
            else:
                raise Exception('Can not connect to roach2!')
            if self.fpga.is_running():
                self.fpga.get_system_information()
                registers = self.fpga.registers.names()
                self.ui.comboBoxRegisters.clear()
                self.ui.comboBoxRegisters.addItems(registers)
            else:
                pass
#                self.ui.statusBar.showMessage(
#                    'Warning: fpga is not programed!')
        except Exception, e:
            self.exproc(e)

    def onpbLoadClicked(self):
        self.dlload.exec_()


class dialogload(QtGui.QDialog):

    def __init__(self):
        super(dialogload, self).__init__()
        self.ui = Ui_Dialogload()
        self.ui.setupUi(self)
        settings = xmlsettings(SettingPath)
        settings.readXML()
        try:
            self.ui.lineEditIp.setText(settings.get('dest_ip'))
            self.ui.lineEditPort.setText(settings.get('dest_port'))
            self.ui.lineEditFlow.setText(settings.get('flow'))
            self.ui.lineEditFhigh.setText(settings.get('fhigh'))
            self.ui.lineEditAcc.setText(settings.get('acc_len'))
            self.ui.lineEditGain.setText(settings.get('gain'))
        except:
            pass
    #connections
        self.connect(self.ui.buttonBoxLoad, QtCore.SIGNAL('accepted()'), self.onbbLoadAccepted)

    def onbbLoadAccepted(self):
        settings = xmlsettings(SettingPath)
        settings.readXML()
        try:
            settings.set('dest_ip', str(self.ui.lineEditIp.text()))
            settings.set('dest_port', str(self.ui.lineEditPort.text()))
            settings.set('flow', str(self.ui.lineEditFlow.text()))
            settings.set('fhigh', str(self.ui.lineEditFhigh.text()))
            settings.set('acc_len', str(self.ui.lineEditAcc.text()))
            settings.set('gain', str(self.ui.lineEditGain.text()))
        except:
            pass
        settings.writeXML()

class dialogcalibration(QtGui.QDialog):

    def __init__(self, fpga):
        super(dialogcalibration, self).__init__()
        self.ui = Ui_Dialogcalibration()
        self.ui.setupUi(self)
        self.ui.radioButtonTestMode.setChecked(True)
        self.fpga = fpga
        self.tableModelADC5g = tableModel((3, 4))
        self.settings = xmlsettings(SettingPath)
        self.settings.readXML()
        # set tableModelADC5g headerData
        for section, value in enumerate(['core1', 'core2', 'core3', 'core4']):
            self.tableModelADC5g.setheader(section, value, 0)
        for section, value in enumerate(['offset', 'gain', 'phase']):
            self.tableModelADC5g.setheader(section, value, 1)

        # set tableModelADC5g data
        try:
            for row in range(3):
                for column in range(4):
                    reg = self.settings.get(
                        self.tableModelADC5g.getheader(row, 1) + str(column + 1))
                    self.tableModelADC5g.set(row, column, reg)
            self.ui.lineEditMMCMPhase.setText(self.settings.get('mmcm'))
        except:
            pass
        self.ui.tableViewADC5g.setModel(self.tableModelADC5g)
        # connects
        self.connect(
            self.tableModelADC5g, QtCore.SIGNAL(
                'itemChanged(QStandardItem * )'),
                     self, QtCore.SLOT('ontmADC5gChanged(QStandardItem *)'))
        self.connect(self.ui.buttonBoxCalibration, QtCore.SIGNAL(
            'accepted()'), self.onbbCalibrationaAccepted)
        self.connect(self.ui.buttonBoxCalibration, QtCore.SIGNAL(
            'rejected()'), self.onbbCalibrationaRejected)

    def closeEvent(self, event):
        try:
            pass
            # self.fpga.stop()
        except:
            pass
        event.accept()

    def onbbCalibrationaRejected(self):
        # self.fpga.stop()
        pass

    def onbbCalibrationaAccepted(self):
        try:
            # mmcm calibrate
            if self.ui.radioButtonTestMode.isChecked():
                print 'phase = ', mmcm_calibration(self.fpga, phase=-1)
            elif self.ui.lineEditMMCMPhase.text() != '':
                print 'phase = ', mmcm_calibration(self.fpga, phase=int(self.ui.lineEditMMCMPhase.text()))
            self.settings.set('mmcm', str(self.ui.lineEditMMCMPhase.text()))
            self.settings.writeXML()
            # adc calibrate
            offset = np.zeros(4)
            gain = np.zeros(4)
            phase = np.zeros(4)
            for i in range(4):
                aaa = QtCore.QVariant(self.tableModelADC5g.get(0, i))
                bbb = QtCore.QVariant(self.tableModelADC5g.get(1, i))
                ccc = QtCore.QVariant(self.tableModelADC5g.get(2, i))
                if aaa != None and bbb != None and ccc != None:
                    aaa = aaa.toFloat()
                    bbb = bbb.toFloat()
                    ccc = ccc.toFloat()
                    if aaa[1]:
                        offset[i] = aaa[0]
                    if bbb[1]:
                        gain[i] = bbb[0]
                    if ccc[1]:
                        phase[i] = ccc[0]
            adc_calibration(self.fpga, offset, gain, phase)
            # save settings
            offset, gain, phase = getadcspi(self.fpga)
            for i in range(4):
                self.settings.set('offset' + str(i + 1), str(offset[i]))
                self.settings.set('gain' + str(i + 1), str(gain[i]))
                self.settings.set('phase' + str(i + 1), str(phase[i]))
            self.settings.writeXML()
            # self.fpga.stop()
            QtGui.QMessageBox.question(self, 'Information', 'Calibration finished!', QtGui.QMessageBox.Yes)
            return True
        except Exception, e:
            print 'Calibration failed!'
            # self.fpga.stop()
            etype = repr(e).split('(')[0]
            emessage = e.message
            QtGui.QMessageBox.question(
                self, etype, emessage, QtGui.QMessageBox.Yes)
            return False

    @QtCore.pyqtSlot('QStandardItem *')
    def ontmADC5gChanged(self, item):
        print 'aaa'


class tableModel(QtCore.QAbstractTableModel):

    def __init__(self, shape):
        super(tableModel, self).__init__()
        self.shape = shape
        self.table = np.zeros(shape).tolist()
        self.hzheader = np.zeros(shape[1]).tolist()
        self.vtheader = np.zeros(shape[0]).tolist()

    def rowCount(self, parent=QtCore.QModelIndex()):
        return self.shape[0]

    def columnCount(self, parent=QtCore.QModelIndex()):
        return self.shape[1]

    def headerData(self, section, orientation, role=QtCore.Qt.DisplayRole):
        if role == QtCore.Qt.DisplayRole and orientation == QtCore.Qt.Horizontal:
            return self.getheader(section, 0)
        elif role == QtCore.Qt.DisplayRole and orientation == QtCore.Qt.Vertical:
            return self.getheader(section, 1)
        return QtCore.QAbstractTableModel.headerData(self, section, orientation, role)

    def setHeaderData(section, orientation, value, role=QtCore.Qt.EditRole):
        if role == QtCore.Qt.EditRole and orientation == QtCore.Qt.Horizontal:
            return self.setheader(section, value, 0)
        elif role == QtCore.Qt.EditRole and orientation == QtCore.Qt.Vertical:
            return self.setheader(section, value, 1)

    def setheader(self, section, value, flag):
        try:
            if flag == 0:
                self.hzheader[section] = value
            elif flag == 1:
                self.vtheader[section] = value
            return True
        except:
            return False

    def getheader(self, section, flag):
        if flag == 0:
            return self.hzheader[section]
        elif flag == 1:
            return self.vtheader[section]

    def data(self, index, role=QtCore.Qt.DisplayRole):
        if not index.isValid():
            return QtCore.QVariant()
        if role == QtCore.Qt.DisplayRole:
            try:
                return self.get(index.row(), index.column())
            except:
                return QtCore.QVariant()

    def setData(self, index, value, role=QtCore.Qt.EditRole):
        if not index.isValid():
            return False
        if role == QtCore.Qt.EditRole:
            return self.set(index.row(), index.column(), value)

    def flags(self, index):
        return QtCore.Qt.ItemIsEnabled | QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEditable

    def update(self):
        self.beginResetModel()
        self.endResetModel()

    def set(self, row, column, value):
        try:
            self.table[row][column] = value
            return True
        except:
            return False

    def get(self, row, column):
        return self.table[row][column]


class Roach2(QtGui.QMainWindow):

    def __init__(self):
        super(Roach2, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.dlprog = dialogprog()
        self.figure = plt.figure()
        self.canvas = FigureCanvas(self.figure)
        self.toolbarPlot = NavigationToolbar(self.canvas, self)
        self.ui.verticalLayoutScreen.addWidget(self.canvas)
        self.ui.verticalLayoutScreen.addWidget(self.toolbarPlot)
        self.raw = np.zeros(8096)
        # adc5g table
        self.show()

        # connections
        self.connect(self.ui.pushButtonCH1,
                     QtCore.SIGNAL('clicked()'), self.onpbCH1Clicked)
        self.connect(self.ui.pushButtonCH2,
                     QtCore.SIGNAL('clicked()'), self.onpbCH2Clicked)
        self.connect(self.ui.pushButtonCalibration, QtCore.SIGNAL(
            'clicked()'), self.onpbCalibrationClicked)
        self.connect(self.ui.pushButtonProg, QtCore.SIGNAL(
            'clicked()'), self.onpbProgClicked)
        self.connect(self.ui.pushButtonRun,
                     QtCore.SIGNAL('clicked()'), self.onpbRunClicked)
        self.connect(
            self.ui.comboBoxMode, QtCore.SIGNAL(
                'currentIndexChanged(const QString&)'),
                     self, QtCore.SLOT('oncbModeChanged(const QString&)'))

        self.connect(
            self.ui.comboBoxMath, QtCore.SIGNAL(
                'currentIndexChanged(const QString&)'),
                     self, QtCore.SLOT('oncbMathChanged(const QString&)'))

    def exproc(self, e):
        etype = repr(e).split('(')[0]
        emessage = e.message
        QtGui.QMessageBox.question(
            self, etype, emessage, QtGui.QMessageBox.Yes)
        self.ui.statusBar.showMessage(emessage)

    def closeEvent(self, event):
        try:
            self.dlprog.fpgacorr.stop()
        except:
            pass
        event.accept()

    def onpbProgClicked(self):
        self.dlprog.show()

    def onpbCalibrationClicked(self):
        calibrate = dialogcalibration(self.dlprog.fpgacorr)
        calibrate.exec_()

    @QtCore.pyqtSlot('const QString&')
    def oncbModeChanged(self, mod):
        self.plot()

    @QtCore.pyqtSlot('const QString&')
    def oncbMathChanged(self, mod):
        self.plot()

    def onpbRunClicked(self):
        if self.ui.pushButtonRun.isChecked():
            try:
                self.m_timerRun = self.startTimer(1000)
            except:
                self.ui.statusBar.showMessage('Can not start timer!')
        else:
            try:
                self.killTimer(self.m_timerRun)
            except:
                self.ui.statusBar.showMessage('Can not kill timer!')

    def onpbCH1Clicked(self):
        self.plot()

    def onpbCH2Clicked(self):
        self.plot()

    def timerEvent(self, event):
        if event.timerId() == self.m_timerRun:
            self.raw = np.array(adc5g.get_snapshot(self.dlprog.fpgacorr, 'scope_raw_1_snap'))
            #self.raw = np.random.rand(4096)
            self.plot()

    def plot(self):
        try:
            data1 = self.raw[0::2]
            data2 = self.raw[1::2]
            datac1 = np.fft.fft(data1)
            datac2 = np.fft.fft(data2)
            datak1 = np.abs(datac1)
            datak2 = np.abs(datac2)
        except Exception, e:
            self.exproc(e)
        self.figure.clf()
        ax0 = self.figure.add_subplot(111)
        if self.ui.comboBoxMode.currentText() == 'Normal':
            if self.ui.comboBoxMath.currentText() == 'None':
                if self.ui.pushButtonCH1.isChecked():
                    ax0.plot(data1, 'b')
                if self.ui.pushButtonCH2.isChecked():
                    ax0.plot(data2, 'r')
            elif self.ui.comboBoxMath.currentText() == 'FFT':
                if self.ui.pushButtonCH1.isChecked():
                    ax0.plot(20. * np.log10(datak1 / np.max(datak1)))
                if self.ui.pushButtonCH2.isChecked():
                    ax0.plot(20. * np.log10(datak2 / np.max(datak2)))
            elif self.ui.comboBoxMath.currentText() == 'Histogram':
                if self.ui.pushButtonCH1.isChecked():
                    std1 = np.std(data1)
                    ax0.hist(data1, bins=32, normed=1,color='b',histtype='step',rwidth=1.,label='rms='+str(std1))
                if self.ui.pushButtonCH2.isChecked():
                    std2 = np.std(data2)
                    ax0.hist(data2, bins=32, normed=1,color='r',histtype='step',rwidth=1.,label='rms='+str(std2))
                plt.legend()
        elif self.ui.comboBoxMode.currentText() == 'XY':
            ax0.plot(data1, data2)
            self.ui.pushButtonCH1.setChecked(True)
            self.ui.pushButtonCH2.setChecked(True)

        self.canvas.draw()


def mmcm_calibration(fpga, phase=20, zdok=0):
    try:
        if phase == -1:
            adc5g.set_test_mode(fpga, zdok)
            adc5g.sync_adc(fpga)
            opt0, glitches0 = adc5g.calibrate_mmcm_phase(
                fpga, zdok, ['scope_raw_1_snap', ])
            adc5g.unset_test_mode(fpga, zdok)
            return opt0
        else:
            for i in range(phase):
                adc5g.opb.inc_mmcm_phase(fpga, zdok)
            return phase
    except:
        return False


def adc_calibration(fpga, offset, gain, phase, zdok=0):
    try:
        N = len(offset)
        for i in range(N):
            adc5g.spi.set_spi_offset(fpga, zdok, i + 1, offset[i])
            adc5g.spi.set_spi_gain(fpga, zdok, i + 1, gain[i])
            adc5g.spi.set_spi_phase(fpga, zdok, i + 1, phase[i])
        return True
    except:
        return False


def getadcspi(fpga, zdok=0):
    offset = np.zeros(4)
    gain = np.zeros(4)
    phase = np.zeros(4)
    try:
        N = len(offset)
        for i in range(N):
            offset[i] = adc5g.spi.get_spi_offset(fpga, zdok, i + 1)
            gain[i] = adc5g.spi.get_spi_gain(fpga, zdok, i + 1)
            phase[i] = adc5g.spi.get_spi_phase(fpga, zdok, i + 1)
        return offset, gain, phase
    except:
        return False


def main():
    app = QtGui.QApplication(sys.argv)
    ex = Roach2()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
