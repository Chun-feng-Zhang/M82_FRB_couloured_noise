# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'mainwindow.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName(_fromUtf8("MainWindow"))
        MainWindow.setEnabled(True)
        MainWindow.resize(900, 538)
        MainWindow.setStyleSheet(_fromUtf8("background-color: rgb(225, 225, 225);"))
        self.centralWidget = QtGui.QWidget(MainWindow)
        self.centralWidget.setObjectName(_fromUtf8("centralWidget"))
        self.frameScreen = QtGui.QFrame(self.centralWidget)
        self.frameScreen.setGeometry(QtCore.QRect(10, 10, 571, 471))
        self.frameScreen.setStyleSheet(_fromUtf8("border-color: rgb(138, 138, 138);\n"
"border-width: 2px;\n"
"border-style: solid;\n"
"border-radius: 8px;\n"
""))
        self.frameScreen.setFrameShape(QtGui.QFrame.StyledPanel)
        self.frameScreen.setFrameShadow(QtGui.QFrame.Raised)
        self.frameScreen.setObjectName(_fromUtf8("frameScreen"))
        self.gridLayout = QtGui.QGridLayout(self.frameScreen)
        self.gridLayout.setMargin(11)
        self.gridLayout.setSpacing(6)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.verticalLayoutScreen = QtGui.QVBoxLayout()
        self.verticalLayoutScreen.setMargin(11)
        self.verticalLayoutScreen.setSpacing(6)
        self.verticalLayoutScreen.setObjectName(_fromUtf8("verticalLayoutScreen"))
        self.gridLayout.addLayout(self.verticalLayoutScreen, 0, 0, 1, 1)
        self.pushButtonCH1 = QtGui.QPushButton(self.centralWidget)
        self.pushButtonCH1.setGeometry(QtCore.QRect(630, 100, 85, 31))
        self.pushButtonCH1.setMinimumSize(QtCore.QSize(85, 27))
        self.pushButtonCH1.setStyleSheet(_fromUtf8(""))
        self.pushButtonCH1.setCheckable(True)
        self.pushButtonCH1.setObjectName(_fromUtf8("pushButtonCH1"))
        self.pushButtonCH2 = QtGui.QPushButton(self.centralWidget)
        self.pushButtonCH2.setGeometry(QtCore.QRect(780, 100, 85, 31))
        self.pushButtonCH2.setMinimumSize(QtCore.QSize(85, 27))
        self.pushButtonCH2.setStyleSheet(_fromUtf8(""))
        self.pushButtonCH2.setCheckable(True)
        self.pushButtonCH2.setObjectName(_fromUtf8("pushButtonCH2"))
        self.layoutWidget = QtGui.QWidget(self.centralWidget)
        self.layoutWidget.setGeometry(QtCore.QRect(650, 260, 201, 41))
        self.layoutWidget.setObjectName(_fromUtf8("layoutWidget"))
        self.horizontalLayout_9 = QtGui.QHBoxLayout(self.layoutWidget)
        self.horizontalLayout_9.setSizeConstraint(QtGui.QLayout.SetNoConstraint)
        self.horizontalLayout_9.setMargin(11)
        self.horizontalLayout_9.setSpacing(6)
        self.horizontalLayout_9.setObjectName(_fromUtf8("horizontalLayout_9"))
        self.labelMath = QtGui.QLabel(self.layoutWidget)
        self.labelMath.setMinimumSize(QtCore.QSize(85, 27))
        self.labelMath.setStyleSheet(_fromUtf8("border-color: rgb(149, 149, 149);\n"
"border-width: 1px;\n"
"border-style: solid;"))
        self.labelMath.setAlignment(QtCore.Qt.AlignCenter)
        self.labelMath.setObjectName(_fromUtf8("labelMath"))
        self.horizontalLayout_9.addWidget(self.labelMath)
        self.comboBoxMath = QtGui.QComboBox(self.layoutWidget)
        self.comboBoxMath.setMinimumSize(QtCore.QSize(85, 27))
        self.comboBoxMath.setObjectName(_fromUtf8("comboBoxMath"))
        self.comboBoxMath.addItem(_fromUtf8(""))
        self.comboBoxMath.addItem(_fromUtf8(""))
        self.comboBoxMath.addItem(_fromUtf8(""))
        self.horizontalLayout_9.addWidget(self.comboBoxMath)
        self.horizontalLayout_9.setStretch(0, 1)
        self.horizontalLayout_9.setStretch(1, 2)
        self.pushButtonCalibration = QtGui.QPushButton(self.centralWidget)
        self.pushButtonCalibration.setGeometry(QtCore.QRect(780, 380, 89, 41))
        self.pushButtonCalibration.setObjectName(_fromUtf8("pushButtonCalibration"))
        self.pushButtonProg = QtGui.QPushButton(self.centralWidget)
        self.pushButtonProg.setGeometry(QtCore.QRect(640, 380, 89, 41))
        self.pushButtonProg.setObjectName(_fromUtf8("pushButtonProg"))
        self.pushButtonRun = QtGui.QPushButton(self.centralWidget)
        self.pushButtonRun.setGeometry(QtCore.QRect(700, 20, 91, 41))
        self.pushButtonRun.setMinimumSize(QtCore.QSize(85, 27))
        self.pushButtonRun.setStyleSheet(_fromUtf8("selection-background-color: none;"))
        self.pushButtonRun.setCheckable(True)
        self.pushButtonRun.setObjectName(_fromUtf8("pushButtonRun"))
        self.layoutWidget1 = QtGui.QWidget(self.centralWidget)
        self.layoutWidget1.setGeometry(QtCore.QRect(650, 180, 201, 41))
        self.layoutWidget1.setObjectName(_fromUtf8("layoutWidget1"))
        self.horizontalLayout_7 = QtGui.QHBoxLayout(self.layoutWidget1)
        self.horizontalLayout_7.setSizeConstraint(QtGui.QLayout.SetNoConstraint)
        self.horizontalLayout_7.setMargin(11)
        self.horizontalLayout_7.setSpacing(6)
        self.horizontalLayout_7.setObjectName(_fromUtf8("horizontalLayout_7"))
        self.labelMode = QtGui.QLabel(self.layoutWidget1)
        self.labelMode.setMinimumSize(QtCore.QSize(85, 27))
        self.labelMode.setStyleSheet(_fromUtf8("border-color: rgb(149, 149, 149);\n"
"border-width: 1px;\n"
"border-style: solid;"))
        self.labelMode.setAlignment(QtCore.Qt.AlignCenter)
        self.labelMode.setObjectName(_fromUtf8("labelMode"))
        self.horizontalLayout_7.addWidget(self.labelMode)
        self.comboBoxMode = QtGui.QComboBox(self.layoutWidget1)
        self.comboBoxMode.setMinimumSize(QtCore.QSize(85, 27))
        self.comboBoxMode.setStyleSheet(_fromUtf8(""))
        self.comboBoxMode.setObjectName(_fromUtf8("comboBoxMode"))
        self.comboBoxMode.addItem(_fromUtf8(""))
        self.comboBoxMode.addItem(_fromUtf8(""))
        self.horizontalLayout_7.addWidget(self.comboBoxMode)
        self.horizontalLayout_7.setStretch(0, 1)
        self.horizontalLayout_7.setStretch(1, 2)
        MainWindow.setCentralWidget(self.centralWidget)
        self.menuBar = QtGui.QMenuBar(MainWindow)
        self.menuBar.setGeometry(QtCore.QRect(0, 0, 900, 31))
        self.menuBar.setObjectName(_fromUtf8("menuBar"))
        MainWindow.setMenuBar(self.menuBar)
        self.statusBar = QtGui.QStatusBar(MainWindow)
        self.statusBar.setObjectName(_fromUtf8("statusBar"))
        MainWindow.setStatusBar(self.statusBar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(_translate("MainWindow", "ROACH2", None))
        self.pushButtonCH1.setText(_translate("MainWindow", "CH1", None))
        self.pushButtonCH2.setText(_translate("MainWindow", "CH2", None))
        self.labelMath.setText(_translate("MainWindow", "Math", None))
        self.comboBoxMath.setItemText(0, _translate("MainWindow", "None", None))
        self.comboBoxMath.setItemText(1, _translate("MainWindow", "FFT", None))
        self.comboBoxMath.setItemText(2, _translate("MainWindow", "Histogram", None))
        self.pushButtonCalibration.setText(_translate("MainWindow", "Calibration", None))
        self.pushButtonProg.setText(_translate("MainWindow", "Prog", None))
        self.pushButtonRun.setText(_translate("MainWindow", "Run/Stop", None))
        self.labelMode.setText(_translate("MainWindow", "Mode", None))
        self.comboBoxMode.setItemText(0, _translate("MainWindow", "Normal", None))
        self.comboBoxMode.setItemText(1, _translate("MainWindow", "XY", None))

