#ifndef DIALOGADC5G_H
#define DIALOGADC5G_H

#include <QDialog>

namespace Ui {
class Dialogadc5g;
}

class Dialogadc5g : public QDialog
{
    Q_OBJECT

public:
    explicit Dialogadc5g(QWidget *parent = 0);
    ~Dialogadc5g();

private:
    Ui::Dialogadc5g *ui;
};

#endif // DIALOGADC5G_H
