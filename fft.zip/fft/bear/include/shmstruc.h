#ifndef _SHMSTRUCTURE_
#define _SHMSTRUCTURE_ 1
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

//#ifndef _BASEBAND_
//#define BASEBAND
//#define RATIO  32  /*the radio of len(baseband data)/len(filterbank data)*/
//typedef unsigned char BASETYPE;
//#endif // BASEBAND

#ifdef HAVE_CONFIG_H
/* include Autoconf-generated header */
#include "config.h"
#endif

#ifdef SOKTYPE_CHAR
  typedef char SOKTYPE;
#elif SOKTYPE_UCHAR
  typedef unsigned char SOKTYPE;
#elif SOKTYPE_INT
  typedef int SOKTYPE;
#elif SOKTYPE_UINT
  typedef unsigned int SOKTYPE;
#endif

#ifdef FILTYPE_CHAR
  typedef char FILTYPE;
#elif FILTYPE_UCHAR
  typedef unsigned char FILTYPE;
#elif FILTYPE_FLOAT
  typedef float FILTYPE;
#endif

//typedef char FILTYPE;

//typedef char SOKTYPE;

enum _STATUS
{
	EMPTY,									//Memory is empty
	WRF,											//fil Memory is being written
	WRB,                                        //base Memory is being written
	RDYF,										//Memory is ready for use
	RDY,
	RD,											//Memory is reading
	SAV											//Memory need to be saved.
};
typedef struct
{
	enum _STATUS Status;
	long int Shifts;
	double MJD;
	#ifdef BASEBAND
	double MJDB;
	#endif // BASEBAND
} _MEMELEM;
typedef struct
{
	long int Nseg;
	long int Nlen;
} _MEMINFO;
const int ElementSize=sizeof( _MEMELEM);
const char SHM_CNT_FN[]="frb_CNT";
const char SHM_INFO_FN[]="frb_header";
const char SHM_FN[]="frb_mem";
#ifdef BASEBAND
const char SHM_BS_FN[]="frb_base";
#endif // BASEBAND


void * OpenSHM(const char * fname, long int size, int oflag=O_RDWR|O_CREAT);
int UnmountSHM(void * add_p, long int size);
int UnlinkSHM(const char * fname);
void SaveCounts(long int Nseg, long int Nlen);
void ReadCounts(_MEMINFO * pmem, int oflag=O_RDWR|O_CREAT);
void UnlinkCounts(void);
#endif
