#ifndef __AUX_DEDSP_
#define __AUX_DEDSP_ 1
#include "filterbank.h"
#include <sedge.h>
void DMvsSNR(SEQUENCE & vdm, SEQUENCE & snr, FilterBankData * pfil);
/**\brief calculate the delay between two frequencies, frequency in units of
 * MHz, time in units of seconds  */
double DMDelay(float dm, float fl, float fh);

void GetBaseName(const char * fname, char * obj, char * ext);
void DM_w_vsSNR(SEQUENCE & vdm, SEQUENCE & vw, MATRIX2D & res, FilterBankData * pf);
void DM_t_vsSNR(SEQUENCE & vdm, SEQUENCE & vt, MATRIX2D & res, FilterBankData * pf);
void t_SNR(SEQUENCE & vt, SEQUENCE & vsnr, FilterBankData * pf);
double GetStatThreshold(double n, double p);
void GetProfile(SEQUENCE & prof, FilterBankData * pfil);
void GetfvsS(SEQUENCE & vf, SEQUENCE & s, double t, double dmv, double w, FilterBankData * pfil);
float * FormSCube(FilterBankData * pfil, float * pvt, float * pvdm, float * pvw);
bool SearchForIsolatedEvents(double thre, float * pt, long int nt, long int ndm, long int nw, MATRIX2D & mxevt, long int maxNevt);
bool SearchForNextEvents(double thre, float * pt, char * mask, long int nt, long int ndm, long int nw, long int & it, long int & idm, long int & iw);
bool GetParVec(FilterBankData * pf, SEQUENCE & vdm, SEQUENCE & vw, SEQUENCE & vt);
long int CountDOF (FilterBankData * pfil, long int nbox, double minw, double snrloss);
bool WriteSCube(const char * fname, float * pcube, long int Nsamples, long int Ndm, long int Nbox);
bool WriteInfo(const char * fname, FilterBankData & fil, long int k, double OptT, double OptDM, double OptW, long int vti, long vdmi, long vwi, double OptS, long int Sco, double maxind);
long int Score(SEQUENCE & vt, MATRIX2D & mxsub, double OptW, double OptS, SEQUENCE & pvindex2, SEQUENCE & pindexS, double alphaf=0.1, double beta_snr=0.333, double beta_etaf=0.333, double beta_ind=0.333);

float * FormSCube2(FilterBankData * pfil, SEQUENCE & pvindex, SEQUENCE & pvdm, SEQUENCE & pvw, long int vti, long int vdmi);
//bool Dedisperse2(FilterBankData * pfil, double dmv, double dmindex, long int vti1, long int vti2, float * ptim);
bool Dedisperse2(FilterBankData * pfil, int * sfti, long int vti1, long int vti2, float * ptim);
double DMDelay2(float dm, float fl, float fh, float dmindex);
float ApplyBoxFilter2(float * ori, float var, float mean, long int wi, long int n);
float getdm(FilterBankData * pfil, long int vdmi, float & var, float & mean);
float * runMedian(float * data, long int size, int w);
float * runMedian(float * data, int size, int w);
#endif
