/**\brief
 *
 * =====================================================================================
 *
 *       Filename:  tst_shm.cpp
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2016年04月30日 20时39分27秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  K.J.Lee (), 
 *   Organization:  
 *
 * =====================================================================================
 */



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sedge.h>
#include "shmstruc.h"
using namespace std;

void printhelp(const char * cmd)
{
	cout<<"Usage "<<cmd<<": "<<endl;
	cout<<endl;
	cout<<"    -m  N_seg Size  Opt   Modify contents."<<endl<<endl;
}

int main(int argc, char *argv[])
{
	if (argc==1)
	{
		printhelp(argv[0]);
		exit(0);
	}
	void * add_p=NULL;
	if (Se_CMD_Key_Exist(argv, argc, "-m"))
	{
		cout<<"Modify shared memory";
		_MEMINFO meminfo;
		ReadCounts(& meminfo);
		long int Nseg=meminfo.Nseg;
		long int Nlen=meminfo.Nlen;
		long int Nsl=Nlen/Nseg;
		cout<<" Nseq= "<<Nseg<<" Size= "<<Nlen<<" (sample)  Each Segmentaion="<<Nlen/Nseg<<" (sample)"<<endl;
		//Start to allocate the header information
		long int header_size=sizeof(_MEMELEM)*Nseg;
		add_p=OpenSHM(SHM_INFO_FN, header_size);
		if (add_p==(void *)(-1)) exit(1);
		
		//Setup header
		_MEMELEM * ph=NULL;
		ph=(_MEMELEM *) (add_p);
		long int i=Se_CMD_Key_Num(argv, argc, "-m", 0, 1);
		(ph+i)->Status=(_STATUS)(Se_CMD_Key_Num(argv, argc, "-m",0, 2));
		cout<<i<<"-th"<<" change to"<<(ph+i)->Status<<endl;
		if (UnmountSHM(add_p, header_size) ==-1)
		{
			perror("munmap failed: ");
			exit(1);
		}
		exit(0);
	}
}
