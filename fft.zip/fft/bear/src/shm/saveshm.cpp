/**\brief
 *
 * =====================================================================================
 *
 *       Filename:  tst_shm.cpp
 *
 *    Description:
 *
 *        Version:  1.0
 *        Created:  2016年04月30日 20时39分27秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  K.J.Lee (),
 *   Organization:
 *
 * =====================================================================================
 */



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sedge.h>
#include "shmstruc.h"
#include "filterbank.h"

using namespace std;

void printhelp(const char * cmd)
{
	cout<<"Usage "<<cmd<<": "<<endl;
	cout<<endl;
	cout<<"    -s     fname                 Save shared memory to the file name (fname)"<<endl;
	cout<<"    -fch1  Top freq (MHz)        Highest frequency of (channel 0)"<<endl;
	cout<<"    -foff  Channel widht (MHz)   Channel widht"<<endl;
	cout<<"    -nch   Channel number        Channel number"<<endl;
	cout<<"    -tsamp Sample rate           Sample rate"<<endl;
	cout<<"    -nif   Nifs                  Polarization parameter number"<<endl;
	cout<<"    -raw                         Save file if the status is RDY (OK)"<<endl;
}

int main(int argc, char *argv[])
{
	if (argc==1)
	{
		printhelp(argv[0]);
		exit(0);
	}
	void * add_p=NULL;
	if (Se_CMD_Key_Exist(argv, argc, "-s"))
	{
		_MEMINFO meminfo;
		ReadCounts(& meminfo);
		long int Nseg=meminfo.Nseg;
		long int Nlen=meminfo.Nlen;
		double Fch1=Se_CMD_Key_Num(argv, argc, "-fch1", 1800,1);
		double Foff=Se_CMD_Key_Num(argv, argc, "-foff", 0.5,1);
		int Nchans=Se_CMD_Key_Num(argv, argc, "-nch", 512,1);
		double Tsamp=Se_CMD_Key_Num(argv, argc, "-tsamp", 64e-6,1);
		int Nifs=Se_CMD_Key_Num(argv, argc, "-nif", 1,1);
		const char * fname=Se_CMD_Key_Val(argv, argc, "-s", 1);
		_STATUS savekey=SAV;
		if (Se_CMD_Key_Exist(argv, argc, "-raw"))
			savekey=RDY;
		long int Nsl=Nlen/Nseg;
		//Start to allocate the header information
		long int header_size=sizeof(_MEMELEM)*Nseg;
		add_p=OpenSHM(SHM_INFO_FN, header_size);
		if (add_p==(void *)(-1)) exit(1);
		void * add_datap=OpenSHM(SHM_FN, Nlen*sizeof(FILTYPE));
		if (add_datap==(void *)(-1)) exit(1);

		#ifdef BASEBAND
        void * add_basedatap=OpenSHM(SHM_BS_FN, Nlen*sizeof(BASETYPE)*RATIO);
		if (add_basedatap==(void *)(-1)) exit(1);
		#endif // BASEBAND

		//header pointer
		_MEMELEM * ph=(_MEMELEM *) (add_p);
		//data pointer
		while(true)
		{
			for (long int i=0;i<Nseg;i++)
			{
				if ((ph+i)->Status==savekey)
				{
					(ph+i)->Status=RD;
					FILTYPE * pd_proc=(FILTYPE*) (add_datap) + (ph+i)->Shifts;
					double mjd=(ph+i)->MJD;
					FilterBankData fil;
					strcpy(fil.Source_name, "J0000-0000");
					fil.UseFrequencyTable=false;
					fil.Az_start=0;
					fil.Za_start=0;
					fil.Src_dej=0;
					fil.Src_raj=0;
					fil.Tstart=mjd;
					fil.Tsamp=Tsamp;
					fil.Fch1=Fch1;
					fil.Foff=Foff;
					fil.Nchans=Nchans;
					fil.Nbits=sizeof(SOKTYPE)*8;
					fil.Nifs=Nifs;
					fil.RefDM=0;
					fil.Nsamples=Nsl/(Nifs*Nchans);
					fil.pData=new float [Nsl];
					for(long int j=0; j<Nsl; j++)
                        			fil.pData[j]=pd_proc[j];
					//fil.pData=pd_proc;
					//for (long int j=0; j<1024;j++) cout<<fil.pData[j]<<' ';
					char outputname[4096];
					sprintf(outputname, "%s_%.15f_%d.fil", fname, mjd, i);
					fil.WriteToFile(outputname);
					fil.Free();
					fil.pData=NULL;
					pd_proc=NULL;

					#ifdef BASEBAND
					double mjdb=(ph+i)->MJDB;
					BASETYPE * pbd_proc=(BASETYPE*) (add_basedatap) + (ph+i)->Shifts*RATIO;
                    char outbasename[4096];
                    sprintf(outbasename, "%s_%.15f_%d.base", fname, mjdb, i);
                    FILE * fp=fopen(outbasename, "wb");
                    fwrite(pbd_proc, sizeof(BASETYPE), Nsl, fp);
                    fclose(fp);
					#endif // BASEBAND

					(ph+i)->Status=EMPTY;
				}
			}
			//usleep(100);
		}
		if (UnmountSHM(add_p, header_size) ==-1)
		{
			perror("munmap failed: ");
			exit(1);
		}
		if (UnmountSHM(add_datap, Nlen*sizeof(FILTYPE)) ==-1)
		{
			perror("munmap failed: ");
			exit(1);
		}
		#ifdef BASEBAND
		if (UnmountSHM(add_basedatap, Nlen*sizeof(BASETYPE)*RATIO) ==-1)
		{
			perror("munmap failed: ");
			exit(1);
		}
		#endif // BASEBAND
		exit(0);
	}
	exit(0);
}


