/**\brief
 *
 * =====================================================================================
 *
 *       Filename:  tst_shm.cpp
 *
 *    Description:
 *
 *        Version:  1.0
 *        Created:  2016年04月30日 20时39分27秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  K.J.Lee (),
 *   Organization:
 *
 * =====================================================================================
 */



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sedge.h>
#include "shmstruc.h"
using namespace std;
//const char chrTranslate[]="EWORS";
const char chrTranslate[]="EWWOORS";
void printhelp(const char * cmd)
{
	cout<<"Usage "<<cmd<<": "<<endl;
	cout<<endl;
	cout<<"    -c  N_seg Size  Create the shared memory, the head information is in"<<endl;
	cout<<"                    file frb_header, the main memory is in file frb_mem."<<endl;
	cout<<"                    (N_seg) is the number of buffer,"                    <<endl;
	cout<<"                    (Size) is the size of each segments (in float)"<<endl;
	cout<<" "<<endl;
	cout<<"    -l              List the information of shared memory."<<endl<<endl;
	cout<<"    -r              Remove the shared memory."<<endl;
	cout<<"    -m N_Seg Stat   Modify flag of the shared memory, 0-EMPTY, 1-WR, 2-RDY (OK), 3-RD, 4-SAV"<<endl;
}
int main(int argc, char *argv[])
{
	if (argc==1)
	{
		printhelp(argv[0]);
		exit(0);
	}
	void * add_p=NULL;
	if (Se_CMD_Key_Exist(argv, argc, "-c"))
	{
		cout<<"Creating shared memory";
		//The number of buffer segmentation
		long int Nseg=Se_CMD_Key_Num(argv, argc, "-c", 20,1);
		//The number of buffer to store float number
		long int Nlen=Se_CMD_Key_Num(argv, argc, "-c", 50e6, 2);
		//The number of float number in each segmentation
		long int Nsl=Nlen/Nseg;
		cout<<" Nseq= "<<Nseg<<" Size= "<<Nlen<<" (samples)  Each Segmentaion="<<Nlen/Nseg<<" (samples)"<<endl;
		SaveCounts(Nseg, Nlen);
		//Start to allocate the header information
		long int header_size=sizeof(_MEMELEM)*Nseg;
		add_p=OpenSHM(SHM_INFO_FN, header_size);
		if (add_p==(void *)(-1)) exit(1);
		void * add_datap=OpenSHM(SHM_FN, Nlen*sizeof(FILTYPE));
        #ifdef BASEBAND
        void * add_basedatap=OpenSHM(SHM_BS_FN, Nlen*sizeof(BASETYPE)*RATIO);
        if (add_basedatap==(void *)(-1)) exit(1);
        #endif // BASEBAND
		if (add_datap==(void *)(-1)) exit(1);

		//Setup header
		_MEMELEM * ph=NULL;
		ph=(_MEMELEM *) (add_p);
		for (long int i=0;i<Nseg;i++)
		{
			(ph+i)->Status=EMPTY;
			(ph+i)->Shifts=i*Nsl;
			(ph+i)->MJD=56300.00000000001;
		}
		//Setup memory
		FILTYPE * pt=(FILTYPE * ) add_datap;
		long int nsl=Nlen/Nseg;
		for(long int i=0;i<Nlen;i++)
		{
			pt[i]=i/nsl;
		}

		if (UnmountSHM(add_p, header_size) ==-1)
		{
			perror("munmap failed: ");
			exit(1);
		}
		if (UnmountSHM(add_datap, Nlen*sizeof(FILTYPE)) ==-1)
		{
			perror("munmap failed: ");
			exit(1);
		}

		exit(0);
	}
	else if (Se_CMD_Key_Exist(argv, argc, "-r"))
	{
		_MEMINFO meminfo;
		ReadCounts(& meminfo);
		long int Nseg=meminfo.Nseg;
		long int Nlen=meminfo.Nlen;

		long int header_size=sizeof(_MEMELEM)*Nseg;
		add_p=OpenSHM(SHM_INFO_FN, header_size);
		void * add_datap=OpenSHM(SHM_FN, Nlen*sizeof(FILTYPE));
		#ifdef BASEBAND
		void * add_basedatap=OpenSHM(SHM_BS_FN, Nlen*sizeof(BASETYPE)*RATIO);
		if (add_basedatap==(void *)(-1)) exit(1);
		#endif // BASEBAND
		if ((long int)(add_p)==-1) exit(1);
		if (add_datap==(void *)(-1)) exit(1);
		if (UnmountSHM(add_p, header_size) ==-1)
		{
			perror("munmap failed: ");
			exit(1);
		}
		if (UnlinkSHM(SHM_INFO_FN)==-1)
		{
			perror("shm_unlink failed: ");
			exit(1);
		}
		if (UnmountSHM(add_datap, Nlen*sizeof(FILTYPE)) ==-1)
		{
			perror("munmap failed: ");
			exit(1);
		}
		if (UnlinkSHM(SHM_FN)==-1)
		{
			perror("shm_unlink failed: ");
			exit(1);
		}
		#ifdef BASEBAND
		if (UnmountSHM(add_basedatap, Nlen*sizeof(BASETYPE)*RATIO) ==-1)
		{
			perror("munmap failed: ");
			exit(1);
		}
		if (UnlinkSHM(SHM_BS_FN)==-1)
		{
			perror("shm_unlink failed: ");
			exit(1);
		}
		#endif // BASEBAND
		UnlinkCounts();
	}
	else if (Se_CMD_Key_Exist(argv, argc, "-l"))		//list memory information
	{
		_MEMINFO meminfo;
		ReadCounts(& meminfo, O_RDONLY);
		long int Nseg=meminfo.Nseg;
		long int Nlen=meminfo.Nlen;
		long int Nsl=Nlen/Nseg;
		long int header_size=sizeof(_MEMELEM)*Nseg;
		add_p=OpenSHM(SHM_INFO_FN, header_size, O_RDONLY);
		if ((long int)add_p==-1)
			exit(1);
		void * add_datap=OpenSHM(SHM_FN, Nlen*sizeof(FILTYPE), O_RDONLY);
		if (add_datap==(void *)(-1)) exit(1);
		FILTYPE * pt;
		_MEMELEM * ph=(_MEMELEM *) (add_p);
		//printf("\033[2J\033[1;1H");
		cout<<"===============================================Parameters==================================================="<<endl;
		cout<<"Nseg="<<Nseg<<"\t"<<"Nlen="<<Nlen*sizeof(FILTYPE)<<" B"<<endl;
		cout<<setiosflags(ios::left)<<setw(29)<<"Index";
		cout<<setiosflags(ios::left)<<setw(35)<<"MJD";
		cout<<setiosflags(ios::left)<<setw(15)<<"Status";
		cout<<setiosflags(ios::left)<<setw(26)<<"Shifts";
		cout<<setiosflags(ios::left)<<setw(33)<<"Dat0";
		cout<<setiosflags(ios::left)<<setw(30)<<"Dat1";
		cout<<setiosflags(ios::left)<<setw(32)<<"Dat-2";
		cout<<setiosflags(ios::left)<<setw(24)<<"Dat-1";
		cout<<endl;
		//cout<<"Index\tMJD\tStatus\tShifts\t Dat0\tDat1\tDat-2\tDat-1"<<endl;
		cout<<"==========================================================================================================="<<endl;
		for (long int i=0;i<Nseg;i++)
		{
			pt=(FILTYPE *)(add_datap)+(ph+i)->Shifts;

			cout<<setiosflags(ios::left)<<setw(15)<<i;
			cout<<setiosflags(ios::left)<<setw(35)<<std::fixed<<setprecision(15)<<(ph+i)->MJD;
			cout<<setiosflags(ios::left)<<setw(15)<<chrTranslate[(ph+i)->Status];
			cout<<setiosflags(ios::left)<<setw(19)<<std::fixed<<setprecision(3)<<(ph+i)->Shifts/1e6;
			cout<<setiosflags(ios::left)<<setw(24)<<std::scientific<<setprecision(4)<<(float)pt[0];
			cout<<setiosflags(ios::left)<<setw(24)<<std::scientific<<setprecision(4)<<(float)pt[1];
			cout<<setiosflags(ios::left)<<setw(24)<<std::scientific<<setprecision(4)<<(float)pt[Nsl-2];
			cout<<setiosflags(ios::left)<<setw(24)<<std::scientific<<setprecision(4)<<(float)pt[Nsl-1];
			//cout<<std::scientific<<setprecision(4)<<pt[0]<<"\t"<<pt[1]<<"\t"<<pt[Nsl-2]<<"\t"<<pt[Nsl-1];
			cout<<endl;
		}
		cout<<"==========================================================================================================="<<endl;
		if (UnmountSHM(add_p, header_size) ==-1)
		{
			perror("munmap failed: ");
			exit(1);
		}
	}
	else if (Se_CMD_Key_Exist(argv, argc, "-d"))		//Dump data to text
	{
		_MEMINFO meminfo;
		ReadCounts(& meminfo, O_RDONLY);
		long int Nseg=meminfo.Nseg;
		long int Nlen=meminfo.Nlen;
		long int header_size=sizeof(_MEMELEM)*Nseg;
		add_p=OpenSHM(SHM_INFO_FN, header_size, O_RDONLY);
		if ((long int)add_p==-1)
			exit(1);
		void * add_datap=OpenSHM(SHM_FN, Nlen*sizeof(FILTYPE), O_RDONLY);
		if (add_datap==(void *)(-1)) exit(1);
		FILTYPE * pt;
		_MEMELEM * ph=(_MEMELEM *) (add_p);

		long int indseg=Se_CMD_Key_Num(argv, argc, "-i",0);
		long int nsmp=Se_CMD_Key_Num(argv, argc, "-n", 1000);
		long int nch=Se_CMD_Key_Num(argv, argc, "-nch", 512);
		cout<<"#Going to dump "<<indseg<<"-th segmentation, and "<<nsmp<<" samples"<<endl;
		pt=(FILTYPE *)(add_datap)+(ph+indseg)->Shifts;
		for (long int i=0;i<nsmp;i++)
		{
			for (long int j=0;j<nch;j++)
			{
				cout<<pt[0]<<" ";
				pt++;
			}
			cout<<endl;
		}
		if (UnmountSHM(add_p, header_size) ==-1)
		{
			perror("munmap failed: ");
			exit(1);
		}
	}
	else if (Se_CMD_Key_Exist(argv, argc, "-m"))
	{
		cout<<"Modify shared memory";
		_MEMINFO meminfo;
		ReadCounts(& meminfo);
		long int Nseg=meminfo.Nseg;
		long int Nlen=meminfo.Nlen;
		long int Nsl=Nlen/Nseg;
		cout<<" Nseq= "<<Nseg<<" Size= "<<Nlen<<" (sample)  Each Segmentaion="<<Nlen/Nseg<<" (sample)"<<endl;
		//Start to allocate the header information
		long int header_size=sizeof(_MEMELEM)*Nseg;
		add_p=OpenSHM(SHM_INFO_FN, header_size);
		if (add_p==(void *)(-1)) exit(1);

		//Setup header
		_MEMELEM * ph=NULL;
		ph=(_MEMELEM *) (add_p);
		char * strmemi=Se_CMD_Key_Val(argv, argc, "-m", 1);
		char * psep=strrchr(strmemi,':');
		if (psep==NULL)
		{
			long int i=Se_CMD_Key_Num(argv, argc, "-m", 0, 1);
			(ph+i)->Status=(_STATUS)(Se_CMD_Key_Num(argv, argc, "-m",0, 2));
			cout<<i<<"-th"<<" change to"<<(_STATUS)(Se_CMD_Key_Num(argv, argc, "-m",0, 2))<<endl;
		}
		else
		{
			long int istart, iend;
			if (strlen(psep+1)>0)
			{
				iend=atof(psep+1);
				char strstart[4096];
				strncpy(strstart, strmemi, psep-strmemi);
				strstart[psep-strmemi]='\0';
				istart=atof(strstart);
							}
			else
			{
				char strstart[4096];
				strncpy(strstart, strmemi, psep-strmemi);
				strstart[psep-strmemi]='\0';
				istart=atof(strstart);
				iend=Nseg-1;
			}
			if (iend>=Nseg)
					iend=Nseg-1;
			if (iend<0)
				iend=0;
			if (istart<0)
					istart=0;
			if (istart>=Nseg)
					istart=Nseg-1;

			for (long int i=istart;i!=iend; i+=(iend-istart)/round(fabs(iend-istart)))
			{
				(ph+i)->Status=(_STATUS)(Se_CMD_Key_Num(argv, argc, "-m",0, 2));
				cout<<i<<"-th"<<" change to"<<(ph+i)->Status<<endl;
			}
			(ph+iend)->Status=(_STATUS)(Se_CMD_Key_Num(argv, argc, "-m",0, 2));
				cout<<iend<<"-th"<<" change to"<<(_STATUS)(Se_CMD_Key_Num(argv, argc, "-m",0, 2))<<endl;
		}
		if (UnmountSHM(add_p, header_size) ==-1)
		{
			perror("munmap failed: ");
			exit(1);
		}
		exit(0);
	}
}
