/**\brief
 *
 * =====================================================================================
 *
 *       Filename:  shmstruc.cpp
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2016年05月03日 14时10分18秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  K.J.Lee (), 
 *   Organization:  
 *
 * =====================================================================================
 */
#include "shmstruc.h"
void * OpenSHM(const char * fname, long int size, int oflag)
{
	void * add_p=NULL;
	int fID;
	if ( (fID=shm_open(fname, oflag, 0777))==-1)
	{
		perror("shm failed: ");
		return ((void *)(-1));
	}
	if (oflag!=O_RDONLY)
	{
		if(ftruncate(fID, size)==-1)
		{
			perror("ftruncate faile: ");
			return ((void *)(-1));
		}
	}
	if (oflag==O_RDONLY)
		add_p=mmap(NULL, size, PROT_READ, MAP_SHARED, fID, SEEK_SET);
	else
		add_p=mmap(NULL, size, PROT_WRITE|PROT_READ, MAP_SHARED, fID, SEEK_SET);
	
	if (add_p==NULL)
	{
		perror("mmap failed: ");
		return((void * )(-1));
	}
	return add_p;
}
int UnmountSHM(void * add_p, long int size)
{
	return (munmap(add_p, size));
}
int UnlinkSHM(const char * fname)
{
	return (shm_unlink(fname));
}

void SaveCounts(long int Nseg, long int Nlen)
{
	_MEMINFO* add_c=(_MEMINFO *)OpenSHM(SHM_CNT_FN, sizeof(_MEMINFO));
	if (add_c==(_MEMINFO *)(-1)) exit(1);
	add_c->Nseg=Nseg;
	add_c->Nlen=Nlen;
	if (UnmountSHM(add_c, sizeof(_MEMINFO)) ==-1)
	{
			perror("munmap failed: ");
			exit(1);
	}

}
void ReadCounts(_MEMINFO * pmem, int oflag)
{
	_MEMINFO* add_c=(_MEMINFO *)OpenSHM(SHM_CNT_FN, sizeof(_MEMINFO), oflag);
	if (add_c==(_MEMINFO *)(-1)) exit(1);
	pmem->Nseg=add_c->Nseg;
	pmem->Nlen=add_c->Nlen;
	if (UnmountSHM(add_c, sizeof(_MEMINFO)) ==-1)
	{
			perror("munmap failed: ");
			exit(1);
	}
}

void UnlinkCounts(void)
{
	_MEMINFO* add_c=(_MEMINFO *)OpenSHM(SHM_CNT_FN, sizeof(_MEMINFO));
	if (add_c==(_MEMINFO *)(-1)) exit(1);
	if (UnmountSHM(add_c, sizeof(_MEMINFO)) ==-1)
	{
			perror("munmap failed: ");
			exit(1);
	}
	if (UnlinkSHM(SHM_CNT_FN)==-1)
	{
		perror("shm_unlink failed: ");
		exit(1);
	}
}
