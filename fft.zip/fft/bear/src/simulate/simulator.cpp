#include <iostream>
#include <sedge.h>
#include <math.h>
#include "filterbank.h"
#include "aux.h"
#include "shmstruc.h"
#include "time.h"
#include "sys/time.h"
using namespace std;

void printhelp(int argc, char * argv[]);
double waveform(double t, double wi)
{
    double res;
    res=t/wi;
    res=exp(-0.5*res*res);
    return res;
}
double GetMJDNow(void)
{
    time_t timep;
    struct tm *p;
    timep=time(&timep);
    p=gmtime(&timep);
    double Year=p->tm_year+1900;
    double Month=p->tm_mon+1;
    double Day=p->tm_mday;
    double Mjd=UTC2MJD(Year, Month, Day);
    struct timeval currenttime;
    gettimeofday( &currenttime, NULL );
    double MJD=Mjd+(double)((p->tm_hour)/24.0)+(double)(p->tm_min/1440.0)+(double)(p->tm_sec/86400.0)+(double)(currenttime.tv_usec/86400.0/1000000.0);
    return MJD;
}

int main(int argc, char * argv[])
{
    FilterBankData fil;

    if (argc==1 || Se_CMD_Key_Exist(argv, argc, "-h"))
    {
        printhelp(argc, argv);
        exit(0);
    }
    if (Se_CMD_Key_Exist(argv, argc, "-share"))
    {
        _MEMINFO meminfo;
        ReadCounts(& meminfo, O_RDWR);
        //Simulation parameters
        double width=1e-3;
        double amp=2.0;
        double dm=500;

        long int Nchans=512;
        double Fch1=1800;
        double Foff=-1;
        double Tsamp=64e-6;
        long int Nseg=meminfo.Nseg;
        long int Nlen=meminfo.Nlen;
        long int Nsl=Nlen/Nseg;

        long Nsamples=Nsl/Nchans;
        //Start to allocate the header information
        void * add_p=NULL;
        long int header_size=sizeof(_MEMELEM)*Nseg;
        add_p=OpenSHM(SHM_INFO_FN, header_size, O_RDWR);
        if (add_p==(void *)(-1)) exit(1);
        void * add_datap=OpenSHM(SHM_FN, Nlen*sizeof(float), O_RDWR);
        if (add_datap==(void *)(-1)) exit(1);
        //header pointer
        _MEMELEM * ph=(_MEMELEM *) (add_p);
        double * vshift=new double [Nchans];
        double * frequency_table=new double [Nchans];

        for (long int i=0; i<Nchans; i++)
        {
            frequency_table[i]=Fch1+Foff*i;
            vshift[i]=DMDelay(dm, frequency_table[i], Fch1)/Tsamp;
        }

        while(true)
        {
            //loop over each segmentation of buffers
            for (long int i=0; i<Nseg; i++)
            {
                //Find the Ready buffer
                if ((ph+i)->Status==EMPTY)
                {
                    (ph+i)->Status=RD;
                    float * pData= (float *)(add_datap) + (ph+i)->Shifts;
                    (ph+i)->MJD=GetMJDNow();
                    double pv=ran2();
                    for(long int is=0; is<Nsamples; is++)
                    {
                        for(long int ic=0; ic<Nchans; ic++)
                        {
                            double t=is*Tsamp;
                            //if (i%2==0)
                            //	pData[is*Nchans+ic]=Se_RanGaussian(0,1)+amp*waveform(t+(-vshift[ic]-Nsamples*pv)*Tsamp,
                            //	width);
                            //else
                            pData[is*Nchans+ic]=Se_RanGaussian(0,1);
                        }
                    }
                    (ph+i)->Status=RDY;
                }
                //sleep(1);
            }
        }
        exit(0);
    }
    strcpy(fil.Source_name, "J0000-0000");
    fil.UseFrequencyTable=false;
    fil.Az_start=0;
    fil.Za_start=0;
    fil.Src_dej=0;
    fil.Src_raj=0;
    fil.Tstart=53121;
    fil.Tsamp=65e-6;
    fil.Fch1=1400;
    fil.Foff=-1;
    fil.Nchans=Se_CMD_Key_Num(argv, argc, "-nc", 200);
    fil.Nbits=32;
    fil.Nifs=1;
    fil.RefDM=0;
    fil.Nsamples=Se_CMD_Key_Num(argv, argc, "-ns", 15385);
    long int n=fil.Nsamples*fil.Nchans;
    fil.pData=new float[n];
    double dm=Se_CMD_Key_Num(argv, argc, "-dm", 500);
    fil.frequency_table=new double [fil.Nchans];
    double * vshift=new double [fil.Nchans];
    for (long int i=0; i<fil.Nchans; i++)
    {
        fil.frequency_table[i]=fil.Fch1+fil.Foff*i;
        vshift[i]=DMDelay(dm, fil.frequency_table[i], fil.Fch1)/fil.Tsamp;
    }
    double amp=Se_CMD_Key_Num(argv,argc, "-amp",2);
    SEQUENCE vamp;
    SEQUENCE vdm;
    SEQUENCE vt;
    SEQUENCE vw;
    if (Se_CMD_Key_Exist(argv, argc, "-flux"))
    {
        long int namp=Se_CMD_Key_N(argv, argc, "-flux");
        vamp.New(namp);
        vdm.New(namp);
        vt.New(namp);
        vw.New(namp);
        for (long int i=0; i<namp; i++)
        {
            double flux=Se_CMD_Key_Num(argv, argc, "-flux", 0, (double)(i+1)); //flux in Jy
            double gain;
            if (Se_CMD_Key_Exist(argv, argc, "-gain"))
                gain=Se_CMD_Key_Num(argv, argc, "-gain", 0.15);
            else if(Se_CMD_Key_Exist(argv, argc, "-D"))
            {
                double D;
                D=Se_CMD_Key_Num(argv, argc, "-D", 25);
                gain=2.84*0.7*(D/100)*(D/100);
                cout<<"Gain="<<gain<<" K/Jy"<<endl;
            }
            else
                gain = 0.15;
            double Tsys=Se_CMD_Key_Num(argv, argc, "-tsys", 25);
            double SNRperPtperBW=flux*gain/Tsys*sqrt(fabs(fil.Foff)*1e6*fil.Tsamp);
            vamp(i)=SNRperPtperBW;
            vdm(i)=Se_CMD_Key_Num(argv, argc, "-dm", 500, i+1);
            vt(i)=ran2()*fil.Nsamples*fil.Tsamp;
            vw(i)=Se_CMD_Key_Num(argv, argc, "-wi", 1e-3, i+1);
        }
        cout<<"----------------------------------------"<<endl;
        cout<<"Index  \tT       \tSNR       \tWIDTH  \tDM"<<endl;
        for (long int i=0; i<namp; i++)
        {
            cout.width(6);
            cout<<left<<i;
            cout<<"\t";
            cout.width(6);
            cout<<left<<vt(i);
            cout<<"\t";
            cout.width(6);
            cout<<left<<vamp(i);
            cout<<"\t";
            cout.width(6);
            cout<<left<<vw(i);
            cout<<"\t";
            cout.width(6);
            cout<<left<<vdm(i)<<endl;
        }
        cout<<"----------------------------------------"<<endl;
    }
    double width=Se_CMD_Key_Num(argv,argc, "-wi",1e-3);
    if (vamp.n==0)
    {
        for(long int i=0; i<fil.Nsamples; i++)
        {
            for(long int j=0; j<fil.Nchans; j++)
            {
                double t=i*fil.Tsamp;

                fil.pData[i*fil.Nchans+j]=Se_RanGaussian(0,1)+amp*waveform(t+(-vshift[j]-fil.Nsamples*0.75)*fil.Tsamp, width);
            }
        }
    }
    else
    {
        for(long int i=0; i<fil.Nsamples; i++)
        {
            for(long int j=0; j<fil.Nchans; j++)
            {
                double t=i*fil.Tsamp;
                double signal=0;
                for(long int k=0; k<vamp.n; k++)
                {
                    double vsft=DMDelay(vdm(k), fil.frequency_table[j], fil.Fch1)/fil.Tsamp;
                    signal+=vamp(k)*waveform(t+(-vsft)*fil.Tsamp -vt(k), vw(k));
                }
                fil.pData[i*fil.Nchans+j]=Se_RanGaussian(0,1)+signal;
            }
        }

    }
    fil.WriteToFile(Se_CMD_Key_Val(argv, argc, "-o"));
}

void printhelp(int argc, char * argv[])
{
    cout<<"Usage :"<<endl;
    cout<<argv[0]<<" [arguments]"<<endl;
    cout<<"Where:"<<endl;
    cout<<
        "   -f  input           Input filterbank file \n"<<
        "   -z                  Use zero-DM RFI filter \n"<<

        "   [-dms]      [0   ]  Dispersion Start value\n"<<
        "   [-ddm]      [1   ]  Dispersion Step value\n"<<
        "   [-dde]      [1000]  Dispersion End value\n"<<

        "   [-nbox]     [15]    Number of boxcar filter\n"<<
        "   [-snrloss]  [0.15]  Tolerent SNR loss for boxcar\n"<<
        "   -o                  Output filterbank files\n"<<
        endl;
}


