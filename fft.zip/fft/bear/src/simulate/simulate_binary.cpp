#include <iostream>
#include <sedge.h>
#include <math.h>
#include "filterbank.h"
#include "aux.h"
using namespace std;

void printhelp(int argc, char * argv[]);
double waveform(double t, double wi, double p, double pd)
{
	double f=1./p;
	double fd=pd/p/p;
	double res;
	double phi=t*f+0.5*t*t*fd;
	phi=phi-floor(phi)-0.5;
	res=phi/wi;
	res=exp(-0.5*res*res);
	return res;
}
int main(int argc, char * argv[])
{
	FilterBankData fil;

	if (argc==1 || Se_CMD_Key_Exist(argv, argc, "-h"))
	{
		printhelp(argc, argv);
		exit(0);
	}
	strcpy(fil.Source_name, "J0000-0000");
	fil.UseFrequencyTable=false;
	fil.Az_start=0;
	fil.Za_start=0;
	fil.Src_dej=0;
	fil.Src_raj=0;
	fil.Tstart=53121;
	fil.Tsamp=65e-6;
	fil.Fch1=1400;
	fil.Foff=-1;
	fil.Nchans=Se_CMD_Key_Num(argv, argc, "-nc", 200);
	fil.Nbits=8;
	fil.Nifs=1;
	fil.RefDM=0;
	fil.Nsamples=Se_CMD_Key_Num(argv, argc, "-ns", 1538500);
	long int n=fil.Nsamples*fil.Nchans;
	fil.pData=new float[n];
	double dm=Se_CMD_Key_Num(argv, argc, "-dm", 30);
	double p=Se_CMD_Key_Num(argv, argc, "-p", 0.003);
	double pd=Se_CMD_Key_Num(argv, argc, "-pd", 0.00);
	fil.frequency_table=new double [fil.Nchans];
	double * vshift=new double [fil.Nchans];
	for (long int i=0;i<fil.Nchans;i++)
	{
		fil.frequency_table[i]=fil.Fch1+fil.Foff*i;
		vshift[i]=DMDelay(dm, fil.frequency_table[i], fil.Fch1)/fil.Tsamp;
	}
	double amp=Se_CMD_Key_Num(argv,argc, "-snr",2);
	double width=Se_CMD_Key_Num(argv,argc, "-wi",1e-3);
		for(long int i=0;i<fil.Nsamples;i++)
		{
			for(long int j=0;j<fil.Nchans;j++)
			{
				double t=i*fil.Tsamp;
				
				fil.pData[i*fil.Nchans+j]=Se_RanGaussian(0,1)*10+amp*10*waveform(t+(-vshift[j]-fil.Nsamples*0.75)*fil.Tsamp, width, p,pd);
			}
		}
	
	fil.WriteToFile(Se_CMD_Key_Val(argv, argc, "-o"));
	fil.Free();
	cout<<"Hell"<<endl;
}

void printhelp(int argc, char * argv[])
{
	cout<<"Usage :"<<endl;
	cout<<argv[0]<<" [arguments]"<<endl;
	cout<<"Where:"<<endl;
	cout<<
	    "   -f  input           Input filterbank file \n"<<
	    "   -z                  Use zero-DM RFI filter \n"<<

			"   [-dms]      [0   ]  Dispersion Start value\n"<<
			"   [-ddm]      [1   ]  Dispersion Step value\n"<<
			"   [-dde]      [1000]  Dispersion End value\n"<<
			
			"   [-nbox]     [15]    Number of boxcar filter\n"<<
			"   [-snrloss]  [0.15]  Tolerent SNR loss for boxcar\n"<<
			"   -o                  Output filterbank files\n"<<
	    endl;
}


