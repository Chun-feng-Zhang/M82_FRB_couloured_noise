/**\brief
 *
 * =====================================================================================
 *
 *       Filename:  aux2.cpp
 *
 *    Description:
 *
 *        Version:  1.0
 *        Created:  2016年05月03日 16时21分58秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  K.J.Lee (),
 *   Organization:
 *
 * =====================================================================================
 */
#include "aux.h"
void GetBaseName(const char * fname, char * obj, char * ext)
{
	obj[0]='\0';
	ext[0]='\0';
	long int n=strlen(fname);
	long int ind=n;
	for (long int i=n-1; i>=0; i--)
	{
		if (fname[i]=='.')
		{
			ind=i;
			break;
		}
	}
	for (long int i=0; i<ind; i++)
	{
		obj[i]=fname[i];
	}
	obj[ind]= '\0';
	for (long int i=ind+1; i<n; i++)
		ext[i-ind-1]=fname[i];
	ext[n-ind-1]= '\0';
}
/**\brief calculate the delay between two frequencies, frequency in units of
 * MHz, time in units of seconds  */
double DMDelay(float dm, float fl, float fh)
{
	return (4148.741601 *dm * ( 1./(fl*fl) - 1./(fh*fh) ) );
}
