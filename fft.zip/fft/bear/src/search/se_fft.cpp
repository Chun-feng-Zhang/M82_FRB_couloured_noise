#include "se_fft.h"
bool Pow_Phase(SEQUENCE & Real, SEQUENCE & Complex,SEQUENCE & Power, SEQUENCE & Phase)
{
long int i;
if((Real.n==Complex.n) && (Complex.n==Power.n) && (Power.n==Phase.n))
{
for(i=0;i<Complex.n;i++)
{
if (Real.Data(i)==0)
{
if (Complex.Data(i)>=0)
{
daysPower.Set(i,(Complex.Data(i))*(Complex.Data(i)));
Phase.Set(i,HALFPI);
}
else
{
Power.Set(i,(Complex.Data(i))*(Complex.Data(i)));
Phase.Set(i,HALFPI*3.0);
}
}
else
{
Power.Set(i,(Real.Data(i))*(Real.Data(i))+((Complex.Data(i))*(Complex.Data(i))) );
Phase.Set(i,AbsATan(Real.Data(i),Complex.Data(i)));
}
}
return(true);
}
else
return(false);
}

bool Real_Imag(SEQUENCE & Real, SEQUENCE & Complex,SEQUENCE & Power, SEQUENCE & Phase)
{
long int i;
SE_LONG_DOUBLE temp;
if((Real.n==Complex.n) && (Complex.n==Power.n) && (Power.n==Phase.n))
{
for(i=0;i<Complex.n;i++)
{
temp=sqrt(Absolute(Power.Data(i)));
Real.Set(i,temp*cos(Phase.Data(i)));
Complex.Set(i,temp*sin(Phase.Data(i)));
}
return(true);
}
else
return(false);
}
bool Hilbert(SEQUENCE & Real, SEQUENCE & Complex)
{
bool succeed;
long int i;
SEQUENCE seqTemp(Real.n);
for(i=0;i<Real.n;i++)
{
seqTemp.Set(i,Real.Data(i));
}
succeed=Fft1d(Real,Complex,1);
for(i=1;i<(Complex.n)>>1-1;i++)
{
Complex.Set((Complex.n)-i,Complex.Data(i));
Real.Set((Complex.n)-i,-(Real.Data(i)));
}
succeed=succeed && Fft1d(Real,Complex,-1);
for(i=0;i<Real.n;i++)
{
Real.Set(i,seqTemp.Data(i));
}
return(succeed);
}

bool Fft1d(SEQUENCE & Real, SEQUENCE & Complex,int isign) //n=2^k
{
long int nn,n,mmax,m,j,istep,i;
long int i2, j2;
SE_LONG_DOUBLE wtemp,wr,wpr,wpi,wi,theta;
SE_LONG_DOUBLE tempr,tempi;
if((Real.n)==(Complex.n))
{
nn=Real.n;
n=nn << 1;
j=1;
for (i=1;i<n;i+=2)
{
i2=i>>1;
j2=j>>1;
if (j > i)
{

tempr=*(Real.head + j2);
*(Real.head+j2)=*(Real.head+i2);//Real.Set(j2,Real.Data(i2));
*(Real.head+i2)=tempr; //Real.Set(i2,tempr);

tempr=*(Complex.head+j2);
*(Complex.head+j2)= *(Complex.head+i2);//Complex.Set(j2,Complex.Data(i2));
*(Complex.head+i2)=tempr; //Complex.Set(i2,tempr);
}
m=n >> 1;
while (m >= 2 && j > m)
{
j -= m;
m >>= 1;
}
j += m;
}

mmax=2;
while (n > mmax)
{
istep=mmax << 1;
theta=-isign*(PI2/mmax);
wtemp=sin(0.5*theta);
wpr = -2.0*wtemp*wtemp;
wpi=sin(theta);
wr=1.0;
wi=0.0;
for (m=1;m<mmax;m+=2)
{
for (i=m;i<=n;i+=istep)
{
j=i+mmax;
i2=i>>1;
j2=j>>1;
tempr=wr*Real.head[j2]-wi*Complex.head[j2];
tempi=wr*Complex.head[j2]+wi*Real.head[j2];
*(Real.head+j2)=*(Real.head+i2)-tempr; //Real.Set(j2,(Real.head[i2])-tempr);
*(Real.head+i2)=*(Real.head+i2)+tempr; //Real.Set(i2,(Real.Data(i2))+tempr);
*(Complex.head+j2)=*(Complex.head+i2)-tempi; // Complex.Set(j2,(Complex.Data(i2))-tempi);
*(Complex.head+i2)=*(Complex.head+i2)+tempi; // Complex.Set(i2,(Complex.Data(i2))+tempi);
}
wr=(wtemp=wr)*wpr-wi*wpi+wr;
wi=wi*wpr+wtemp*wpi+wi;
}
mmax=istep;
}

if(isign==-1)
{
// SE_LONG_DOUBLE sn=sqrt((SE_LONG_DOUBLE)nn);
for(i=0;i<nn;i++)
{
Real.Set(i,Real.Data(i)/nn);
Complex.Set(i,Complex.Data(i)/nn);
}
}
// else
// {
// }
return(true);
}
else
return(false);

}
