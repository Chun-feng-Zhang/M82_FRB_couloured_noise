#include <iostream>
#include <cstdlib>
#include <string>
#include <sedge.h>
#include <math.h>
#include "filterbank.h"
#include "aux.h"
#include "shmstruc.h"
#include <typeinfo>


using namespace std;

void DebugDump(FilterBankData & fil);
void printhelp(int argc, char * argv[]);
void GraphicalOutPut(FilterBankData & fil, const string gdrv, const SEQUENCE & vthre, const MATRIX2D & mxevt, bool boldebug=false, double t0=0);
void CandGraphicalOutPut(FilterBankData & fil, float * pcube, float * pvt, float * pvdm, float * pvw, const SEQUENCE & vthre, const MATRIX2D & mxevt, double t0);
bool bolDebug;
bool bolScube;
bool bolInfo;
bool bolCand;
void THISISTHEVIPFUNCTION(void);
void SearchForFRB(FilterBankData & fil, long int starts, long int ends, long int fstarts, long int fends, long int ds, string * pstrrfimethod, float * ptscale, long int rfiN, float dms, float ddm, float dme, long int nbox,
                  float snrloss, double minw, SEQUENCE & vthre,  const char * gradrv, MATRIX2D & mxEventPar, bool bolreadfile=true, const char * fakegradrv="tmp.PNG/PNG", double t0=0, bool bolUseStd=true);

int main(int argc, char * argv[])
{
    /*
    const char * env_pgplot=std::getenv("");
    cout<<"PATH= "<<env_pgplot<<endl;

    if (env_pgplot == NULL)
    {
        cout<<"Can't read environment PGPLOT_FONT!"<<endl;
        exit(-1);
    }
    */
    //setenv("PGPLOT_FONT", "/opt/pgplot/grfont.dat", 0);

    FilterBankData fil;
    strcpy(fil.Source_name, "J0000-0000");

    bolDebug=Se_CMD_Key_Exist(argv, argc, "-debug");
    bolScube=Se_CMD_Key_Exist(argv, argc, "-scube");
    bolInfo=Se_CMD_Key_Exist(argv, argc, "-info");
    bolCand=Se_CMD_Key_Exist(argv, argc, "-cand");
    if (argc==1 || Se_CMD_Key_Exist(argv, argc, "-h"))
    {
        printhelp(argc, argv);
        exit(0);
    }
    if (bolDebug) cout<<"Read in header"<<endl;

    long int ds=Se_CMD_Key_Num(argv,argc, "-ds",10);

    string * pstrrfimethod=NULL;
    float * ptscale=NULL;
    long int rfiN=0;
    if (Se_CMD_Key_Exist(argv, argc, "-rfi"))
    {

        long int N=Se_CMD_Key_N(argv, argc, "-rfi");
        string strrfi;

        for (long int i=0; i<N; i++)
        {
            strrfi=Se_CMD_Key_Val(argv, argc, "-rfi", i+1);
            if (strrfi=="zdot" || strrfi=="zap1" || strrfi=="zap2" || strrfi=="zero" ||strrfi=="runMedian" ||strrfi=="runMedian2")
                rfiN+=1;
        }
        pstrrfimethod= new string [rfiN];
        ptscale= new float [rfiN];
        long int k=0,j=0;
        while(k<N)
        {
            strrfi=Se_CMD_Key_Val(argv, argc, "-rfi", k+1);
            k++;
            if (strrfi=="zdot" || strrfi=="zero")
            {
                pstrrfimethod[j]=strrfi;
                ptscale[j]=0;
                j++;
            }
            else if (strrfi=="zap1" || strrfi=="zap2")
            {
                pstrrfimethod[j]=strrfi;
                ptscale[j]=Se_CMD_Key_Num(argv, argc, "-rfi", 7,k+1);
                k++;
                j++;
            }
            else if (strrfi=="runMedian" || strrfi=="runMedian2")
            {
            	pstrrfimethod[j]=strrfi;
                ptscale[j]=Se_CMD_Key_Num(argv, argc, "-rfi", 0.08,k+1);
                k++;
                j++;
            }
        }
    }

    bool bolUseStdFile=false;
    bolUseStdFile=Se_CMD_Key_Exist(argv, argc, "-std");

    float dms=Se_CMD_Key_Num(argv, argc, "-dms", 1);
    float ddm=Se_CMD_Key_Num(argv, argc, "-ddm", 1);
    float dme=Se_CMD_Key_Num(argv, argc, "-dme", 2000);
    long int nbox=Se_CMD_Key_Num(argv, argc, "-nbox", 12);
    float snrloss=Se_CMD_Key_Num(argv, argc, "-snrloss", 0.15);
    double minw=Se_CMD_Key_Num(argv, argc, "-minw", 0.2e-3);
    SEQUENCE vthre(3);
    vthre(0)=0.3;
    vthre(1)=0.05;
    vthre(2)=Se_CMD_Key_Num(argv, argc, "-thre",1e-7,3);
//	float f1=Se_CMD_Key_Num(argv, argc, "-zap",0,1);
//	float f2=Se_CMD_Key_Num(argv, argc, "-zap",0,2);
    MATRIX2D mxEvents;
    string strgradrv="";
//	if (Se_CMD_Key_Exist(argv, argc, "-g"))
//		strgradrv=Se_CMD_Key_Val(argv, argc, "-g");

    //Read from share memory
    if (Se_CMD_Key_Exist(argv, argc, "-share"))
    {
        //The important informaiton are Fch, Foff, Nchans, Tsamp, Tstart, Nif,
        //Nsamples, Nbits
        _MEMINFO meminfo;
        ReadCounts(& meminfo, O_RDWR);
        long int Nseg=meminfo.Nseg;
        long int Nlen=meminfo.Nlen;
        long int Nsl=Nlen/Nseg;

        fil.Fch1=Se_CMD_Key_Num(argv, argc, "-fch1", 1800,1);
        fil.Foff=Se_CMD_Key_Num(argv, argc, "-foff", 0.5,1);
        fil.Nchans=Se_CMD_Key_Num(argv, argc, "-nch", 512,1);
        double Tsamp=Se_CMD_Key_Num(argv, argc, "-tsamp", 64e-6,1);
        fil.Tsamp=Tsamp;
        long int Nifs=Se_CMD_Key_Num(argv, argc, "-nif", 1,1);

        fil.Nifs=Nifs;
        fil.UseFrequencyTable=false;
        fil.Src_dej=0;
        fil.Src_raj=0;
        fil.Nbits=32;
        fil.Az_start=0;
        fil.Za_start=0;
        fil.Src_dej=0;
        fil.Src_raj=0;
        fil.Nsamples=Nsl/(Nifs*fil.Nchans);
        for (long int i=0; i<fil.Nchans; i++)
            fil.frequency_table[i]=fil.Fch1+i*fil.Foff;
        long int nsize=Nsl;


        //Start to allocate the header information
        void * add_p=NULL;
        long int header_size=sizeof(_MEMELEM)*Nseg;
        add_p=OpenSHM(SHM_INFO_FN, header_size);
        if (add_p==(void *)(-1)) exit(1);
        void * add_datap=OpenSHM(SHM_FN, Nlen*sizeof(FILTYPE));
        if (add_datap==(void *)(-1)) exit(1);
        //header pointer
        _MEMELEM * ph=(_MEMELEM *) (add_p);
        //data pointer
        while(true)
        {
            //loop over each segmentation of buffers
            for (long int i=0; i<Nseg; i++)
            {
                if(bolDebug) cout<<"Working on "<<i<<"-th segmentation."<<endl;
                //Find the Ready buffer
                if ((ph+i)->Status==RDY)
                {
                    (ph+i)->Status=RD;
                    fil.pData=new float [nsize];
                    FILTYPE * pd_proc= (FILTYPE *)(add_datap) + (ph+i)->Shifts;
                    if(bolDebug)
                    {
                        cout<<"Address"<<pd_proc<<endl;
                    }
                    double mjd=(ph+i)->MJD;
                    //Reload changed parameters
                    fil.Tstart=mjd;
                    fil.Nsamples=Nsl/(Nifs*fil.Nchans);
                    fil.Tsamp=Tsamp;
                    fil.Nifs=Nifs;
                    for(long int j=0; j<nsize; j++)
                        fil.pData[j]=pd_proc[j];

                    char outputname[4096];
                    char outputname_nodetect[4096];
                    sprintf(outputname, "%s_%.15f_%ld", "frb", mjd, i);
                    sprintf(outputname_nodetect, "%s_%.15f_%ld", "nondet", mjd, i);
                    strgradrv=outputname;
                    if (bolDebug)
                    {
                        //fil.PrintHeader();
                        cout<<"DM range"<<dms<<"\t"<<ddm<<"\t"<<dme<<endl;
                    }

                    SearchForFRB(fil, 0, -1, 0, -1, ds, pstrrfimethod, ptscale, rfiN, dms, ddm, dme, nbox,
                                 snrloss, minw, vthre,  strgradrv.c_str(), mxEvents, false, outputname_nodetect,0, bolUseStdFile);

                    if (mxEvents.Row!=0)
                    {
                        (ph+i)->Status=SAV;
                    }
                    else
                        (ph+i)->Status=EMPTY;

                    fil.Free();
                    pd_proc=NULL;
                }
            }
            //usleep(500);
        }
        exit(0);
    }
    //Read from the filter bank
    else
    {
        fil.ReadInHeader(Se_CMD_Key_Val(argv,argc, "-f"));
    }
    if (bolDebug) cout<<"Read in data"<<endl;


    long int starts=0, ends=-1;
    if (Se_CMD_Key_Exist(argv, argc, "-starts"))
    {
        starts=Se_CMD_Key_Num(argv, argc, "-starts",0);
        ends=Se_CMD_Key_Num(argv, argc, "-ends",-1);
    }
    else if (Se_CMD_Key_Exist(argv, argc, "-start"))
    {
        starts=fil.Nsamples*Se_CMD_Key_Num(argv, argc, "-start",0);
        ends=fil.Nsamples*Se_CMD_Key_Num(argv, argc, "-end",1);
    }

    long int fstarts=0, fends=-1;
    if (Se_CMD_Key_Exist(argv, argc, "-fstarts"))
    {
        fstarts=Se_CMD_Key_Num(argv, argc, "-fstarts",0);
        fends=Se_CMD_Key_Num(argv, argc, "-fends",-1);
    }
    else if (Se_CMD_Key_Exist(argv, argc, "-fstart"))
    {
        fstarts=(int)(Se_CMD_Key_Num(argv, argc, "-fstart", fil.frequency_table[0])-fil.Fch1)/fil.Foff;
        fends=(int)(Se_CMD_Key_Num(argv, argc, "-fend", fil.frequency_table[fil.Nchans-1])-fil.Fch1)/fil.Foff;
        if (fstarts > fends)
        {
        	int tmp = fstarts;
        	fstarts = fends;
        	fends = tmp;
        }
        if (fstarts<0) fstarts=0;
        if (fends>fil.Nchans) fends=-1;
    }
    if (bolDebug)
    {
        cout<<fil.FileName<<"\t"<<starts<<" "<<ends<<" "<<ds<<" ";
        cout<<"rfi"<<" ";
        for (long int i=0; i<rfiN; i++)
            cout<<pstrrfimethod[i].c_str()<<" "<<ptscale[i]<<" ";
        cout<<dms<<" "<<dme<<" "<<ddm<<" "<<nbox<<snrloss<<" "<<minw<<" "<<strgradrv;
        cout<<endl;
    }
    if (!Se_CMD_Key_Exist(argv, argc, "-all"))
    {
        char swap[1024];
        char swap2[1024];
        sprintf(swap,"%s_%.15lf", "FRB", fil.Tstart);
        sprintf(swap2,"%s_%.15lf", "non", fil.Tstart);
        strgradrv=swap;
        SearchForFRB(fil, starts, ends, fstarts, fends, ds, pstrrfimethod, ptscale, rfiN, dms, ddm, dme, nbox,
                     snrloss, minw, vthre,  strgradrv.c_str(), mxEvents, true, swap2, fil.Tstart, bolUseStdFile);

        //SaveToTextFile(mxEvents, Se_CMD_Key_Val(argv, argc, "-events"));
    }
    else
    { cout<<"No need -all"<<endl;
    exit(0);
//    	double maxdelay = abs(DMDelay(dme, fil.frequency_table[fil.Nchans-1], fil.frequency_table[0]));
//
//    	if (bolDebug) cout<<"seglen = "<<maxdelay<<endl;
//
//        long int SEGLEN=Se_CMD_Key_Num(argv, argc, "-seglen",1.0)/fil.Tsamp;
//    	//long int SEGLEN=Se_CMD_Key_Num(argv, argc, "-seglen", maxdelay)/fil.Tsamp;
//
//        MATRIX2D mxAllEvents;
//        long int nsamp_seg=SEGLEN*2;
//        long int nseg=fil.Nsamples/SEGLEN;
//        long int Ntots=fil.Nsamples;
//        long int Ncur=0;
//        long int starts=0;
//        for(long int iseg=0; iseg<nseg; iseg++)
//        {
//            if (bolDebug) cout<<"iseg="<<iseg<<endl;
//            ends=starts+nsamp_seg;
//            if (ends+Ncur>Ntots) ends=Ntots-Ncur;
//            if (ends<=0) break;
////			strsubgdrv+=".png/PNG";
////			double t0=SEGLEN*fil.Tsamp+fil.Tstart;
//            char swap[1024];
//            char swap2[1024];
//            sprintf(swap,"%s_%.15lf", "FRB", fil.Tstart);
//            sprintf(swap2,"%s_%.15lf", "non", fil.Tstart);
//
//            string strsubgdrv;
//            strsubgdrv=swap;
//            SearchForFRB(fil, starts, ends, fstarts, fends, ds, pstrrfimethod, ptscale, rfiN, dms, ddm, dme, nbox,
//                         snrloss, minw, vthre,  strsubgdrv.c_str(), mxEvents, true, swap2, fil.Tstart, bolUseStdFile);
//
//          //  long int orirow=mxAllEvents.Row;
//          //  mxAllEvents.Resize(mxAllEvents.Row+mxEvents.Row, mxEvents.Col);
//          //  mxAllEvents.SetPart(mxEvents, orirow,0);
//          //  Ncur+=SEGLEN;
//          //  starts=-SEGLEN;
//          //  fil.Tsamp=fil.Tsamp_ori;
//          //  fil.Nifs=fil.Nifs_ori;
//          //  fil.Tstart+=SEGLEN*fil.Tsamp/(3600*24.);
//          //  fil.Foff = fil.Foff_ori;
//          //  fil.Fch1 = fil.Fch1_ori;
//          //  fil.Nchans = fil.Nchans_ori;
//          //  memcpy(fil.frequency_table, fil.frequency_table_ori, sizeof(double)*16320);
//        }
        //SaveToTextFile(mxAllEvents, Se_CMD_Key_Val(argv, argc, "-events"));
    }
    if (pstrrfimethod != NULL && ptscale != NULL)
    {
        delete [] pstrrfimethod;
        delete [] ptscale;
    }
    fil.CloseFile();
    exit(0);
}

void SearchForFRB(FilterBankData & fil, long int starts, long int ends, long int fstarts, long int fends, long int ds, string * prfimethod, float * ptscale, long int rfiN, float dms, float ddm, float dme, long int nbox,
                  float snrloss, double minw, SEQUENCE & vthrep,  const char * gradrv, MATRIX2D & mxEventPar, bool bolreadfile, const char * fakegradrv, double t0, bool bolUseStd)
{
    if (bolreadfile)
//fil.ReadInDatabySample(starts, ends);
    cout<<"read start"<<endl;
    	fil.ReadInDatabySamplebyChan(starts, ends, fstarts, fends);
    cout<<"read end"<<endl;
    switch (fil.Nifs)
    {
    case 1:
    {
       // int pi[]= {0};
       // if (bolUseStd)
       //     fil.Strip2OnePol_STD(pi,1);
       // else
       //     fil.Strip2OnePol(pi,1);
       cout<<"comment Strip20nePol"<<endl;
        break;
    }
    case 2:
    {
        int pi[]= {0,1};
        if (bolUseStd)
            fil.Strip2OnePol_STD(pi,2);
        else
            fil.Strip2OnePol(pi,2);

        break;
    }
    case 4:
    {
        int pi[]= {0};
        if (bolUseStd)
            fil.Strip2OnePol_STD(pi,1);
        else
            fil.Strip2OnePol(pi,1);
        break;
    }
    default:
    {
        cout<<"Please Check the Nif"<<endl;
        exit(0);
    }
    }


  //  if (!fil.FormZeroDMSeriesandStatistics())
  //  {
  //  	return ;
  //  }

//    MATRIX2D mxEvents;
  
 //  delete [] pvt;
 //   delete [] pvdm;
 //   delete [] pvw;
cout <<"start creat dediprof"<<endl;
    SEQUENCE dediprof;
cout <<"end creat dediprof"<<endl;
    
    cout<<"dedispers start"<<endl;
    fil.Dedisperse(1523.25);
    cout<<"dedispers end"<<endl;
    GetProfile(dediprof, &fil);
    cout<<"write dedispsed data to file"<< endl;
    SaveToTextFile(dediprof,"dediprof.txt");
    cout<< "have been writen"<<endl;
    long int Nn = ceil(log(dediprof.n)/log(2));
    long int PowNn = pow(2,Nn);
    long int ik; 
    SE_LONG_DOUBLE val=0;
    //cout<<"Nn="<<Nn<<endl;
    //cout<<"2^Nn="<<(int)pow(2,Nn)<<endl;
    //exit(0);
    
    SEQUENCE real(PowNn); 
    for(ik=0;ik<dediprof.n;ik++)
    {
	   real.Set(ik,dediprof.Data(ik));
    }

    for(ik=dediprof.n;ik<PowNn;ik++)
    {
	   real.Set(ik,val);
    }
    //int aa=1915;
    //cout<<"log_2(aa)="<<ceil(log(aa)/log(2))<<endl;
    SEQUENCE power(PowNn);
    SEQUENCE phase(PowNn);
    SEQUENCE freq(PowNn);
    SEQUENCE Freq(PowNn>>1);
    SEQUENCE Power(PowNn>>1);

    long int Nsamp = fil.Nsamples;
    float Tsamp=fil.Tsamp; 
   
    SEQUENCE img(PowNn);
    for(ik=0;ik<PowNn;ik++)
    {
	   img.Set(ik,val);
	   freq.Set(ik,1.*(ik+1)/Tsamp/freq.n);
    }

    //cout<<"img.n="<<img.n<<endl;
    //cout<<"real.n="<<real.n<<endl;
    //cout<<"real.Data[10]="<<real.Data(10)<<endl;
    //cout<<"img.Data[10]="<<img.Data(10)<<endl;
    //printf("%s\n",typeid(real).name());//类型
    //printf("%s\n",typeid(img).name());//类型

    // for(ik=0;ik<real.n;ik++)
    //  {
    //	     cout<<"ik="<<ik<<endl;
    //	     cout<<"realData"<<real.Data(ik)<<endl;
   //    }

    bool succeed = Fft1d(real,img,1);
    if (succeed) cout<<"fft is successful"<<endl;
    bool result = Pow_Phase(real,img,power,phase);
    if (succeed) cout<<"power_phase is successful"<<endl;
    
    //cout<<"real.data"<<real.Data(10)<<endl;
    //cout<<"img.data"<<img.Data(10)<<endl;
    //cout<<"aha!580"<<endl;
     // for(ik=0;ik<freq.n;ik++)
     // {
     //cout<<"freq:"<<freq.Data(ik)<<endl; 
     // cout<<"power:"<<log(power.Data(ik))<<endl; 
     //cout<<"power:"<<log(power).Data(ik)<<endl; 
      //}
   
//     for(ik=0;ik<freq.n>>1;ik++)
//     {
//	     freq.Set(ik,freq.Data(ik));
//	     power.Set(ik,power.Data(ik));
//	     //cout<<"ik="<<ik<<endl;
//     }
//
//
//     for(ik=freq.n>>1;ik<freq.n;ik++)
//     {
//	     freq.Set(ik,val);
//	     power.Set(ik,val);
//	     //cout<<"ik="<<ik<<endl;
//     }
//


// cut half of freq and power
for(ik=0;ik<real.n>>1;ik++)
{
      Freq.Set(ik,freq.Data(ik));
      Power.Set(ik,power.Data(ik));
      //cout<<"ik="<<ik<<endl;
//  cout << "Freq:"<<log(Freq.Data(ik))/log(10.0)<<endl;
}
//================  cut span ===============
Freq = log(Freq)/log(10.0);
Power = log(Power)/log(10.0);


//long int cut; 
//for(ik=0;ik<Freq.n;ik++)
//{
//while((Freq.Data(ik)>=0)&&(Freq.Data(ik)<=1))
//	{
//	cut = ik;
//	break;
//	}
//}
//
//SEQUENCE FreQ(Freq.n-cut);
//SEQUENCE PoweR(Freq.n-cut);
//cout<<"cut"<<cut<<endl;
//cout<<"Freq(0)"<<Freq.Data(0)<<endl;
//for(ik=0;ik<FreQ.n;ik++)
//{
//	FreQ.Set(ik,Freq.Data(cut+ik));
//	PoweR.Set(ik,Power.Data(cut+ik));
//}
//
//================  cut span end ===============
//cout << "points number of Freq:"<<Freq.n<<endl;
////============================= plot fft ===================================
	char namestr[1024];
	//char filename=fil.FileName;
	//sprintf(namestr,"%s_fft",filename);
	string filname = fil.FileName;
	sprintf(namestr,"%s_fft",filname.c_str());
	string pngname;
	string psname;
	pngname+=namestr;
	psname+=namestr;
	pngname+=".png/TPNG";
	psname+=".ps/PS";
	if (cpgbeg(0,pngname.c_str(), 1, 1) != 1)
            exit(0);
        cpgask(0);
        cpgscr(0, 1,1,1);
        cpgscr(1, 0.5,0.5,0);
        cpgpap(20., 9./16);
//	cpgenv(Min((Nsamp-1)/2/Nsamp/Tsamp),Max((Nsamp-1)/2/Nsamp/Tsamp),Min(power),Max(power),0,-2);
	cpgsch(0);
//	cpgvstd();
	//cpgslw(20);
        // cpgsvp(0.1,0.9,0.2,0.6);
         VPlot(Freq,Power,"color=b,noxmargin,fontsize=10,xlab=log(Freq/Hz),ylab=log(Power)");
//         VPlot(log(Freq)/log(10.0),log(Power)/log(10.0),"color=b,noxmargin,fontsize=10,xlab=Freq(Hz),ylab=log(Power)");
	//SEQUENCE tmp;
	//tmp.New(2);
	//tmp(0) = 0;
	//tmp(1) = 1;
	//ylab=flux,fontsize=5,noxmargin,xlab=t (s)"
	cpgend();
   cout<<"Plotting"<<pngname<<endl; 

//==================================== end plot ==============================
//    if (bolDebug) cout<<"Free"<<endl;
//    fil.Free();
//    if (bolDebug) cout<<"Finishing"<<endl;
}


void DebugDump(FilterBankData & fil)
{
    MATRIX2D mxIft;
    mxIft.New(fil.Nsamples, fil.Nchans*fil.Nifs);
    long int k=0;
    for (long int i =0; i<fil.Nsamples; i++)
    {
        for (long int j=0; j<fil.Nchans*fil.Nifs; j++)
        {
            mxIft(i,j)=fil.pData[k];
            k++;
        }
    }
    SaveToTextFile(mxIft, "a.txt");

    MATRIX2D mxres;
    SEQUENCE vdm, vw, vt;
    SEQUENCE vt_snr, vdm_snr;
    SEQUENCE vsnr;
    DMvsSNR(vdm,vdm_snr, &fil);
    long int maxi=MaxIndex(vdm_snr);
    double OptDM=vdm(maxi);
   /////
   //////
   //////
   /////
   /////
   /////
   /////
   ////
   //
   // float obj1dptim;
   // obj1dptim = fil.Dedisperse(520);
   // cout<<"aha!607"<<obj1dptim<<endl;
   // exit(0);
   /////
   /////
   /////
   /////
   ///////
   /////
   ///// 
    SaveToTextFile(MatComb(&vdm, &vdm_snr), "dm_snr");

    DM_w_vsSNR(vdm, vw, mxres,& fil);
    SaveToTextFile(vdm, "vdm");
    SaveToTextFile(vw, "vw");
    SaveToTextFile(mxres, "mxdmw");
    t_SNR(vt, vsnr, & fil);
    long int maxti=MaxIndex(vsnr);
    double OptT=vt(maxti);

    SEQUENCE vsnr_w;
    vsnr_w=Zeros(mxres.Col);
    for (long int i=0; i<mxres.Col; i++)
        vsnr_w(i)=Max(mxres.ColVect(i));
    long int maxwi=MaxIndex(vsnr_w);
    double OptW=vw(maxwi);

    SaveToTextFile(MatComb(&vt,&vsnr), "t_snr");
    DM_t_vsSNR(vdm, vt, mxres, & fil);
    SaveToTextFile(vt, "vt");
    SaveToTextFile(mxres, "mxdmt");

    fil.FormDedisperseChannelData(OptDM);
    SEQUENCE vprof;
    GetProfile(vprof, &fil);
    SaveToTextFile(vprof, "vprof");
    SEQUENCE f_snr;
    SEQUENCE vf;
    GetfvsS(vf,f_snr, OptT, OptDM, OptW, &fil);
    SaveToTextFile(f_snr, "vsf");
    SaveToTextFile(vf, "vf");
}

void GraphicalOutPut(FilterBankData & fil, const string gdrv, const SEQUENCE & vthre, const MATRIX2D & mxevt, bool bolDebug, double t0)
{
    string outputname=gdrv;
    outputname+=".png/TPNG";
    //outputname+=".gif/VGIF";
    if(cpgbeg(0,outputname.c_str(), 1, 1) != 1)
        exit(0);
    cpgask(0);
    cpgscr(0, 1,1,1);
    cpgscr(1, 0,0,0);

    cpgpap(8.3, 1.41);

    SEQUENCE vdm, vw, vt;
    SEQUENCE vt_snr, vdm_snr;
    MATRIX2D mxdmw, mxdmt;
    SEQUENCE vsnr_w;
    SEQUENCE vprof;
    SEQUENCE vsf;
    SEQUENCE vf;
    if(bolDebug) cout<<"Calculte DMvsSNR"<<endl;
    DMvsSNR(vdm,vdm_snr, &fil);
    if(bolDebug) cout<<"OptDM"<<endl;
    long int maxdmi=MaxIndex(vdm_snr);
    double OptDM=vdm(maxdmi);
    if(bolDebug) cout<<"DM_w_vsSNR"<<endl;
    DM_w_vsSNR(vdm, vw, mxdmw,& fil);
    t_SNR(vt, vt_snr, & fil);
    if(bolDebug) cout<<"optT"<<endl;
    long int maxti=MaxIndex(vt_snr);
    double OptT=vt(maxti);

    vsnr_w=Zeros(mxdmw.Col);
    for (long int i=0; i<mxdmw.Col; i++)
        vsnr_w(i)=Max(mxdmw.ColVect(i));
    long int maxwi=MaxIndex(vsnr_w);
    double OptW=vw(maxwi);

    /*
    	{
            float fl=fil.frequency_table[fil.Nchans-1];
            float fh=fil.frequency_table[0];
            int pswi=pow(2,maxwi);
            int totdelay=round(fabs(DMDelay((float)vdm(maxdmi),fl,fh)/fil.Tsamp));
            cout<<"totdelay="<<totdelay<<endl;
            MATRIX2D mxsub;
            for (long int n=0,sumDM=0; n<fil.Nsubband; n++)
            {
                SubBandData * psub=fil.pSubband+n;
                sumDM+=psub->NDM;
                if (sumDM>=maxdmi)
                {
                    mxsub.New(psub->Nchans*fil.Nifs,psub->Nsamples);
                    for (long int i =0; i<psub->Nsamples; i++)
                    {
                        for (long int j=0; j<psub->Nchans*fil.Nifs; j++)
                        {
                            mxsub(j,i)=psub->pData[(maxti+i-pswi/2)*psub->Nchans*fil.Nifs+j];
                            //mxsub(j,i)=psub->pData[i*psub->Nchans*fil.Nifs+j];
                        }
                    }
                    cout<<"Nsamples="<<psub->Nsamples<<endl;
                    break;
                }
            //for (long int j=0; j<psub->NDM; j++)
            //{
            //}
            }
            cout<<"maxti="<<maxti<<endl;
            SaveToTextFile(mxsub, "mxsub.txt");
    	}
    */



    if(bolDebug) cout<<"DM_t_vsSNR"<<endl;
    DM_t_vsSNR(vdm, vt, mxdmt, & fil);

    if(bolDebug) cout<<"Form dedisp"<<endl;
    fil.FormDedisperseChannelData(OptDM);
    if(bolDebug) cout<<"Get Prof"<<endl;
    GetProfile(vprof, &fil);

    //SaveToTextFile(vprof,"vprof");

    if(bolDebug) cout<<"Get fvsS"<<endl;
    GetfvsS(vf,vsf, OptT, OptDM, OptW, &fil);

    if(bolDebug) cout<<"Plot"<<endl;

    //plot orignal data and t-SNR
    //	detection SNR
    //	T-SNR
    if(bolDebug) cout<<"SNR plot"<<endl;

    cpgsvp(0.4,0.9,0.45,0.55);
    VPlot(vt,vt_snr, "noxmargin,fontsize=5,xlab=t (s),ylab=S");
    VPlot(vt,Ones(vt)*vthre.Data(0), "color=b,holdon");
    VPlot(vt,Ones(vt)*vthre.Data(1), "color=g,holdon");
    VPlot(vt,Ones(vt)*vthre.Data(2), "color=r,holdon");


    if(bolDebug) cout<<"ori data plot"<<endl;
    //oridat
    MATRIX2D mxIft;
    mxIft.New(fil.Nchans*fil.Nifs, fil.Nsamples);
    long int k=0;
    for (long int i =0; i<fil.Nsamples; i++)
    {
        for (long int j=0; j<fil.Nchans*fil.Nifs; j++)
        {
            mxIft(j,i)=fil.pData[k];
            k++;
        }
    }

    cpgsvp(0.4, 0.9, 0.75,0.95);
    SEQUENCE vfo;

    long int Nf_down=mxIft.Row/Max(mxIft.Row/40,1);
    float dT_down=2e-3;
    float Tsamp=fil.Tsamp;
    long int NT_down=Max((long int)(dT_down/Tsamp),1);
    NT_down=NT_down<1?1:NT_down;
//	float BW=fil.Fch1;
    SEQUENCE vt_down=vt;
    vfo=vf;
    Se_DownSample_Average(vf, (long int )( (float)(mxIft.Row) / Nf_down ));
    Se_MatDownSample_Average(mxIft, (long int )( (float)(mxIft.Row) / Nf_down ), NT_down);
    Se_DownSample_Average(vt_down, NT_down);
    Se_PgPcolor(vt_down,vf, mxIft, "colormap=parula,nox,noy,fontsize=5");

    SEQUENCE fp, tp;
    fp=vf;
    tp=fp;
    float maxf=Max(fp);
    for (long int j=0; j<mxevt.Row; j++)
    {
        for (long int i=0; i<fp.n; i++)
            tp(i)=DMDelay(vdm(mxevt.Data(j,1)), fp(i), maxf)+ vt(mxevt.Data(j,0))-1e-2;
        VPlot(tp,fp, "line,holdon,color=w");
    }


    //t-dm-SNR
    if(bolDebug) cout<<"t-dm-SNR plot"<<endl;

    Se_MatDownSample_Average(mxdmt, 1, NT_down);
    cpgsvp(0.4,0.9,0.55,0.75);
    Se_PgPcolor(vt_down,vdm, mxdmt, "colormap=parula,ylab=DM,nox,fontsize=5,bar");
    for (long int i=0; i<mxevt.Row; i++)
    {
        char charswap[1024];
        OptT=vt((long int)(mxevt.Data(i,0)));
        OptDM=vdm((long int)(mxevt.Data(i,1)));
        SEQUENCE xp(1),yp(1);
        xp(0)=OptT;
        yp(0)=OptDM;
        sprintf(charswap, "s=907,holdon,nox,noy,color=r,symbolsize=%f", sqrt((float)(mxevt.Row-i)/(mxevt.Row))*7);
        VPlot(xp,yp, charswap);

    }

    //t-prof
    Se_DownSample_Average(vprof, NT_down);
    cpgsvp(0.4,0.9,0.35,0.45);
    VPlot(vt_down,vprof, "ylab=flux,fontsize=5,noxmargin,xlab=t (s)");

    //Plot f-Stat
    cpgsvp(0.1,0.25,0.75,0.95);
    if (fil.frequency_table[1]>fil.frequency_table[0])
        VPlot(vsf,vfo, "reversex,xlab=S,ylab=f (MHz),fontsize=5");
    else
        VPlot(vsf,vfo, "reversey,reversex,xlab=S,ylab=f (MHz),fontsize=5");

    //Plot f-dS
    cpgsvp(0.25,0.4,0.75,0.95);
    SEQUENCE vdfl, vdsf;
    vdfl=vfo.Part(1,vfo.n-1);
    vdsf=vdfl;
    for (long int i=0; i<vdsf.n; i++)
        vdsf(i)=vsf(i+1)-vsf(i);
    if (fil.frequency_table[1]>fil.frequency_table[0])
        VPlot(vdsf,vdfl, "reversex,noy,xlab=dS,fontsize=5");
    else
        VPlot(vdsf,vdfl, "reversey,reversex,noy,xlab=dS,fontsize=5");

    VPlot(Zeros(vdfl.n),vdfl, "holdon,reversey,reversex,color=r");

    //Plot DM-w-SNR
    //    DM-SNR
    cpgsvp(0.5, 0.9, 0.1, 0.15);
    VPlot(vdm, vdm_snr, "noymargin,fontsize=5,xlab=DM,ylab=S");
    VPlot(vdm,Ones(vdm)*vthre.Data(0), "color=b,holdon");
    VPlot(vdm,Ones(vdm)*vthre.Data(1), "color=g,holdon");
    VPlot(vdm,Ones(vdm)*vthre.Data(2), "color=r,holdon");
    // DM -W -SNR
    cpgsvp(0.5, 0.9, 0.15,0.30);
    Se_PgPcolor(vdm, log(vw)/log(10.0), mxdmw.T(), "noy,nox,colormap=parula,fontsize=5");
    for (long int i=0; i<mxevt.Row; i++)
    {
        char charswap [1024];
        OptW=log(vw((long int)(mxevt.Data(i,2))))/log(10.0);
        OptDM=vdm((long int)(mxevt.Data(i,1)));
        SEQUENCE xp(1),yp(1);
        xp(0)=OptDM;
        yp(0)=OptW;
        sprintf(charswap, "s=907,holdon,nox,noy,color=r,symbolsize=%f", sqrt((float)(mxevt.Row-i)/(mxevt.Row))*7);
        VPlot(xp,yp, charswap);
    }


    // W-SNR
    cpgsvp(0.4, 0.5, 0.15,0.30);
    VPlot(vsnr_w,log(vw)/log(10.0), "noymargin,fontsize=5,ylab=W,ylog,xlab=S");
    VPlot(Ones(vsnr_w)*vthre.Data(0),log(vw)/log(10.0), "color=b,holdon");
    VPlot(Ones(vsnr_w)*vthre.Data(1),log(vw)/log(10.0), "color=g,holdon");
    VPlot(Ones(vsnr_w)*vthre.Data(2),log(vw)/log(10.0), "color=r,holdon");

    //all candidates plot
    Se_PgText("Candidate Profile ", 0.12,0.67,0, "fontsize=7");

    for (long int i=0; i<mxevt.Row; i++)
    {
        float toth=0.6;
        float wi=toth/mxevt.Row;
        if (wi>0.15) wi=0.15;
        OptW=log(vw((long int)(mxevt.Data(i,2))))/log(10.0);
        OptDM=vdm((long int)(mxevt.Data(i,1)));
        if (bolDebug)
            cout<<"OptDM="<<OptDM<<endl;
        fil.Dedisperse(OptDM);
        GetProfile(vprof, &fil);
        Se_DownSample_Average(vprof, NT_down);
        cpgsvp(0.1,0.35,0.65-(i+1)*wi,0.65-(i)*wi);
        VPlot(vt_down,vprof, "ylab=flux,fontsize=5,noxmargin,xlab=t (s)");
    }

    char strtmpt0[4096];
    sprintf(strtmpt0, "%.15lf", t0);
    cpgsch(1.2);
    Se_PgText(fil.Source_name, 0.45,0.98,0, "fontsize=7");
    Se_PgText(strtmpt0, 0.6,0.98,0, "");
    cpgsch(0.7);
    cpgsvp(0.84,0.865,0.005,0.0225);
    THISISTHEVIPFUNCTION();
    //Se_PgText(" by K.J.Lee", 0.871, 0.01,0,"fontsize=8");
    cpgend();

}

//====================== Plot Candidates ==================
void CandGraphicalOutPut(FilterBankData & fil, float * pcube, float * pvt, float * pvdm, float * pvw, const SEQUENCE & vthre, const MATRIX2D & mxevt, double t0)
{

    if (bolDebug)
    {
        cout<<"Plot Candidates..."<<endl;
        cout<<"============Events list============="<<endl;
    }

    char t0str[1024];
    sprintf(t0str,"%s_%.15lf_Cand", "FRB", t0);

    for(long int k=0; k<mxevt.Row; k++)
    {
        if(bolDebug)
        {
            cout<<setw(10)<<mxevt.Data(k,0);
            cout<<setw(10)<<mxevt.Data(k,1);
            cout<<setw(10)<<mxevt.Data(k,2)<<endl;
        }

        string candstr;
        candstr+=t0str;
        char istr[16];
        sprintf(istr,"_%ld", k+1);
        candstr+=istr;

        //string ftmapstr=candstr;
        //ftmapstr+=".ftmap";

        candstr+=".png/PNG";

        //if(cpgopen(candstr.c_str()) <= 0)
        if (cpgbeg(0,candstr.c_str(), 1, 1) != 1)
            exit(0);
        cpgask(0);
        cpgscr(0, 1,1,1);
        cpgscr(1, 0,0,0);
        cpgpap(18, 9./16.);

        long int vdmi=mxevt.Data(k,1);

        double OptDM=pvdm[vdmi];
        fil.FormDedisperseChannelData(OptDM);
        double OptS=mxevt.Data(k,3);

        long int vwi=mxevt.Data(k,2);
        double OptW=pvw[vwi];
        int pswi=fil.vBin[vwi];
        MATRIX2D mxsub;
        SEQUENCE vprof_chop,vprof_zerodm;
        ///
        int plwi= 40*pswi;
        if (plwi > fil.Nsamples)
            plwi=fil.Nsamples;
        mxsub.New(fil.Nchans*fil.Nifs,plwi);
        vprof_chop.New(plwi);
        vprof_chop=Zeros(plwi);
        vprof_zerodm.New(plwi);
        vprof_zerodm=Zeros(plwi);
        SEQUENCE vprof_cand;
        GetProfile(vprof_cand, &fil);
        long int vti=mxevt.Data(k,0);
        double OptT=pvt[vti];

        SEQUENCE vt_chop;
        vt_chop.New(plwi);
        if (vti-plwi/2 >= 0 && vti+plwi/2-1 < fil.Nsamples)
        {
            for (long int i =0; i<plwi; i++)
            {
                vt_chop(i)=(i-plwi/2)*fil.Tsamp;
                long int ti=vti+i-plwi/2;
                vprof_zerodm(i)=fil.pZeroDM[ti];
                vprof_chop(i)=vprof_cand.Data(ti);

                for (long int j=0; j<fil.Nchans*fil.Nifs; j++)
                {
                    mxsub(j,i)=fil.Obj.pData[ti*fil.Obj.Nchans*fil.Nifs+j];
                }
            }
        }
        else if (vti-plwi/2 < 0 && vti+plwi/2-1 < fil.Nsamples)
        {
            for (long int i =0; i<plwi; i++)
            {
                vt_chop(i)=(i-vti)*fil.Tsamp;
                long int ti=i;
                vprof_zerodm(i)=fil.pZeroDM[ti];
                vprof_chop(i)=vprof_cand.Data(ti);

                for (long int j=0; j<fil.Nchans*fil.Nifs; j++)
                {
                    mxsub(j,i)=fil.Obj.pData[ti*fil.Obj.Nchans*fil.Nifs+j];
                }
            }
        }
        else if (vti-plwi/2 >= 0 && vti+plwi/2-1 >= fil.Nsamples)
        {
            for (long int i =0; i<plwi; i++)
            {
                vt_chop(i)=(i-(vti+plwi-fil.Nsamples))*fil.Tsamp;
                long int ti=fil.Nsamples-plwi+i;
                vprof_zerodm(i)=fil.pZeroDM[ti];
                vprof_chop(i)=vprof_cand.Data(ti);

                for (long int j=0; j<fil.Nchans*fil.Nifs; j++)
                {
                    mxsub(j,i)=fil.Obj.pData[ti*fil.Obj.Nchans*fil.Nifs+j];
                }
            }
        }

        //SaveToTextFile(mxsub, ftmapstr.c_str());

        Se_MatDownSample_Average(mxsub, 8, 1);
        SEQUENCE vf_down, vf, vsf;
        GetfvsS(vf, vsf, OptT, OptDM, OptW, &fil);
        /*
                vf.New(fil.Nchans);
                for (long int i=0;i<fil.Nchans;i++)
                {
                    vf(i)=fil.frequency_table[i];
                }
        */
        vf_down=vf;
        Se_DownSample_Average(vf_down, 8);

        cpgsvp(0.05,0.45,0.41,0.77);
        Se_PgPcolor(vt_chop,vf_down, mxsub, "colormap=parula,nox,ylab=f (MHz),fontsize=5");
        cpgsvp(0.05,0.45,0.77,0.95);
        VPlot(vt_chop,vprof_chop, "ylab=flux,fontsize=5,noxmargin,nox");

        SEQUENCE xp(1),yp(1);
        xp(0)=0;
        yp(0)=0;
        VPlot(xp,yp, "s=907,holdon,nox,noy,color=r,symbolsize=10");
//======================== Plot pZeroDM ===============================
        cpgsvp(0.58,0.95,0.44,0.58);
        VPlot(vt_chop,vprof_zerodm, "ylab=flux,xlab=t (s),fontsize=5");
        xp(0)=0;
        yp(0)=0;
        VPlot(xp,yp, "s=907,holdon,nox,noy,color=r,symbolsize=10");
//======================== Plot f-S and f-ds ===================================
        //Plot f-Stat
        cpgsvp(0.45,0.5,0.41,0.77);
        if (fil.frequency_table[1]>fil.frequency_table[0])
            VPlot(vsf,vf, "xlab=S,noy,fontsize=5");
        else
            VPlot(vsf,vf, "reversey,xlab=S,noy,fontsize=5");

        //Plot f-dS
        cpgsvp(0.5,0.55,0.41,0.77);
        SEQUENCE vdfl, vdsf;
        vdfl=vf.Part(1,vf.n-1);
        vdsf=vdfl;
        for (long int i=0; i<vdsf.n; i++)
            vdsf(i)=vsf(i+1)-vsf(i);
        if (fil.frequency_table[1]>fil.frequency_table[0])
            VPlot(vdsf,vdfl, "noy,xlab=dS,fontsize=5");
        else
            VPlot(vdsf,vdfl, "reversey,noy,xlab=dS,fontsize=5");

        VPlot(Zeros(vdfl.n),vdfl, "holdon,reversey,reversex,color=r");

//======================== Plot DM-t_S ================================
//        long int plvdm=2*pvw[vwi]*pow(fil.Fch1,3)/(8300.*abs(fil.Foff))/(pvdm[fil.Ndm-1]-pvdm[0])*fil.Ndm;
//        long int plvt=2*fil.Nchans*pswi;
        long int plvdm=200;
        if (plvdm > fil.Ndm)
            plvdm=fil.Ndm;
        long int plvt=plwi;
        SEQUENCE vt_dm,vdm_t;
        vt_dm=vt_chop;
        vdm_t.New(plvdm);

        MATRIX2D mxtdm;
        mxtdm.New(plvdm,plvt);

        for(long int i=0; i<plvdm; i++)
        {
            long int dmi=0;
            if (vdmi-plvdm/2 >= 0 && vdmi+plvdm/2-1 < fil.Ndm)
            {
                dmi=vdmi+i-plvdm/2;
                vdm_t(i)=pvdm[dmi];
            }
            else if (vdmi-plvdm/2 < 0 && vdmi+plvdm/2-1 < fil.Ndm)
            {
                dmi=i;
                vdm_t(i)=pvdm[dmi];
            }
            else if (vdmi-plvdm/2 >= 0 && vdmi+plvdm/2-1 >= fil.Ndm)
            {
                dmi=fil.Ndm-plvdm+i;
                vdm_t(i)=pvdm[dmi];
            }

            if (vti-plvt/2 >= 0 && vti+plvt/2-1 < fil.Nsamples)
            {
                for(long int j=0; j<plvt; j++)
                {
                    long int ti=vti+j-plvt/2;
                    mxtdm(i,j)=pcube[dmi*fil.Nbox*fil.Nsamples+vwi*fil.Nsamples+ti];
                }
            }
            else if (vti-plvt/2 < 0 && vti+plvt/2-1 < fil.Nsamples)
            {
                for(long int j=0; j<plvt; j++)
                {
                    long int ti=j;
                    mxtdm(i,j)=pcube[dmi*fil.Nbox*fil.Nsamples+vwi*fil.Nsamples+ti];
                }
            }
            else if (vti-plvt/2 >= 0 && vti+plvt/2-1 >= fil.Nsamples)
            {
                for(long int j=0; j<plvt; j++)
                {
                    long int ti=fil.Nsamples-plvt+j;
                    mxtdm(i,j)=pcube[dmi*fil.Nbox*fil.Nsamples+vwi*fil.Nsamples+ti];
                }
            }
        }

        cpgsvp(0.05,0.45,0.05,0.41);
        Se_PgPcolor(vt_dm, vdm_t, mxtdm, "xlab=t (s),ylab=DM (cm^-3 pc),colormap=parula,fontsize=5");
        xp(0)=0;
        yp(0)=OptDM;
        VPlot(xp,yp, "s=907,holdon,nox,noy,color=r,symbolsize=10");
//======================== Plot DM_S ==============================
        SEQUENCE vdmcand;
        vdmcand.New(fil.Ndm);
        SEQUENCE vdmcand_snr;
        vdmcand_snr.New(fil.Ndm);
        for(long int i=0; i<fil.Ndm; i++)
        {
            vdmcand(i)=pvdm[i];
            vdmcand_snr(i)=pcube[i*fil.Nbox*fil.Nsamples+vwi*fil.Nsamples+vti];
        }
        cpgsvp(0.55,0.85,0.05,0.15);
        VPlot(vdmcand,vdmcand_snr, "xlab=DM (cm^-3 pc),ylab=S,fontsize=5,noxmargin");
        VPlot(vdmcand,Ones(vdmcand)*vthre.Data(0), "color=b,holdon");
        VPlot(vdmcand,Ones(vdmcand)*vthre.Data(1), "color=g,holdon");
        VPlot(vdmcand,Ones(vdmcand)*vthre.Data(2), "color=r,holdon");
//======================== Plot W-S ================================
        SEQUENCE vwcand;
        vwcand.New(fil.Nbox);
        SEQUENCE vwcand_snr;
        vwcand_snr.New(fil.Nbox);
        for(long int i=0; i<fil.Nbox; i++)
        {
            vwcand(i)=pvw[i];

            //cout<<"vbin="<<pvw[i]<<endl;

            vwcand_snr(i)=pcube[vdmi*fil.Nbox*fil.Nsamples+i*fil.Nsamples+vti];
        }
        cpgsvp(0.5,0.55,0.15,0.39);
        VPlot(vwcand_snr,log(vwcand)/log(10.0), "xlab=S,ylab=W (s),ylog,fontsize=5,noymargin");
        VPlot(Ones(vwcand_snr)*vthre.Data(0),log(vwcand)/log(10.0), "color=b,holdon");
        VPlot(Ones(vwcand_snr)*vthre.Data(1),log(vwcand)/log(10.0), "color=g,holdon");
        VPlot(Ones(vwcand_snr)*vthre.Data(2),log(vwcand)/log(10.0), "color=r,holdon");
//======================== Plot DM-W_S ================================
        MATRIX2D dmwcand_snr;
        dmwcand_snr.New(fil.Nbox,fil.Ndm);
        for(long int j=0; j<fil.Ndm; j++)
        {
            for(long int i=0; i<fil.Nbox; i++)
            {
                dmwcand_snr(i,j)=pcube[j*fil.Nbox*fil.Nsamples+i*fil.Nsamples+vti];
            }
        }
        cpgsvp(0.55,0.85,0.15,0.39);
        Se_PgPcolor(vdmcand, log(vwcand)/log(10.0), dmwcand_snr, "noy,nox,colormap=parula,fontsize=5");
        xp(0)=OptDM;
        yp(0)=log(OptW)/log(10.0);
        VPlot(xp,yp, "s=907,holdon,nox,noy,color=r,symbolsize=10");
//======================== Form pcube2 =================================
        SEQUENCE pvindex2,pvdm2,pvw2;

        float * pcube2=FormSCube2(&fil, pvindex2, pvdm2, pvw2, vti, vdmi);
        for(long int i=0; i<pvw2.n; i++) pvw2(i)*=1000;

//======================== Plot Index-DM_S =============================
        MATRIX2D index_dm;
        index_dm.New(pvdm2.n,pvindex2.n);
        SEQUENCE pindexS;
        pindexS.New(pvindex2.n);
        long int maxindi=0;
        double maxindS=0;
        for (long int i=0; i<pvindex2.n; i++)
        {
            float maxs=0;
            for (long int j=0; j<pvdm2.n; j++)
            {
                float maxw=0;
                for (long int k=0; k<pvw2.n; k++)
                {
                    if (pcube2[i*pvdm2.n*pvw2.n+j*pvw2.n+k] > maxw)
                    {
                        maxw=pcube2[i*pvdm2.n*pvw2.n+j*pvw2.n+k];
                    }
                }
                index_dm(j,i)=maxw;
                maxs=maxw>maxs?maxw:maxs;
            }
            pindexS(i)=maxs;
            if (maxs > maxindS)
            {
                maxindS=maxs;
                maxindi=i;
            }
        }
        double maxind=pvindex2(maxindi);

        cpgsvp(0.8825,0.95,0.27,0.39);
        Se_PgPcolor(pvindex2, pvdm2, index_dm, "ylab=DM (cm^-3 pc),nox,colormap=parula,fontsize=5");
//======================== Plot Index-W_S =============================
        MATRIX2D index_w;
        index_w.New(pvw2.n, pvindex2.n);
        float * maxdm=new float [pvw2.n];
        for (long int i=0; i<pvindex2.n; i++)
        {
            for (long int l=0; l<pvw2.n; l++) maxdm[l]=0;
            for (long int j=0; j<pvdm2.n; j++)
            {
                for (long int k=0; k<pvw2.n; k++)
                {
                    if (pcube2[i*pvdm2.n*pvw2.n+j*pvw2.n+k] > maxdm[k])
                    {
                        maxdm[k]=pcube2[i*pvdm2.n*pvw2.n+j*pvw2.n+k];
                    }
                }
            }
            for (long int k=0; k<pvw2.n; k++)
            {
                index_w(k,i)=maxdm[k];
            }
        }
        delete [] maxdm;
        cpgsvp(0.8825,0.95,0.15,0.27);
        Se_PgPcolor(pvindex2, pvw2, index_w, "ylab=W (ms),nox,colormap=parula,fontsize=5");

//======================== Plot Index_S ==================================
        cpgsvp(0.8825,0.95,0.05,0.15);
        VPlot(pvindex2,pindexS,"xlab=DM Index,ylab=S,fontsize=5,noymargin");

        delete [] pcube2;
//======================== Write Info ==================================
        long int Sco=Score(vt_chop, mxsub, OptW, OptS, pvindex2, pindexS);

        if (bolInfo)
        {
            char fname[1024];
            sprintf(fname,"%s_%.15lf", "FRB", t0);
            WriteInfo(fname, fil, k, OptT, OptDM, OptW, vti, vdmi, vwi, OptS, Sco, maxind);
        }
//======================== Plot text ==================================
        cpgsch(1);
        char tmp[1024];
        sprintf(tmp,"%s:%d","Telescope",fil.Telescope_id);
        Se_PgText(tmp, 0.6,0.93,0, "fontsize=10");
        sprintf(tmp,"%s:%lf","RA (J2000)",fil.Src_raj);
        Se_PgText(tmp, 0.6,0.894,0, "fontsize=10");
        sprintf(tmp,"%s:%lf","DEC (J2000)",fil.Src_dej);
        Se_PgText(tmp, 0.6,0.858,0, "fontsize=10");
        sprintf(tmp,"%s:%lf","AZ",fil.Az_start);
        Se_PgText(tmp, 0.6,0.822,0, "fontsize=10");
        sprintf(tmp,"%s:%lf","ZA",fil.Za_start);
        Se_PgText(tmp, 0.6,0.786,0, "fontsize=10");

        sprintf(tmp,"%s:%.15lf","T (MJD)",t0+OptT/(3600*24.));
        Se_PgText(tmp, 0.6,0.75,0, "fontsize=10");
        sprintf(tmp,"%s:%lf","DM (cm^{-3} pc)",OptDM);
        Se_PgText(tmp, 0.6,0.714,0, "fontsize=10");

        sprintf(tmp,"%s:%lf","DM Index",maxind);
        Se_PgText(tmp, 0.6,0.678,0, "fontsize=10");

        sprintf(tmp,"%s:%f","Width (ms)",1000*OptW);
        Se_PgText(tmp, 0.6,0.642,0, "fontsize=10");
        sprintf(tmp,"%s:%lf","SNR",mxevt.Data(k,3));
        Se_PgText(tmp, 0.6,0.606,0, "fontsize=10");

        sprintf(tmp,"%s:%ld","Score",Sco);
        Se_PgText(tmp, 0.85,0.606,0, "fontsize=10");

        cpgsch(0.7);
        cpgsvp(0.48,0.52,0.01,0.07);
        THISISTHEVIPFUNCTION();
        //cpgclos();
        cpgend();

    }

}

void printhelp(int argc, char * argv[])
{
    cout<<"Usage :"<<endl;
    cout<<argv[0]<<" [arguments]"<<endl;
    cout<<"Where:"<<endl;
    cout<<
        "   [-h]                     Print help info\n"<<
        "\n"<<
        "   -f  input                Input filterbank file \n"<<
//	    "   -z                       Use zero-DM RFI filter \n"<<
//	    "   -zdot                    Use dot-DM RFI filter \n"<<
        "   -rfi [[zdot][z][zap1 n]] Use RFI filter	\n"<<

        "   [-dms]      [1   ]       Dispersion Start value\n"<<
        "   [-ddm]      [1   ]       Dispersion Step value\n"<<
        "   [-dme]      [2000]       Dispersion End value\n"<<

        "   [-minw]     [2e-4]       Minimal width to start\n"<<
        "   [-nbox]     [12]         Number of boxcar filter\n"<<
        "   [-snrloss]  [0.15]       Tolerent SNR loss for boxcar\n"<<

        "   [-ds]       [20]         Downsampling rate\n"<<
        "   -o                       Output filterbank files\n"<<
        "\n"<<
        "   [-info]                  Save info data\n"<<
        "   [-scube]                 Save Scube data\n"<<
        "   [-debug]                 Debug informaiton\n"<<
        "   [-cand]                  Save candidate figures\n"<<
        "   [-start]    [0]          Percentage to start\n"<<
        "   [-end]      [1]          Percentage to end\n"<<
        "   [-starts]   [0]          The starting sample\n"<<
        "   [-ends]     [-1]         The ending sample, -1 will read in all\n"<<
        "\n"<<
        "   [-d]                     Dump the downsampled and baseline removed data to a new fil\n"
        "   [-thre] [0.3 0.05 1e-7]  Statistical threshold\n"<<
//			"   -g  a.png/PNG            Plot with given graphical driver\n"<<
        "   [-debugdump]             Dump debug text files\n"<<
        "   -events                  Write Events file\n"<<
        "\n"<<
        "   [-all]                   Read data in segments with length [-seglen] with -g not used\n"<<
        "   [-seglen]   [1]          Segment length (s)\n"<<
        "\n"<<
        "   [-share]                 Read data from shared memory structure\n"<<
        "      -fch1                 Frequency of first channel [1800 Mhz]\n"<<
        "      -foff                 Channel width [0.5]\n"<<
        "      -nch                  Number of channel [512]\n"<<
        "      -tsamp                Sampling time scale [64e-6]\n"<<
        "      -nif                  Number of inter-channels\n"<<
        endl;
}

void THISISTHEVIPFUNCTION(void)
{
    float pandax[]= {162, 165, 180, 202, 231, 259, 299, 341, 368, 396, 417, 428, 440, 451, 451, 446, 432, 410, 387, 352, 319, 282, 254, 225, 197, 180, 165, 161, 163, 169, 150, 153, 170, 192, 213, 225, 237, 244, 375, 396, 420, 443, 456, 466, 471, 469, 461, 450, 293, 326, 275, 285, 292, 310, 313, 337, 343, 221, 231, 253, 271, 286, 299, 289, 274, 255, 234, 224, 223, 228, 326, 336, 355, 382, 400, 400, 389, 371, 351, 337, 321, 328, 339, 259, 266, 358, 366};
    float panday[]= {376.5, 406.5, 438, 466.5, 483, 492, 499.5, 493.5, 486, 475.5, 465, 448.5, 426, 397.5, 376.5, 349.5, 321, 298.5, 283.5, 271.5, 265.5, 265.5, 274.5, 288, 306, 327, 354, 378, 399, 427.5, 459, 490.5, 513, 517.5, 517.5, 514.5, 502.5, 493.5, 486, 516, 520.5, 516, 502.5, 484.5, 469.5, 447, 433.5, 417, 346.5, 343.5, 312, 300, 300, 309, 300, 300, 310.5, 402, 423, 438, 436.5, 426, 393, 378, 366, 366, 373.5, 391.5, 403.5, 423, 400.5, 421.5, 432, 429, 411, 385.5, 373.5, 363, 363, 373.5, 393, 417, 429, 397.5, 397.5, 396, 396};
    cpgswin(150,471,265.5,520.5);
    cpgsci(1);
    cpgline(29, pandax,panday);
    cpgline(-30+38+1,pandax+30-1, panday+30-1);
    cpgline(-39+48+1,pandax+39-1, panday+39-1);
    cpgline(-49+50+1,pandax+49-1, panday+49-1);
    cpgline(-51+57+1,pandax+51-1, panday+51-1);
    cpgline(-58+70+1,pandax+58-1, panday+58-1);
    cpgline(-71+83+1,pandax+71-1, panday+71-1);
    cpgline(-84+85+1,pandax+84-1, panday+84-1);
    cpgline(-86+87+1,pandax+86-1, panday+86-1);
}
