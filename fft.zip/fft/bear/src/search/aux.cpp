/**\brief
 *
 * =====================================================================================
 *
 *       Filename:  aux.cpp
 *
 *    Description:  auxiliary functions
 *
 *        Version:  1.0
 *        Created:  2014年12月17日 17时28分04秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  K.J.Lee (),
 *   Organization:
 *
 * =====================================================================================
 */
#include "aux.h"

#include <time.h>

void DMvsSNR(SEQUENCE & vdm, SEQUENCE & snr, FilterBankData * pfil)
{
    vdm.New(pfil->Ndm);
    snr.New(pfil->Ndm);
    long int n=0;
    for (long int i=0; i<pfil->Nsubband; i++)
    {
        SubBandData * psub=pfil->pSubband+i;
        for (long int j=0; j<psub->NDM; j++)
        {
            TimeSeries * ptim=psub->pTim+j;
            TimeSeries * ftpt=(ptim->plink);
            double maxv=ftpt->ptim[0];
            for (long int k=0; k<ptim->Nbox; k++)
            {
                for (long int l=0; l<(ftpt+k)->Nsamples; l++)
                {
                    if (maxv<(ftpt+k)->ptim[l])
                        maxv=(ftpt+k)->ptim[l];
                }
            }
            vdm(n)=psub->pDM[j];
            snr(n)=maxv;
            n++;
        }
    }
}

void DM_w_vsSNR(SEQUENCE & vdm, SEQUENCE & vw, MATRIX2D & res, FilterBankData * pf)
{
    res.New(pf->Ndm, pf->Nbox);
    vw.New(pf->Nbox);
    vdm.New(pf->Ndm);
    long int n=0;
    for (long int i=0; i<pf->Nsubband; i++)
    {
        SubBandData * psub=pf->pSubband+i;
        for (long int j=0; j<psub->NDM; j++)
        {
            TimeSeries * ptim=psub->pTim+j;
            for (long int k=0; k<ptim->Nbox; k++)
            {
                TimeSeries * ftpt=(ptim->plink+k);
                float * pt=ftpt->ptim;
                long int m=ftpt->Nsamples;
                float maxv=pt[0];
                for (long int l=0; l<m; l++)
                {
                    maxv=maxv>pt[l]?maxv:pt[l];
                }
                res(n,k)=maxv;
                vdm(n)=psub->pDM[j];
                vw(k)=pf->vBin[k]*pf->Tsamp;
            }
            n++;
        }
    }
}

void t_SNR(SEQUENCE & vt, SEQUENCE & vsnr, FilterBankData * pf)
{
    vt.New(pf->Nsamples);
    vsnr.New(pf->Nsamples);
    for(long int i=0; i<pf->Nsamples; i++)
    {
        vt(i)=i*pf->Tsamp;
        vsnr(i)=pf->pSubband->pTim->plink->ptim[i];
    }

    for (long int i=0; i<pf->Nsubband; i++)
    {
        SubBandData * psub=pf->pSubband+i;
        for (long int j=0; j<psub->NDM; j++)
        {
            TimeSeries * ptim=psub->pTim+j;
            TimeSeries * ftpt=(ptim->plink);
            for (long int k=0; k<ptim->Nbox; k++)
            {
                float * pt=(ftpt+k)->ptim;
                for (long int l=0; l<(ftpt+k)->Nsamples; l++)
                {
                    if (vsnr(l)<pt[l])
                        vsnr(l)=pt[l];
                }
            }
        }
    }
}
void DM_t_vsSNR(SEQUENCE & vdm, SEQUENCE & vt, MATRIX2D & res, FilterBankData * pf)
{
    res=Zeros(pf->Ndm, pf->Nsamples);
    vt.New(pf->Nsamples);
    vdm.New(pf->Ndm);
    for(long int i=0; i<pf->Nsamples; i++)
        vt(i)=i*pf->Tsamp;

    long int n=0;
    for (long int i=0; i<pf->Nsubband; i++)
    {
        SubBandData * psub=pf->pSubband+i;
        for (long int j=0; j<psub->NDM; j++)
        {
            //Get to the particular DM trial
            TimeSeries * ptim=psub->pTim+j;
            //l is the time index
            TimeSeries * ftpt=(ptim->plink);
            float * pt=ftpt->ptim;
            for (long int l=0; l<pf->Nsamples; l++)
            {
                if (l<ftpt->Nsamples)
                    res(n,l)=pt[l];
                else
                    res(n,l)=pt[ftpt->Nsamples-1];
            }

            for (long int k=1; k<ptim->Nbox; k++)
            {
                for (long int l=0; l<(ftpt+k)->Nsamples; l++)
                {
                    if (res(n,l)<(ftpt+k)->ptim[l])
                        res(n,l)=(ftpt+k)->ptim[l];
                }
            }

            vdm(n)=psub->pDM[j];
            n++;
        }
    }
}
/**\brief calculate the statistical threshold of statistics
 * \param n the number of tries, i.e. Nsample*Ndm*Nbox
 * \param p the threshold of probability, i.e. 1e-3, 1e-4 etc.*/
double GetStatThreshold(double n, double p)
{
    double x=1;
    for (char i=0; i<40; i++)
        x=2*log(n)-0.4516-log(x)-2.*log(p);
    return x;
}

/**\brief
 *
 * ===  FUNCTION  ======================================================================
 *         Name:  CountDOF
 *  Description:
 * =====================================================================================
 */
long int CountDOF (FilterBankData * pfil, long int nbox, double minw, double snrloss)
{
    float step=pow(snrloss+1.0,4.0);
    float pre=minw;
    long int nchunk=pre/pfil->Tsamp;
    double dof=0;
    if (nchunk<1)
    {
        nchunk=1;
        pre=pfil->Tsamp;
    }
    dof+=(pfil->Nsamples)*pfil->Ndm/nchunk;
    //cout<<dof<<endl;
    //cout<<pfil->Nsamples<<"\t"<<pfil->Ndm<<endl;
    //forming the step of boxcar filter
    for (long int i=1; i<nbox; i++)
    {
        pre*=step;
        //cout<<"pre="<<pre<<endl;
        nchunk=round(pre/pfil->Tsamp);
        //cout<<"nchunk="<<nchunk<<endl;
        dof+=(pfil->Nsamples)*(pfil->Ndm)/nchunk;
        //cout<< (pfil->Nsamples)*(pfil->Ndm)/nchunk<<endl;
    }
    return dof;
}		/* -----  end of function CountDOF  ----- */

void GetProfile(SEQUENCE & prof, FilterBankData * pfil)
{
    prof.New(pfil->Obj1D.Nsamples);
    for (long int i=0; i<prof.n; i++)
    {
        prof(i)=pfil->Obj1D.ptim[i];
    }
}
void GetfvsS(SEQUENCE & vf, SEQUENCE & s, double t, double dmv, double w, FilterBankData * pfil)
{
    s.New(pfil->Nchans);
    vf.New(pfil->Nchans);
//    int fti;
    double maxf=pfil->frequency_table[0];
    for(long int i=0; i<pfil->Nchans; i++)
    {
        maxf=maxf>pfil->frequency_table[i]?maxf:pfil->frequency_table[i];
    }
//    double ib=t/pfil->Tsamp;

//    int maxdelay=0;
    long int ileft, iright;
    double res=0;
    long int dn=round(w/pfil->Tsamp);

    double frac=1.0/(dn*pfil->Sig_0DM);
    for (long int ich=0; ich<s.n; ich++)
    {
        vf(ich)=pfil->frequency_table[ich];
        ileft=round( (t+ DMDelay(dmv, pfil->frequency_table[ich], maxf)-w*0.5)/pfil->Tsamp );
        iright=round( (t+ DMDelay(dmv, pfil->frequency_table[ich], maxf)+w*0.5)/pfil->Tsamp );
        //confine the boundary
        ileft=ileft<0?0:ileft;
        iright=iright>pfil->Nsamples-1?pfil->Nsamples-1:iright;
        double mean=0;
        for (long int i=0; i<pfil->Nsamples; i++)
            mean+=pfil->pData[i*pfil->Nchans*pfil->Nifs + ich*pfil->Nifs+0];
        mean/=pfil->Nsamples;
        double tmp;
        for (long int i=ileft; i<iright; i++)
        {
            tmp=pfil->pData[i*pfil->Nchans*pfil->Nifs + ich*pfil->Nifs+0]-mean;
            res+=tmp;
        }
        s(ich)=res*res*frac;
    }
}
bool GetParVec(FilterBankData * pf, SEQUENCE & vdm, SEQUENCE & vw, SEQUENCE & vt)
{
    vt=Series(0,1,pf->Nsamples-1)*pf->Tsamp;
    vdm.New(pf->Ndm);
    vw.New(pf->Nbox);
    long int k=0;
    for (long int i=0; i<pf->Nsubband; i++)
    {
        SubBandData * psub=pf->pSubband+i;
        for (long int j=0; j<psub->NDM; j++)
        {
            vdm(k)=psub->pDM[j];
            k++;
        }
    }
    for (long int k=0; k<pf->Nbox; k++)
    {
        vw(k)=pf->vBin[k]*pf->Tsamp;
    }
    return true;
}
/*
float * FormSCube(FilterBankData * pfil)
{
	FilterBankData * pf=pfil;
	float * pto=new float [pf->Ndm*pf->Nbox*pf->Nsamples];
	//SEQUENCE tmp;
	//tmp.New(pf->Ndm*pf->Nbox*pf->Nsamples);
	//cout<<pf->Ndm<<endl;
	//cout<<pf->Nbox<<endl;
	//cout<<pf->Nsamples<<endl;
	long int ichan=0;
	for (long int i=0; i<pf->Nsubband; i++)
	{
		SubBandData * psub=pf->pSubband+i;
		for (long int j=0; j<psub->NDM; j++)
		{
			//Get to the particular DM trial
			TimeSeries * ptim=psub->pTim+j;
			//l is the time index
			for (long int isamp=0; isamp<pf->Nsamples; isamp++)
			{
				float maxv;
				TimeSeries * ftpt=(ptim->plink);
				float * pt=ftpt->ptim;
				for (long int ibox=0; ibox<ptim->Nbox; ibox++)
				{
					float *objpt=pto+ibox*(pf->Ndm)*(pf->Nsamples) + ichan*(pf->Nsamples) +isamp;
					if (isamp<(ftpt+ibox)->Nsamples)
					{
						objpt[0]=(ftpt+ibox)->ptim[isamp];
						//tmp( ibox*(pf->Ndm)*(pf->Nsamples) + ichan*(pf->Nsamples)
						//+isamp)=objpt[0];
					}
					else
					{
						objpt[0]=0;
						//tmp(ibox*(pf->Ndm)*(pf->Nsamples) + ichan*(pf->Nsamples)
						//+isamp)=0;
					}
					//cout<<objpt[0]<<endl;
				}
			}
			ichan++;
		}
	}
	//SaveToTextFile(tmp, "lala");
	return pto;
}
*/

float * FormSCube(FilterBankData * pfil, float * pvt, float * pvdm, float * pvw)
{
    float * pcube=new float [pfil->Ndm*pfil->Nbox*pfil->Nsamples];

    for(long int i=0; i<pfil->Nsamples; i++)
        pvt[i]=i*pfil->Tsamp;
    for(long int i=0; i<pfil->Nbox; i++)
        pvw[i]=pfil->vBin[i]*pfil->Tsamp;

    long int ichan=0;
    for (long int i=0; i<pfil->Nsubband; i++)
    {
        SubBandData * psub=pfil->pSubband+i;
        for (long int j=0; j<psub->NDM; j++)
        {
            pvdm[ichan]=psub->pDM[j];
            //Get to the particular DM trial
            TimeSeries * ptim=psub->pTim+j;
            //l is the time index
            TimeSeries * ftpt=(ptim->plink);
            for (long int ibox=0; ibox<ptim->Nbox; ibox++)
            {
                for (long int isamp=0; isamp<pfil->Nsamples; isamp++)
                {

                    float *objpt=pcube+ichan*(pfil->Nbox)*(pfil->Nsamples) + ibox*(pfil->Nsamples) +isamp;
                    if (isamp<(ftpt+ibox)->Nsamples)
                    {
                        objpt[0]=(ftpt+ibox)->ptim[isamp];
                    }
                    else
                    {
                        objpt[0]=0;
                    }
                }
            }
            ichan++;
        }
    }
    return pcube;
}

bool SearchForNextEvents(double thre, float * pt, char * mask, long int nt, long int ndm, long int nw, long int & it, long int & idm, long int & iw, float &vs)
{
    long int ntot=nt*nw*ndm;
    float maxv=0;
    long int maxind=0;
    long int ind=0;
    bool getit=false;
    double mean=0;
    double var=0;
    for (long int i=0; i<ntot; i++)
    {
        mean+=pt[i];
        var+=pt[i]*pt[i];
    }
    mean/=ntot;
    var/=ntot;
    float rms=sqrt(var-mean*mean);


    for (long int j=0; j<ndm; j++)
    {
        for (long int i=0; i<nw; i++)
        {
            for (long int k=0; k<nt; k++)
            {
                if (pt[ind]>maxv && mask[ind]==0)
                {
                    vs=maxv=pt[ind];
                    maxind=ind;
                    it=k;
                    idm=j;
                    iw=i;
                    getit=true;
                }
                ind++;
            }
        }
    }
    if (!getit) return false;
    if (maxv<thre) return false;
    //Extend to the boundary
    LINKEDLIST<long int> Neib;
    Neib.Add(maxind);
    Neib._MoveToHead();
    mask[maxind]=1;
    while(Neib.p!=NULL)
    {
        //Get neighbor see if they satisfy the condition
        long int ic=*(Neib.p->Body);
        Neib.Delete();

        for(long int ddm=-10; ddm<=10; ddm++)
        {
            for(long int dws=-4; dws<=4; dws++)
            {
                for (long int dt=-10; dt<=10; dt++)
                {
                    long int delta=ddm*nw*nt+dws*nt+dt;
                    long int ic1=ic+delta;
                    if (ic1>=0 && ic1<ntot)
                    {
                        if (pt[ic1]> thre && pt[ic1]<pt[ic]+rms*0.3 && mask[ic1]==0)
                        {
                            mask[ic1]=1;
                            Neib.Add(ic1);
                        }
                    }
                }
            }
        }
        //Add neihbor to the list
        Neib._MoveToHead();
    }

    return true;
}

bool SearchForIsolatedEvents(double thre, float * pt, long int nt, long int ndm, long int nw, MATRIX2D & mxevt, long int maxNevt)
{
    long int ntot=nt*nw*ndm;
    char * mask=new char [ntot];
    for (long int i=0; i<ntot; i++) mask[i]=0;
    long int nevt=0;
    mxevt.New(maxNevt,4);
    long int it, idm, iw;
    float vs;
    while(SearchForNextEvents(thre, pt, mask, nt, ndm, nw, it, idm, iw, vs))
    {
        mxevt(nevt, 0)=it;
        mxevt(nevt, 1)=idm;
        mxevt(nevt, 2)=iw;
        mxevt(nevt, 3)=vs;
        nevt++;
        if (nevt==maxNevt)
            break;
    }
    delete [] mask;
    if (nevt==0)
    {
        mxevt.Free();
        return false;
    }
    else
    {
        mxevt=mxevt.Part(0,nevt-1, 0,3);
        return true;
    }
}

bool WriteSCube(const char * fname, float * pcube, long int Nsamples, long int Ndm, long int Nbox)
{
    string outputname;
    outputname+=fname;
    outputname+=".scube";

    FILE * fpo=fopen(outputname.c_str(), "wb");
    if (fpo==NULL) return false;

    fwrite(pcube,4,Nbox*Ndm*Nsamples,fpo);
    if(ferror(fpo))
    {
        cerr<<__func__<<": failed to write Scube."<<endl;
        return false;
    }
    fclose(fpo);
    return true;
}

bool WriteInfo(const char * fname, FilterBankData & fil, long int k, double OptT, double OptDM, double OptW, long int vti, long vdmi, long vwi, double OptS, long int Sco, double maxind)
{
    string scubename, pngname;
    scubename+=fname;
    pngname+=fname;
    scubename+=".scube";
    pngname+=".png";


    string outputname;
    outputname+=fname;
    char tmp[16];
    sprintf(tmp, "_Cand_%ld", k+1);
    outputname+=tmp;
    string outpngname = outputname;
    outputname+=".info";
    outpngname+=".png";
    FILE * fpo=fopen(outputname.c_str(), "wb");
    if (fpo==NULL) return false;

    fprintf(fpo,"%-25s: %.15lf\n","T(MJD)",OptT/(24.*3600.)+fil.Tstart);
    fprintf(fpo,"%-25s: %ld\n", "NT", vti);

    fprintf(fpo,"%-25s: %f\n","DM(cm^-3*pc)",OptDM);
    fprintf(fpo,"%-25s: %ld\n", "NDM",vdmi);

    fprintf(fpo,"%-25s: %lf\n","DM_Index",maxind);

    fprintf(fpo,"%-25s: %f\n","Width(ms)",1000*OptW);
    fprintf(fpo,"%-25s: %ld\n", "NW",vwi);

    fprintf(fpo,"%-25s: %f\n","S",OptS);
    fprintf(fpo,"%-25s: %ld\n", "Score",Sco);
    fprintf(fpo,"%-25s: %d\n","Telescope_id",fil.Telescope_id);
    fprintf(fpo,"%-25s: %.15lf\n","Tstart(MJD)",fil.Tstart);
    fprintf(fpo,"%-25s: %lf\n","RA(J2000)",fil.Src_raj);
    fprintf(fpo,"%-25s: %lf\n","DEC(J2000)",fil.Src_dej);
    fprintf(fpo,"%-25s: %lf\n","AZ(degrees)",fil.Az_start);
    fprintf(fpo,"%-25s: %lf\n","AL(degrees)",fil.Za_start);
    fprintf(fpo,"%-25s: %lf\n","Tsamp(us)",1e6*fil.Tsamp);
    fprintf(fpo,"%-25s: %ld\n","Nsamples",fil.Nsamples);
    fprintf(fpo,"%-25s: %ld\n","NDMs",fil.Ndm);
    fprintf(fpo,"%-25s: %d\n","Nbox",fil.Nbox);
    fprintf(fpo,"%-25s: %s\n","Data",fil.FileName.c_str());
    fprintf(fpo,"%-25s: %s\n","Scube",scubename.c_str());
    fprintf(fpo,"%-25s: %s\n","Image",pngname.c_str());
    fprintf(fpo,"%-25s: %s\n","CImage",outpngname.c_str());

    fclose(fpo);

return true;
}

long int Score(SEQUENCE & vt, MATRIX2D & mxsub, double OptW, double OptS, SEQUENCE & pvindex2, SEQUENCE & pindexS, double alphaf, double beta_snr, double beta_etaf, double beta_ind)
{
    long int sumfbool=0;
    for (long int i=0; i<mxsub.Row; i++)
    {
        double inwin=0, outwin=0, outwin2=0;
        long int inN=0, outN=0;
        for (long int j=0; j<mxsub.Col; j++)
        {
            if (vt(j)<-OptW/2 || vt(j)>OptW/2)
            {
                outwin+=mxsub(i,j);
                outwin2+=mxsub(i,j)*mxsub(i,j);
                ++outN;
            }
            else
            {
                inwin+=mxsub(i,j);
                ++inN;
            }
        }
        sumfbool+=(inwin/inN-outwin/outN)>sqrt(outwin2/outN-(outwin/outN)*(outwin/outN))*alphaf?1:0;
    }

    double etaf=(double)sumfbool/(double)mxsub.Row;

    double tmp1=0, tmp2=0;
    for (long int i=0; i<pvindex2.n; i++)
    {
        tmp1+=(pvindex2(i)-2.)*(pvindex2(i)-2.)*pindexS(i);
        tmp2+=pindexS(i);
    }
    double S_ind=-200.*tmp1/tmp2;
    //cout<<S_ind<<endl;
    double S_etaf=-200.*(etaf-1.)*(etaf-1.);
    double S_snr=OptS>100?0:-(OptS-100)*(OptS-100);

    return beta_snr*S_snr+beta_etaf*S_etaf+beta_ind*S_ind;

}
/////////////////////////////////  dm index ////////////////////////////////////////////////////////
float * FormSCube2(FilterBankData * pfil, SEQUENCE & pvindex, SEQUENCE & pvdm, SEQUENCE & pvw, long int vti, long int vdmi)
{
    float var,mean;

//    cout<<"get DM.."<<endl;
    float OptDM=getdm(pfil, vdmi, var, mean);
    if (OptDM == -1) return NULL;
//    cout<<"finish get DM..."<<endl;

    float ddm=pfil->Tsamp*1.2e3;

    long int Nindex=21;
    long int Ndm=pfil->vBin[pfil->Nbox-1];
//    long int Nbox=pfil->Nbox;
    long int Nbox=Ndm/2;

    if (!pvindex.New(Nindex)) return NULL;
    if (!pvdm.New(Ndm)) return NULL;
    if (!pvw.New(Nbox)) return NULL;

    for (long int i=0; i<Nindex; i++)
    {
        pvindex(i)=1.0+i*2./Nindex;
    }
    for (long int i=0; i<Ndm; i++)
    {
        pvdm(i)=OptDM+(i-Ndm/2)*ddm;
    }
    for (long int i=0; i<Nbox; i++)
    {
        //pvw(i)=pfil->vBin[i]*pfil->Tsamp;
        pvw(i)=i*pfil->Tsamp*2;
    }

    long int vti1=(vti-pfil->vBin[pfil->Nbox-1])>0?(vti-pfil->vBin[pfil->Nbox-1]):0;
    long int vti2=(vti+pfil->vBin[pfil->Nbox-1])<pfil->Nsamples-1?(vti+pfil->vBin[pfil->Nbox-1]):pfil->Nsamples-1;

    float * ptim=new float [vti2-vti1];

    float * pcube=new float [Nindex*Ndm*Nbox];

    //cout<<"begin dedisp..."<<endl;
    //clock_t start=0,finish=0;
    //start=clock();

    int * sfti=new int [pfil->Nchans];
    float * fsfti=new float [pfil->Nchans];
	//if (sfti==NULL) return false;

    double maxf=pfil->frequency_table[0];
	for(long int i=0; i<pfil->Nchans; i++)
		maxf=maxf>pfil->frequency_table[i]?maxf:pfil->frequency_table[i];

    for (long int i=0; i<Nindex; i++)
    {
        for (long int j=0; j<pfil->Nchans; j++)
        {
            fsfti[j]=DMDelay2(1., pfil->frequency_table[j], maxf, pvindex(i));
        }
        for (long int j=0; j<Ndm; j++)
        {
            float tmp=pvdm(j)/pfil->Tsamp;
            for (long int l=0; l<pfil->Nchans; l++)
            {
                sfti[l]=tmp*fsfti[l];
            }
            if (!Dedisperse2(pfil, sfti, vti1, vti2, ptim)) return NULL;
            for (long int k=0; k<Nbox; k++)
            {
                //pcube[i*Ndm*Nbox+j*Nbox+k]=ApplyBoxFilter2(ptim, var, mean, pfil->vBin[k], vti2-vti1);
                pcube[i*Ndm*Nbox+j*Nbox+k]=ApplyBoxFilter2(ptim, var, mean, 2*k, vti2-vti1);
            }
        }
    }
    delete [] sfti;
    delete [] fsfti;

    //finish=clock();
    //cout<<"finish dedisp..."<<"Time waste: "<<finish-start<<endl;

    delete [] ptim;

    return pcube;
}
//bool Dedisperse2(FilterBankData * pfil, double dmv, double dmindex, long int vti1, long int vti2, float * ptim)
bool Dedisperse2(FilterBankData * pfil, int * sfti, long int vti1, long int vti2, float * ptim)
{

	long int Nsamples=vti2-vti1;
/*
	int * sfti=new int [pfil->Nchans];
	if (sfti==NULL) return false;
*/
/*
	double maxf=pfil->frequency_table[0];
	for(long int i=0; i<pfil->Nchans; i++)
		maxf=maxf>pfil->frequency_table[i]?maxf:pfil->frequency_table[i];
*/
/*
	for (long int j=0; j<pfil->Nchans; j++)
    {
        sfti[j]=round(DMDelay2(dmv, pfil->frequency_table[j], maxf, dmindex)/pfil->Tsamp);
    }
*/

	for (long int i=0; i<Nsamples; i++)
	{
		float tmp=0;
		long int tmpi=i+vti1;
		for(long int k=0; k<pfil->Nifs; k++)
		{
			for(long int j=0; j<pfil->Nchans; j++)
			{
//				long int isft=i+vti1+sfti[j];
                long int isft=tmpi+sfti[j];
				if (isft<pfil->Nsamples && isft>0)
					tmp+=pfil->pData[(isft)*pfil->Nchans*pfil->Nifs + j*pfil->Nifs+k];
			}
		}
		ptim[i]=tmp;
	}
//	delete [] sfti;
	return true;
}

double DMDelay2(float dm, float fl, float fh, float dmindex)
{
	return (4.148741601e-3 *dm * ( 1./(pow(fl/1000., dmindex)) - 1./(pow(fh/1000., dmindex)) ) );
}

float ApplyBoxFilter2(float * ori, float var, float mean, long int wi, long int n)
{
    float obj=0;

	long int k=0;
	long int sfti=wi>n?n:wi;
	double sigshif=sfti*var;
	float tmp=0;
	for (long int j=0; j<sfti/2; j++)
	{
		tmp+=ori[j]-mean;
	}
	obj=tmp*tmp/sigshif;
	for (long int j=sfti/2; j<sfti; j++)
	{
		tmp+=ori[j]-mean;
		obj=tmp*tmp/(sigshif) > obj?tmp*tmp/(sigshif):obj;
		if (k>=n) return obj;
	}
	for (long int j=sfti; j<n; j++)
	{
		tmp+=ori[j];
		tmp-=ori[j-sfti];
		obj=tmp*tmp/(sigshif) > obj?tmp*tmp/(sigshif):obj;
		if (k>=n) return obj;
	}
	for (long int j=n; j<n+sfti/2; j++)
	{
		tmp-=(ori[j-sfti]-mean);
		obj=tmp*tmp/(sigshif) > obj?tmp*tmp/(sigshif):obj;
		if (k>=n) return obj;
	}
	return obj;
}

float getdm(FilterBankData * pfil, long int vdmi, float & var, float & mean)
{
    long int n=0;
    for (long int i=0; i<pfil->Nsubband; i++)
    {
        SubBandData * psub=pfil->pSubband+i;
        for (long int j=0; j<psub->NDM; j++)
        {
            if (n == vdmi)
            {
                TimeSeries * ptim=psub->pTim+j;
                var=ptim->Var;
                mean=ptim->Mean;
                return psub->pDM[j];
            }
            n++;
        }
    }
    return -1;
}

float * runMedian(float * data, long int size, int w)
{
	float * datMedian = new float [size];
	AVLTree<float> treeMedian;

	w = w>size?size:w;
	long int k = 0;

	int a = -floor(w*0.5);
	int b = ceil(w*0.5);

	for (long int i=0; i<b; i++)
	{
		treeMedian.insertValue(data[i]);
	}
	datMedian[k++] = treeMedian.getMedian();

	for (long int i=1; i<size; i++)
	{
		a++;
		b++;
		if (a > 0)
			treeMedian.removeValue(data[a-1]);
		if (b <= size)
			treeMedian.insertValue(data[b-1]);

		datMedian[k++] = treeMedian.getMedian();
	}

	return datMedian;
}

float * runMedian(float * data, int size, int w)
{
	float * datMedian = new float [size];
	AVLTree<float> treeMedian;

	w = w>size?size:w;
	long int k = 0;

	int a = -floor(w*0.5);
	int b = ceil(w*0.5);

	for (long int i=0; i<b; i++)
	{
		treeMedian.insertValue(data[i]);
	}
	datMedian[k++] = treeMedian.getMedian();

	for (long int i=1; i<size; i++)
	{
		a++;
		b++;
		if (a > 0)
			treeMedian.removeValue(data[a-1]);
		if (b <= size)
			treeMedian.insertValue(data[b-1]);

		datMedian[k++] = treeMedian.getMedian();
	}

	return datMedian;
}
