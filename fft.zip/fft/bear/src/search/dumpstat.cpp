/**\brief
 *
 * =====================================================================================
 *
 *       Filename:  tst_shm.cpp
 *
 *    Description:
 *
 *        Version:  1.0
 *        Created:  2016年04月30日 20时39分27秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  K.J.Lee (),
 *   Organization:
 *
 * =====================================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sedge.h>
#include "shmstruc.h"
#include "filterbank.h"

using namespace std;

void printhelp(const char * cmd)
{
	cout<<"Usage "<<cmd<<": "<<endl;
	cout<<endl;
	cout<<"    -fch1  Top freq (MHz)        Highest frequency of (channel 0)"<<endl;
	cout<<"    -foff  Channel widht (MHz)   Channel widht"<<endl;
	cout<<"    -nch   Channel number        Channel number"<<endl;
	cout<<"    -tsamp Sample rate           Sample rate"<<endl;
	cout<<"    -nif   Nifs                  Polarization parameter number"<<endl;
	cout<<"    -sum   N                     Polarization summed (0 is ExEx, 1 is EyEy and 2 is ExEx+EyEy)"<<endl;
	cout<<"    -fl   Nifs                   Power of frequency range [fl, fh]"<<endl;
	cout<<"    -fh   Nifs                   Power of frequency range [fl, fh]"<<endl;
}

int main(int argc, char *argv[])
{
	if (argc==1)
	{
		printhelp(argv[0]);
		exit(0);
	}
	void * add_p=NULL;
	_MEMINFO meminfo;
	ReadCounts(& meminfo);
	long int Nseg=meminfo.Nseg;
	long int Nlen=meminfo.Nlen;
	double Fch1=Se_CMD_Key_Num(argv, argc, "-fch1", 1800, 1);
	double Foff=Se_CMD_Key_Num(argv, argc, "-foff", 0.5, 1);
	int Nchans=Se_CMD_Key_Num(argv, argc, "-nch", 512, 1);
	double Tsamp=Se_CMD_Key_Num(argv, argc, "-tsamp", 64e-6, 1);
	int Nifs=Se_CMD_Key_Num(argv, argc, "-nif", 1, 1);
	int sums=Se_CMD_Key_Num(argv, argc, "-sum", 0, 1);
	double fl=Se_CMD_Key_Num(argv, argc, "-fl", 1400, 1);
	double fh=Se_CMD_Key_Num(argv, argc, "-fh", 1800, 1);

	_STATUS savekey=RDY;
	long int Nsl=Nlen/Nseg;
	//Start to allocate the header information
	long int header_size=sizeof(_MEMELEM)*Nseg;
	add_p=OpenSHM(SHM_INFO_FN, header_size);
	if (add_p==(void *)(-1)) exit(1);
	void * add_datap=OpenSHM(SHM_FN, Nlen*sizeof(FILTYPE));
	if (add_datap==(void *)(-1)) exit(1);

	//header pointer
	_MEMELEM * ph=(_MEMELEM *) (add_p);
	//data pointer

	long int Nsamples=Nsl/(Nifs*Nchans);

	int chanl = Foff>0 ? (fl-Fch1)/Foff : (fh-Fch1)/Foff;
	int chanh = Foff>0 ? (fh-Fch1)/Foff : (fl-Fch1)/Foff;

	chanl = chanl<0 ? 0:chanl;
	chanh = chanh>Nchans ? Nchans:chanh;

	while(true)
	{
		for (long int i=0;i<Nseg;i++)
		{
			if ((ph+i)->Status==savekey)
			{
				(ph+i)->Status=RD;
				FILTYPE * pd_proc=(FILTYPE*) (add_datap) + (ph+i)->Shifts;
				double mjd=(ph+i)->MJD;
				double xres=0;
				for (long int i=0;i<Nsamples;i++)
				{
					long int dl1=i*Nifs*Nchans;
					for (long int j=0;j<sums+1;j++)
					{
						long int dl2=j*Nchans;
						for (long int k=chanl; k< chanh; k++)
							xres += pd_proc[dl1+dl2+k];
					}
				}

				xres /= (chanh-chanl)*Nsamples;

	            cout<<"MJD: "<<setprecision(20)<<mjd<<"\n";
	            cout<<"power: "<<setprecision(5)<<xres<<"\n";
	            cout<<endl;

				pd_proc=NULL;

				(ph+i)->Status=EMPTY;
			}
		}
		//usleep(100);
	}
	if (UnmountSHM(add_p, header_size) ==-1)
	{
		perror("munmap failed: ");
		exit(1);
	}
	if (UnmountSHM(add_datap, Nlen*sizeof(FILTYPE)) ==-1)
	{
		perror("munmap failed: ");
		exit(1);
	}
	exit(0);
}


