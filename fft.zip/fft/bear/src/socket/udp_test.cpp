#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#include "aux.h"
#include "shmstruc.h"
#include <sedge.h>

using namespace std;

float profile(float t, float w, float p, float A, float ph);

int main(int argc, char * argv[])
{
    string ip=Se_CMD_Key_Val(argv,argc, "-ip");
    long int port=Se_CMD_Key_Num(argv,argc, "-port", 9999);

    long int nchans=Se_CMD_Key_Num(argv,argc, "-nch", 500);
    long int nifs=Se_CMD_Key_Num(argv,argc, "-nif", 1);
    float tsamp=Se_CMD_Key_Num(argv,argc, "-tsamp", 64e-6);
    float fch1=Se_CMD_Key_Num(argv,argc, "-fch1", 1800);
    float foff=Se_CMD_Key_Num(argv,argc, "-foff", -1);

    float dm=Se_CMD_Key_Num(argv,argc, "-dm", 500);
    float snr=Se_CMD_Key_Num(argv,argc, "-snr", 10);
    
    float p=Se_CMD_Key_Num(argv,argc, "-period", 1);
    float w=Se_CMD_Key_Num(argv,argc, "-w", 0.005);
    float ph=Se_CMD_Key_Num(argv,argc, "-phase", 0.5);

    float A = snr * sqrt(2 * 0.989939 * sqrt(2.) * w * tsamp) / (0.842732 * w * sqrt(3.1415926) * sqrt(nchans));

    cout<<"A= "<<A<<endl;

    int sock = socket(PF_INET, SOCK_DGRAM, 0);

    sockaddr_in servAddr;
    memset(&servAddr, 0, sizeof(servAddr));
    servAddr.sin_family = PF_INET;
    servAddr.sin_addr.s_addr = inet_addr(ip.c_str());
    servAddr.sin_port = htons(port);

    long int * vdi=new long int [nchans];
    for (long int j=0; j<nchans; j++)
    {
        vdi[j]=round(DMDelay(dm, fch1+foff*j, fch1)/tsamp);
    }

    SOKTYPE * buffer=new SOKTYPE [nchans*nifs+sizeof(long int)/sizeof(SOKTYPE)];

    long int i=0;

    //cout<<__bswap_64(1)<<endl;

    while(1)
    {
        for (long int j=0; j<nchans; j++)
        {
            for (long int k=0; k<nifs; k++)
            {
                buffer[j*nifs+k]=round(Se_RanGaussian(0, 1) + profile((i-vdi[j])*tsamp, w, p, A, ph) + 20);
            }
        }
        long int sn=__bswap_64(i);
        memcpy(buffer+nchans*nifs,&sn,sizeof(long int));
        SOKTYPE * tmpdata=new SOKTYPE [nchans*nifs];
        for (long int j=0; j<nchans*nifs; j++)
        {
	    if (sizeof(SOKTYPE) == sizeof(char))
	    {
		tmpdata[j]=buffer[nchans*nifs-1-j];
	    }
	    else if (sizeof(SOKTYPE) == sizeof(unsigned int))
	    {
		tmpdata[j]=__bswap_32(buffer[nchans*nifs-1-j]);
	    }
        }
        memcpy(buffer,tmpdata,nchans*nifs*sizeof(SOKTYPE));
        sendto(sock, buffer, nchans*nifs*sizeof(SOKTYPE)+sizeof(long int), 0, (struct sockaddr*)&servAddr, sizeof(servAddr));
        delete [] tmpdata;
        ++i;

        //usleep(10);
    }

    delete [] buffer;
    delete [] vdi;

    exit(0);
}

float profile(float t, float w, float p, float A, float ph)
{
    float phase = (t/p-floor(t/p))/p;
    return A*exp(-2.*(phase-ph)*(phase-ph)*p*p/(w*w));
}
