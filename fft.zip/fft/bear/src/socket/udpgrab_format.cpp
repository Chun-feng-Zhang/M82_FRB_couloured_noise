/*
 ============================================================================
 Name        : udpgrab_format.cpp
 Author      : Jeason Pei
 Version     : v1.0
 Created     : May 11, 2016
 Copyright   : this is free for use
 Description : grab udp frames from ROACH1/2 10GbE network, checkout whether the packets are lost or not, and then transform the data to a specific format.
 ============================================================================
 */
//g++ se_cmd.cpp shmstruc.cpp udpgrab_singleFrame.c  -I/usr/include/python2.6 -shared -L/usr/bin -fpic -lpython2.6 -lrt -o udpgrab_singleFrame.exe
//g++ shmstruc.cpp udpgrab_format.cpp  -lrt -o udpgrab_format.exe
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
//#include "se_cmd.h"
#include "shmstruc.h"
#include <byteswap.h>
#include <sedge.h>
#include <string>

//#define UDP_IP "192.168.5.12" //CX4 port
//#define UDP_IP "127.0.0.1" //SFP+ port1
//#define UDP_PORT 6666
//#define FRAME 4104
//#define TCHANS 512 // total channel is 512
//#define BANDCUT 0 // cut lower frequency from 0 to 100MHz
//#define BANDUSE (TCHANS-BANDCUT-0) //used channels
using namespace std;


int main(int argc, char *argv[])
{
    string ip=Se_CMD_Key_Val(argv,argc, "-ip");
    long int port=Se_CMD_Key_Num(argv,argc, "-port", 9999);
    long int nchans=Se_CMD_Key_Num(argv,argc, "-nchans", 512);
    long int banduse=Se_CMD_Key_Num(argv, argc, "-banduse", 512);
    long int nifs=Se_CMD_Key_Num(argv, argc, "-nifs", 1);
    long int framesize=nifs*nchans*sizeof(SOKTYPE)+sizeof(long int);

    int serverSocket;
    struct timeval currenttime;
    struct sockaddr_in serverAddr;
    // 建立Socket，并设置
    serverSocket = socket(AF_INET, SOCK_DGRAM, 0);
    // 设置socket选项，这是可选的，可以避免服务器程序结束后无法快速重新运行
    int val=1;
    int bufsize = 256*1024*1024;

    setsockopt(serverSocket, SOL_SOCKET, SO_REUSEADDR, &val, sizeof(val));
    setsockopt(serverSocket, SOL_SOCKET, SO_RCVBUF, &bufsize, sizeof(bufsize));

    // 定义端口地址
    bzero(&serverAddr,sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(port);
    serverAddr.sin_addr.s_addr = inet_addr(ip.c_str());
    int rc = bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr));
    if (rc == -1)
    {
        printf("Bad bind\n");
        return 0;
    }

    double Year, Month, Day;
    double Mjd;
    time_t timep;
    struct tm *p;

    SOKTYPE *data_swap;
    data_swap = (SOKTYPE *) malloc (sizeof(unsigned char)*framesize); //for frame verification and format

    //unsigned int *voidframe;
    //voidframe = (unsigned int *) malloc (sizeof(unsigned int)*banduse); //for frame compensation
    int n_fseg;
    int start=time((time_t*)NULL);
    unsigned int serverAddr_len=sizeof(serverAddr);
    //creat shared memory
    void * add_p=NULL;
    printf("Creating shared memory\n");
    _MEMINFO meminfo;
    ReadCounts(& meminfo);
    long int Nseg=meminfo.Nseg;			//number of segmentation
    long int Nlen=meminfo.Nlen;			//number of floats in all segmentationd
    long int Nsl=Nlen/Nseg;					//number of floats in one segmentation
    long int header_size=sizeof(_MEMELEM)*Nseg;
    add_p=OpenSHM(SHM_INFO_FN, header_size);
    if (add_p==(void *)(-1)) exit(1);
    //Allocate Data memory
    void * add_datap=OpenSHM(SHM_FN, Nlen*sizeof(FILTYPE));
    if (add_datap==(void *)(-1)) exit(1);

    FILTYPE * pt=(FILTYPE * ) add_datap;

    //Setup header
    _MEMELEM * ph=(_MEMELEM *) (add_p);

//list shared memory
    printf("Index\tMJD\t\tStatus\tShifts\n");
    printf("==================================\n");
    for (int i=0; i<Nseg; i++)
        printf("%d\t%f\t%d\t%ld\t\n", i+1,(ph+i)->MJD,(ph+i)->Status,(ph+i)->Shifts );
    printf("==================================\n");

    long unsigned int ntotsend=0; //total send packets
    long unsigned int ntotrecv=0; //total received packets
    long unsigned int ntotlost=0; //total lost packets
    double ratelost=0; //packets lost rate

    long unsigned int ntmp=0;
    do
    {
        //get Mjd time
        time(&timep);
        p=gmtime(&timep);
        Year=p->tm_year+1900;
        Month=p->tm_mon+1;
        Day=p->tm_mday;
        Mjd = UTC2MJD(Year, Month, Day);
        n_fseg=0; //number of full segmentations
        //printf("Year:%f,Month:%f,day:%f\n",Year,Month,Day);
        //printf("MJD time is:%f\n",Mjd);

        for (int i=0; i<Nseg; i++)
        {
            if((ph+i)->Status==EMPTY)
            {
                #ifndef BASEBAND
                (ph+i)->Status=WRF;
                #endif // BASEBAND
                gettimeofday( &currenttime, NULL );
                time(&timep);
                p=gmtime(&timep);
                (ph+i)->MJD=Mjd+(double)((p->tm_hour)/24.0)
                            +(double)(p->tm_min/1440.0)
                            +(double)(p->tm_sec/86400.0)
                            +(double)(currenttime.tv_usec/86400.0/1000000.0);

                printf("MJD time is:%.15f\n",(ph+i)->MJD);

                //Setup memory
                FILTYPE * pt_current=pt+(ph+i)->Shifts;
                long unsigned int my_count=0; // for litter endien change
                long unsigned int count_check=0;//checkout counter
                long unsigned int * acc_counter=(long unsigned int *)(data_swap+nifs*nchans); //frame counter received from udp packets
                long unsigned int nvoid=0;
                long int m=0; 												//Number of blocked frames
                long int k=0;													//Number of lost frames
                long int Nsmp=Nsl/(nifs*banduse);						//The number of time samples of one segmentation
                //cout<<"Nsmp="<<Nsmp<<endl;
                for(long int j=0; j<Nsmp; j++)
                {
                    recvfrom(serverSocket,data_swap,sizeof(unsigned char)*framesize,0,(struct sockaddr*)&serverAddr, &serverAddr_len);
                    my_count=__bswap_64(acc_counter[0]);
                    //for (long int iii=0; iii<512; iii++) cout<<(int)data_swap[iii]<<" ";
                    //cout<<"my_count= "<<my_count<<endl;
                    if(j==0)
                    {
                        count_check=my_count; //set initializing value to count_check
                        count_check++;
                        ntmp=my_count;
                    }
                    else
                    {
                        //frame lost judgment
                        long int deltacount=my_count-count_check;
                        if (deltacount==0)
                        {
                            count_check++;
                        }
                        //if(count_check!=my_count){
                        else
                        {
                            //if frame block
                            if(deltacount<0)
                            {

                                if(my_count==0)
                                {
                                    //printf("frame lost due to block,received void frame!\n");
                                    nvoid++;
                                    count_check++;
                                }
                                else
                                {
                                    m++;
                                    for(int s=0; s<nifs*nchans; s++)
                                    {
                                        data_swap[s]=0;
                                    }
                                    //printf("frame %ld was blocked!\n",my_count);
                                    if((count_check-1)==my_count)
                                    {
                                        count_check++;
                                    }
                                }
                            }
                            //if frame lost, if(count_check<my_count)
                            else
                            {

                                k+=deltacount;
                                long int jjj=j;
                                j+=deltacount;
                                if (j < Nsmp)
                                {
                                    for (long int iii=0; iii<nifs*banduse*deltacount; iii++) pt_current[iii]=0;
                                    pt_current+=nifs*banduse*deltacount;
                                }
                                else
                                {
                                    for (long int iii=0; iii<nifs*banduse*(Nsmp-jjj); iii++) pt_current[iii]=0;
                                    pt_current+=nifs*banduse*(Nsmp-jjj);
                                }

                                /*
                                for(int pp=0;pp<multi_lost;pp++){
                                	k++;
                                	pt_current+=banduse;
                                	//pt_current=voidframe;
                                	//for(int ll=0;ll<banduse;ll++)
                                	//	{pt_current[ll]=voidframe[ll];}//write zero to the lost frame
                                }
                                */
                                //printf("frames lost from %ld to %ld!\n",count_check,(my_count-1));
                                count_check+=deltacount+1;
                                break;
                            }
                        }

                    }
                    /*
                    for(int kk=(0+BANDCUT);kk<nchans;kk++){
                    	pt_current[kk-BANDCUT]=__bswap_32(data_swap[(nchans-1)-(kk-BANDCUT)]);
                    }
                    */
                    for (long int kk=0; kk<nifs*banduse; kk++)
                    {
                        if (sizeof(SOKTYPE) == 1)
                            pt_current[kk]=data_swap[nifs*nchans-1-kk-0];
                        else if (sizeof(SOKTYPE) == 4)
                            pt_current[kk]=__bswap_32(data_swap[nifs*nchans-1-kk-0] );
                        //cout<<pt_current[kk]<<endl;
                    }
                    pt_current+=nifs*banduse;

                    //cout<<"count_check= "<<count_check<<endl;
                }
                #ifdef BASEBAND
                (ph+i)->Status=RDYF;
                #else
                (ph+i)->Status=RDY;
                #endif
                //printf("data input to memory segmentation number %d done!\n",i);
                //printf("number frame is: %ld\n",my_count);
                //printf("number of void frames is: %ld\n",nvoid);
                //printf("number of blocked frames is: %ld\n",m);
                //printf("number of lost frames is: %ld\n",k);
                //fflush(stdout);
                ntotsend+=count_check-ntmp;
                ntotlost+=k;
                ntotrecv+=count_check-ntmp-k;
                ratelost=(double)ntotlost/(double)ntotsend;

                cout<<"PacketSend: "<<ntotsend<<"\n";
                cout<<"PacketRecv: "<<ntotrecv<<"\n";
                cout<<"PacketLost: "<<ntotlost<<"\n";
                cout<<"LostRate: "<<ratelost*100<<"%"<<"\n";
                cout<<endl;

                //break;
            }
            else
            {
                //printf("segmentation number %d is full!\n",i);
                n_fseg++;
                //usleep(100);
                //if(n_fseg>=20){
                //printf("all of segmentations are full,please check and reset!\n");
                //exit(1);
                //}
            }
        }
    }
    while(1);
    int finish=time((time_t*)NULL);
    int Total_time=finish-start;
    printf("time consume is %d seconds\n",Total_time);

    return 0;
}

