/**\brief
 *
 * =====================================================================================
 *
 *       Filename:  tst_mat.cpp
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2015年02月04日 22时44分24秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  K.J.Lee (), 
 *   Organization:  
 *
 * =====================================================================================
 */
#include <sedge.h>
using namespace std;
int main(void)
{
	MATRIX2D mxAllEvents, mxEvents;
	for (long int i=0;i<1;i++)
	{
		mxEvents=Diag(2);
		long int orirow=mxAllEvents.Row;
		mxAllEvents.Resize(mxAllEvents.Row+mxEvents.Row, mxEvents.Col);
		mxAllEvents.SetPart(mxEvents, orirow,0);
	}
	SaveToTextFile(mxAllEvents);
}
