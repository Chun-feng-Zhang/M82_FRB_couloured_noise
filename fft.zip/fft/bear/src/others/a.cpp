/**\brief
 *
 * =====================================================================================
 *
 *       Filename:  a.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2016年05月02日 18时00分20秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  K.J.Lee (), 
 *   Organization:  
 *
 * =====================================================================================
 */
#include <stdio.h>
#include <byteswap.h>
#include <iostream>
#include<time.h>
#include<sys/time.h>
#include <sedge.h>
using namespace std;
double GetMJDNow(void)
{
	time_t timep;
	struct tm *p;
	timep=time(&timep);
	p=gmtime(&timep);
  double Year=p->tm_year+1900;
  double Month=p->tm_mon+1;
  double Day=p->tm_mday;
	double Mjd=367 * Year
        - 7 * (Year + (Month + 9) / 12) / 4
        - 3 * ((Year + (Month - 9) / 7) / 100 + 1) / 4
        + 275 * Month / 9
        + Day
        + 1721028
        - 2400000;
	struct timeval currenttime;
	gettimeofday( &currenttime, NULL );	
  double MJD=Mjd+(double)((p->tm_hour+8)/24.0)+(double)(p->tm_min/1440.0)+(double)(p->tm_sec/86400.0)+(double)(currenttime.tv_usec/86400.0/1000000.0);
	return MJD;
}

int main(void)
{
	cout<<std::fixed<<setprecision(15)<<GetMJDNow()<<endl;
	
	return(0);
	unsigned long i =0x0102030405060723;
	unsigned char *pt;
	pt=(unsigned char *) (&i);
	char j=0;
	printf("%lx\n", i);
	for (j=0;j<8;j++)
		printf("%d\n", pt[j]);

	printf("After bitswap\n");
	i=__bswap_64(i);
	for (j=0;j<8;j++)
		printf("%d\n", pt[j]);
	
	printf("%lx\n", i);

}
