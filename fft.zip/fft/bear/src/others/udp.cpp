/**\brief
 *
 * =====================================================================================
 *
 *       Filename:  udp.cpp
 *
 *    Description:  a
 *
 *        Version:  1.0
 *        Created:  2016年04月30日 19时46分07秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  K.J.Lee (), 
 *   Organization:  
 *
 * =====================================================================================
 */

#include <netinet/in.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include "config.h"


char Tx_buffer[]= {"MOXA UDP test!"};
char Rx_buffer[LENGTH];
char *Dest_IP_addr = "192.168.0.14";

/***************************************************************************
**   void *UDP_Rx_process(void *data)
**   功能:  建立一个UDP接收线程
**   参数:  void *data-->传入参数
** 全局变量: th_UDP_Rx
**   描述:
** 
****************************************************************************/
void *UDP_Rx_process(void *data)
{
 int sock_UDP_Rx_fd;                           // Socket file descriptor
 int Rx_num;
 int Tx_num;
 int addr_size;
 struct sockaddr_in addr_remote;        // Host address information

 printf ("UDP_Rx_process starting!\n" );
 //-----------------------------------------------------------
 if ((sock_UDP_Rx_fd = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
 {
     printf("ERROR: Cannot obtain Socket Descriptor!\n");
     return (0);
 }
 
 //-----------------------------------------------------------
 // Fill the socket address struct 填充本地信息
 addr_remote.sin_family = AF_INET;           // Protocol Family
 addr_remote.sin_port = htons(UDP_Rx_PORT);         // Port number
 addr_remote.sin_addr.s_addr  = INADDR_ANY;  // AutoFill local address
 bzero(&(addr_remote.sin_zero), 8);          // Flush the rest of struct

 //----------------------------------------------------------
 //  Blind a special Port
 if( bind(sock_UDP_Rx_fd, (struct sockaddr*)&addr_remote, sizeof(struct sockaddr)) == -1 )
 { 
  printf ("ERROR: Cannot bind Port %d\n",UDP_Rx_PORT);
   return (0);
 }
 else
 {
  printf("OK: Bind the Port %d sucessfully\n",UDP_Rx_PORT);
 }

 while(1)
 {

  //----------------------------------------------------
  //监听端口接收数据
  bzero(Rx_buffer,LENGTH);
  addr_size = sizeof(struct sockaddr_in);
  Rx_num = recvfrom(sock_UDP_Rx_fd, Rx_buffer, LENGTH, 0, (struct sockaddr *)&addr_remote, &addr_size);
  Rx_buffer[Rx_num]=0;
  
  //----------------------------------------------------
  //处理数据操作
  //inet_pton(AF_INET, argv[1], &remote_addr.sin_addr); // Net Address
  printf ("Receive from %s total %d bytes port:%d!\n", inet_ntoa(addr_remote.sin_addr), Rx_num,UDP_Rx_PORT);
  printf ("Data:%s\n",Rx_buffer);

  //----------------------------------------------------
  //在相应的端口上返回数据
  Tx_num = sendto(sock_UDP_Rx_fd, Rx_buffer, Rx_num, 0, (struct sockaddr *)&addr_remote, sizeof(struct sockaddr_in));
  if( Tx_num < 0 )
  {
      printf ("ERROR: Cannot send your data!\n",  Tx_num);
  }
  else
  {
          printf ("OK: Sent to %s total %d bytes !\n", Dest_IP_addr, Tx_num);
  }
  
  usleep(20000);
  //sleep(2);
 }
 close (sock_UDP_Rx_fd);
}
/***************************************************************************
**   void *UDP_Tx_process(void *data)
**   功能:  建立一个UDP发送线程
**   参数:  void *data-->传入参数
** 全局变量:th_UDP_Tx
**   描述:
** 
****************************************************************************/
void *UDP_Tx_process(void *data)
{
 int sock_UDP_Tx_fd;                         // Socket file descriptor
 int Tx_num;                               // Counter of received bytes 
 struct sockaddr_in addr_remote;      // Host address information

 printf ("UDP_Tx_process starting!\n" );
 while(1)
 {
  //-------------------------------------------------------
  //队列信号量操作

  
  //-------------------------------------------------------
  //UDP发送获取网络ID
  if ((sock_UDP_Tx_fd = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
  {
      printf("ERROR: Cannot obtain Socket Descriptor!\n");
      return (0);
  }
  
  //--------------------------------------------------------
  // Fill the socket address struct   填充发送的结构体
  addr_remote.sin_family = AF_INET;                     // Protocol Family
  addr_remote.sin_port = htons(UDP_Tx_PORT);                   // Port number
  inet_pton(AF_INET, Dest_IP_addr, &addr_remote.sin_addr);   // Net Address
  bzero(&(addr_remote.sin_zero), 8);                     // Flush the rest of struct
  
  //---------------------------------------------------------
  //UDP发送数据包
  Tx_num = sendto(sock_UDP_Tx_fd, Tx_buffer, strlen(Tx_buffer), 0, (struct sockaddr *)&addr_remote, sizeof(struct sockaddr_in));
  if( Tx_num < 0 )
  {
       printf ("ERROR: Cannot send your data!\n", Dest_IP_addr, Tx_num);
  }
  else
  {
          printf ("OK: Sent to %s total %d bytes !\n", Dest_IP_addr, Tx_num);
  }
  close (sock_UDP_Tx_fd);
  
  usleep(20000);
  sleep(2);
 }
}
/***************************************************************************
**   void *TCP_Server_process(void *data)
**   功能:  建立一个TCP服务线程
**   参数:  void *data-->传入参数
** 全局变量:
**   描述:
** 
****************************************************************************/
void *TCP_Server_process(void *data)
{
 int sock_TCP_fd;                          // Socket file descriptor
 int new_sock_fd;                         // New Socket file descriptor
 int num;
 int i;
 int sin_size;                        // to store struct size
 char sdbuf[]={"MOXA TCP/IP test!"};                 // Send buffer
 struct sockaddr_in addr_local;    
 struct sockaddr_in addr_remote;   

 //-----------------------------------------------------
 // Get the Socket file descriptor  
 if( (sock_TCP_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1 ) 
 {  
     printf ("ERROR: Cannot obtain Socket Despcritor\n");
     return (0);
 }
 else
 {
     printf ("OK: Obtain Socket Despcritor sucessfully\n");
 }

 //----------------------------------------------------
 // Fill the local socket address struct
 addr_local.sin_family = AF_INET;             // Protocol Family
 addr_local.sin_port = htons(TCP_PORT);          // Port number
 addr_local.sin_addr.s_addr  = INADDR_ANY;   // AutoFill local address
 bzero(&(addr_local.sin_zero), 8);            // Flush the rest of struct

 //---------------------------------------------------
 //  Blind a special Port
 if( bind(sock_TCP_fd, (struct sockaddr*)&addr_local, sizeof(struct sockaddr)) == -1 )
 { 
  printf ("ERROR: Cannot bind Port %d\n",TCP_PORT);
  return (0);
 }
 else
 {
     printf("OK: Bind the Port %d sucessfully\n",TCP_PORT);
 }

 //---------------------------------------------------
 //  Listen remote connect/calling
 if(listen(sock_TCP_fd,10) == -1)   
 { 
     printf ("ERROR: Cannot listen Port %d\n", TCP_PORT);
     return (0);
 }
 else
 {
     printf ("OK: Listening the Port %d sucessfully\n", TCP_PORT);
 }

 while(1)
 { 
  sin_size = sizeof(struct sockaddr_in); 

  //-------------------------------------------------
  //Wait a connection, and obtain a new socket file despriptor for single connection
  if ((new_sock_fd= accept(sock_TCP_fd, (struct sockaddr *)&addr_remote, &sin_size)) == -1)
  { 
      printf ("ERROR: Obtain new Socket Despcritor error\n");
      continue;
  }
  else
  {
      printf ("OK: Server has got connect from %s\n", inet_ntoa(addr_remote.sin_addr));
  }

      for(i=0;i<10;i++)
      {
   if((num = send(new_sock_fd, sdbuf, strlen(sdbuf), 0)) == -1)
   {
       printf("ERROR: String cannot be sent\n");
       close(new_sock_fd);
       break;
   }
   else
    printf("OK: Sent %d bytes to %s sucessful!\n", num,inet_ntoa(addr_remote.sin_addr));
   sleep(1);
      }
  
     usleep(20000);
  close(new_sock_fd); 
  }
 close(sock_TCP_fd);
}

/**************************************************************************
**                            End Of File
**************************************************************************/


