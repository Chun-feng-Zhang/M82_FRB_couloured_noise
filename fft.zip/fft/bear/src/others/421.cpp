/* 2011 Aug. 7th
*/
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <math.h>
#include "se_cmd.h"
#include "se_ave.h"
#include "header.h"
#include "rmd.h"
#include <stdlib.h>
#include <string.h>
using namespace std;
void get_string (FILE * inputfile, string & strtmp);
void put_string (FILE * outputfile, string & strtmp);
long double startpenc;					//starting percentage
long double endpenc;						//ending percentage
long int startbyte;							//where is the start of the smaller file
long int endbyte;								//where is the end of the smaller file
bool bit2ndfile = false;				//whether output the smaller file
bool bolKeepBand = false;
bool bolUsingVar = false;
void printhelp(char * cmdname);
int main (int argc, char *argv[])
{
	/*Handle help information*/
	if (argc <= 1 || Se_CMD_Key_Exist (argv, argc, "-h"))
	{
		printhelp(argv[0]);
		return (1);
	}

	string strIFileName;
	string strOFileName;
	string strOFileName2;
	string strOMaskName;
	bool bolMask=false;
	int expecting_rawdatafile = 0, expecting_source_name = 0;
	int nsamples;
	int expecting_frequency_table = 0, channel_index = 0;
	
	char chrOutPutBitNum = atoi (Se_CMD_Key_Val (argv, argc, "-nbit"));	

	if (Se_CMD_Key_Exist (argv, argc, "-kb")) bolKeepBand = true;
	
	if (Se_CMD_Key_Exist(argv, argc, "-var")) bolUsingVar=true;
	if (Se_CMD_Key_Exist(argv, argc, "-omask")) 
	{
		strOMaskName=Se_CMD_Key_Val(argv, argc, "-omask");
		bolMask=true;
	}
	
	if (Se_CMD_Key_Exist (argv, argc, "-o2"))
	{
		if (Se_CMD_Key_Exist (argv, argc, "-start"))
			startpenc = atof (Se_CMD_Key_Val (argv, argc, "-start")) / 100.0;
		else
			startpenc = 0.1;

		if (Se_CMD_Key_Exist (argv, argc, "-end"))
			endpenc = atof (Se_CMD_Key_Val (argv, argc, "-end")) / 100.0;
		else
			endpenc = 0.20;
		strOFileName2 = Se_CMD_Key_Val (argv, argc, "-o2");
		bit2ndfile = true;
	}
	else
	{
		startpenc = endpenc = startbyte = endbyte = -1;
		bit2ndfile = false;
	}
	strIFileName = Se_CMD_Key_Val (argv, argc, "-f");
	strOFileName = Se_CMD_Key_Val (argv, argc, "-o");
	FILE *fpInput = fopen (strIFileName.c_str (), "rb");
	FILE *fpOutput = fopen (strOFileName.c_str (), "wb");
	FILE *fpMask;
	FILE *fpOutput2;
	
	if (bit2ndfile) fpOutput2 = fopen (strOFileName2.c_str (), "wb");
	if (bolMask) fpMask=fopen (strOMaskName.c_str (), "wb");

	string strtmp;
	long int intTotalHeaderBytes = 0;
	int nbins;
	double period;												
	unsigned char inbit;									//input bit
	get_string (fpInput, strtmp);
	put_string (fpOutput, strtmp);
	if (bit2ndfile) put_string (fpOutput2, strtmp);
	if (bolMask) put_string (fpMask, strtmp);
	if (strtmp != "HEADER_START")
	{
		cerr << "Non-Standard file format." << endl;
		return (-1);
	}
	intTotalHeaderBytes += strtmp.length () + 4;
	while (1)
	{
		get_string (fpInput, strtmp);
		put_string (fpOutput, strtmp);
		if (bit2ndfile) put_string (fpOutput2, strtmp);
		if (bolMask) put_string (fpMask, strtmp);
		if (strtmp == "HEADER_END")
		{
			intTotalHeaderBytes += strtmp.length () + 4;
			break;
		}
		intTotalHeaderBytes += strtmp.length () + 4;
		if (strtmp == "rawdatafile")
		{
			expecting_rawdatafile = 1;
		}
		else if (strtmp == "source_name")
		{
			expecting_source_name = 1;
		}
		else if (strtmp == "FREQUENCY_START")
		{
			expecting_frequency_table = 1;
			channel_index = 0;
		}
		else if (strtmp == "FREQUENCY_END")
		{
			expecting_frequency_table = 0;
		}
		else if (strtmp == "az_start")
		{
			fread (&az_start, sizeof (az_start), 1, fpInput);
			fwrite (&az_start, sizeof (az_start), 1, fpOutput);
			if (bit2ndfile) fwrite (&az_start, sizeof (az_start), 1, fpOutput2);
			if (bolMask) fwrite (&az_start, sizeof (az_start), 1, fpMask);
			intTotalHeaderBytes += sizeof (az_start);
		}
		else if (strtmp == "za_start")
		{
			fread (&za_start, sizeof (za_start), 1, fpInput);
			fwrite (&za_start, sizeof (za_start), 1, fpOutput);
			if (bit2ndfile) fwrite (&za_start, sizeof (za_start), 1, fpOutput2);
			if (bolMask) fwrite (&za_start, sizeof (za_start), 1, fpMask);
			intTotalHeaderBytes += sizeof (za_start);
		}
		else if (strtmp == "src_raj")
		{
			fread (&src_raj, sizeof (src_raj), 1, fpInput);
			fwrite (&src_raj, sizeof (src_raj), 1, fpOutput);
			if (bit2ndfile) fwrite (&src_raj, sizeof (src_raj), 1, fpOutput2);
			if (bolMask) fwrite (&src_raj, sizeof (src_raj), 1, fpMask);
			intTotalHeaderBytes += sizeof (src_raj);
		}
		else if (strtmp == "src_dej")
		{
			fread (&src_dej, sizeof (src_dej), 1, fpInput);
			fwrite (&src_dej, sizeof (src_dej), 1, fpOutput);
			if (bit2ndfile) fwrite (&src_dej, sizeof (src_dej), 1, fpOutput2);
			if (bolMask) fwrite (&src_dej, sizeof (src_dej), 1, fpMask);
			intTotalHeaderBytes += sizeof (src_dej);
		}
		else if (strtmp == "tstart")
		{
			fread (&tstart, sizeof (tstart), 1, fpInput);
			fwrite (&tstart, sizeof (tstart), 1, fpOutput);
			double tstart2 =
					tstart + tsamp * (long double) (nsamples) * startpenc;
			if (bit2ndfile) fwrite (&tstart2, sizeof (tstart2), 1, fpOutput2);
			if (bolMask) fwrite (&tstart2, sizeof (tstart2), 1, fpMask);
			intTotalHeaderBytes += sizeof (tstart);
		}
		else if (strtmp == "tsamp")
		{
			fread (&tsamp, sizeof (tsamp), 1, fpInput);
			fwrite (&tsamp, sizeof (tsamp), 1, fpOutput);
			if (bit2ndfile) fwrite (&tsamp, sizeof (tsamp), 1, fpOutput2);
			if (bolMask) fwrite (&tsamp, sizeof (tsamp), 1, fpMask);
			intTotalHeaderBytes += sizeof (tsamp);
		}
		else if (strtmp == "period")
		{
			fread (&period, sizeof (period), 1, fpInput);
			fwrite (&period, sizeof (period), 1, fpOutput);
			if (bit2ndfile) fwrite (&period, sizeof (period), 1, fpOutput2);
			if (bolMask) fwrite (&period, sizeof (period), 1, fpMask);
			intTotalHeaderBytes += sizeof (period);
		}
		else if (strtmp == "fch1")
		{
			fread (&fch1, sizeof (fch1), 1, fpInput);
			fwrite (&fch1, sizeof (fch1), 1, fpOutput);
			if (bit2ndfile) fwrite (&fch1, sizeof (fch1), 1, fpOutput2);
			if (bolMask) fwrite (&fch1, sizeof (fch1), 1, fpMask);
			intTotalHeaderBytes += sizeof (fch1);
		}
		else if (strtmp == "fchannel")
		{
			fread (&frequency_table[channel_index], sizeof (double), 1, fpInput);
			fwrite (&frequency_table[channel_index], sizeof (double), 1, fpOutput);
			if (bit2ndfile) fwrite (&frequency_table[channel_index], sizeof (double), 1, fpOutput2);
			if (bolMask) fwrite (&frequency_table[channel_index], sizeof (double), 1, fpMask);
			intTotalHeaderBytes += sizeof (double);
			fch1 = foff = 0.0;				/* set to 0.0 to signify that a table is in use */
			channel_index++;
		}
		else if (strtmp == "foff")
		{
			fread (&foff, sizeof (foff), 1, fpInput);
			fwrite (&foff, sizeof (foff), 1, fpOutput);
			if (bit2ndfile) fwrite (&foff, sizeof (foff), 1, fpOutput2);
			if (bolMask) fwrite (&foff, sizeof (foff), 1, fpMask);
			intTotalHeaderBytes += sizeof (foff);
		}
		else if (strtmp == "nchans")
		{
			fread (&nchans, sizeof (nchans), 1, fpInput);
			fwrite (&nchans, sizeof (nchans), 1, fpOutput);
			if (bit2ndfile) fwrite (&nchans, sizeof (nchans), 1, fpOutput2);
			if (bolMask) fwrite (&nchans, sizeof (nchans), 1, fpMask);
			intTotalHeaderBytes += sizeof (nchans);
		}
		else if (strtmp == "telescope_id")
		{
			fread (&telescope_id, sizeof (telescope_id), 1, fpInput);
			fwrite (&telescope_id, sizeof (telescope_id), 1, fpOutput);
			if (bit2ndfile) fwrite (&telescope_id, sizeof (telescope_id), 1, fpOutput2);
			if (bolMask) fwrite (&telescope_id, sizeof (telescope_id), 1, fpMask);
			intTotalHeaderBytes += sizeof (telescope_id);
		}
		else if (strtmp == "machine_id")
		{
			fread (&machine_id, sizeof (machine_id), 1, fpInput);
			fwrite (&machine_id, sizeof (machine_id), 1, fpOutput);
			if (bit2ndfile) fwrite (&machine_id, sizeof (machine_id), 1, fpOutput2);
			if (bolMask) fwrite (&machine_id, sizeof (machine_id), 1, fpMask);
			intTotalHeaderBytes += sizeof (machine_id);
		}
		else if (strtmp == "data_type")
		{
			fread (&data_type, sizeof (data_type), 1, fpInput);
			fwrite (&data_type, sizeof (data_type), 1, fpOutput);
			if (bit2ndfile) fwrite (&data_type, sizeof (data_type), 1, fpOutput2);
			if (bolMask) fwrite (&data_type, sizeof (data_type), 1, fpMask);
			intTotalHeaderBytes += sizeof (data_type);
		}
		else if (strtmp == "ibeam")
		{
			fread (&ibeam, sizeof (ibeam), 1, fpInput);
			fwrite (&ibeam, sizeof (ibeam), 1, fpOutput);
			if (bit2ndfile) fwrite (&ibeam, sizeof (ibeam), 1, fpOutput2);
			if (bolMask) fwrite (&ibeam, sizeof (ibeam), 1, fpMask);
			intTotalHeaderBytes += sizeof (ibeam);
		}
		else if (strtmp == "nbeams")
		{
			fread (&nbeams, sizeof (nbeams), 1, fpInput);
			fwrite (&nbeams, sizeof (nbeams), 1, fpOutput);
			if (bit2ndfile) fwrite (&nbeams, sizeof (nbeams), 1, fpOutput2);
			if (bolMask) fwrite (&nbeams, sizeof (nbeams), 1, fpMask);
			intTotalHeaderBytes += sizeof (nbeams);
		}
		else if (strtmp == "nbits")
		{
			fread (&nbits, sizeof (nbits), 1, fpInput);
			if (Se_CMD_Key_Exist (argv, argc, "-inbit"))
				inbit = atoi (Se_CMD_Key_Val (argv, argc, "-inbit"));
			else
				inbit = nbits;
			nbits = chrOutPutBitNum;
			fwrite (&nbits, sizeof (nbits), 1, fpOutput);	//XXXXXX

			if (bit2ndfile) fwrite (&nbits, sizeof (nbits), 1, fpOutput2);	//XXXX2XX
			if (bolMask) fwrite (&nbits, sizeof (nbits), 1, fpMask);	//XXXX2XX
			intTotalHeaderBytes += sizeof (nbits);
		}
		else if (strtmp == "barycentric")
		{
			fread (&barycentric, sizeof (barycentric), 1, fpInput);
			fwrite (&barycentric, sizeof (barycentric), 1, fpOutput);
			if (bit2ndfile) fwrite (&barycentric, sizeof (barycentric), 1, fpOutput2);
			if (bolMask) fwrite (&barycentric, sizeof (barycentric), 1, fpMask);
			intTotalHeaderBytes += sizeof (barycentric);
		}
		else if (strtmp == "pulsarcentric")
		{
			fread (&pulsarcentric, sizeof (pulsarcentric), 1, fpInput);
			fwrite (&pulsarcentric, sizeof (pulsarcentric), 1, fpOutput);
			if (bit2ndfile) fwrite (&pulsarcentric, sizeof (pulsarcentric), 1, fpOutput2);
			if (bolMask) fwrite (&pulsarcentric, sizeof (pulsarcentric), 1, fpMask);
			intTotalHeaderBytes += sizeof (pulsarcentric);
		}
		else if (strtmp == "nbins")
		{
			fread (&nbins, sizeof (nbins), 1, fpInput);
			fwrite (&nbins, sizeof (nbins), 1, fpOutput);
			if (bit2ndfile) fwrite (&nbins, sizeof (nbins), 1, fpOutput2);
			if (bolMask) fwrite (&nbins, sizeof (nbins), 1, fpMask);
			intTotalHeaderBytes += sizeof (nbins);
		}
		else if (strtmp == "nsamples")
		{
			/* read this one only for backwards compatibility */
			fread (&nsamples, sizeof (nsamples), 1, fpInput);
			fwrite (&nsamples, sizeof (nsamples), 1, fpOutput);
			long double dtmp;
			dtmp = (long double) (nsamples) * fabs (startpenc - endpenc);
			int nsamples2 = (int) dtmp;
			if (bit2ndfile) fwrite (&nsamples2, sizeof (nsamples2), 1, fpOutput2);
			if (bolMask) fwrite (&nsamples, sizeof (nsamples), 1, fpMask);
			intTotalHeaderBytes += sizeof (nsamples);
		}
		else if (strtmp == "nifs")
		{
			fread (&nifs, sizeof (nifs), 1, fpInput);
			fwrite (&nifs, sizeof (nifs), 1, fpOutput);
			if (bit2ndfile) fwrite (&nifs, sizeof (nifs), 1, fpOutput2);
			if (bolMask) fwrite (&nifs, sizeof (nifs), 1, fpMask);
			intTotalHeaderBytes += sizeof (nifs);

		}
		else if (strtmp == "npuls")
		{
			fread (&npuls, sizeof (npuls), 1, fpInput);
			fwrite (&npuls, sizeof (npuls), 1, fpOutput);
			if (bit2ndfile) fwrite (&npuls, sizeof (npuls), 1, fpOutput2);
			if (bolMask) fwrite (&npuls, sizeof (npuls), 1, fpMask);
			intTotalHeaderBytes += sizeof (npuls);
		}
		else if (strtmp == "refdm")
		{
			fread (&refdm, sizeof (refdm), 1, fpInput);
			fwrite (&refdm, sizeof (refdm), 1, fpOutput);
			if (bit2ndfile) fwrite (&refdm, sizeof (refdm), 1, fpOutput2);
			if (bolMask) fwrite (&refdm, sizeof (refdm), 1, fpMask);
			intTotalHeaderBytes += sizeof (refdm);
		}
		else if (expecting_rawdatafile == 1)
		{
			strcpy (rawdatafile, strtmp.c_str ());
			expecting_rawdatafile = 0;
		}
		else if (expecting_source_name == 1)
		{
			strcpy (source_name, strtmp.c_str ());
			expecting_source_name = 0;
		}
		else
		{
			cerr << "read_header - unknown parameter : " << strtmp << endl;
			exit (-1);
		}

	}

	//32 bits machines
	if (sizeof (long int) == 4)
	{
		cout << "This is NOT a 64 bit machine." << endl;
		cout << "This code is not tested on a 32 bits machine yet!" << endl;
	}

	{
		if (!Se_CMD_Key_Exist (argv, argc, "-rmd"))	//not use running median
		{
			switch (inbit)
			{
			case 1:									//input 1bit
				{
					cout << "Input is a 1 bit data file" << endl;
					switch (chrOutPutBitNum)
					{
					case 1:							//1bit sampling 
						{
							cout << "It is already 1bit data" << endl;
							break;
						}
					case 2:
						{
							cout << "Converting the data" << endl;
							unsigned char chrtmp;
							unsigned char chra;
							while (!feof (fpInput))
							{
								fread (&chrtmp, sizeof (unsigned char), 1, fpInput);
								chra = 0;
								for (unsigned char i = 0; i < 4; i++)
								{
									chra = (chra << 2) + (chrtmp & 0x80);
									chrtmp <<= 1;
								}
								fwrite (&chra, sizeof (unsigned char), 1, fpOutput);
								chra = 0;
								for (unsigned char i = 0; i < 4; i++)
								{
									chra = (chra << 2) + (chrtmp & 0x80);
									chrtmp <<= 1;
								}
								fwrite (&chra, sizeof (unsigned char), 1, fpOutput);
							}
							break;
						}
					case 4:
						{
							cout << "Converting the data" << endl;
							unsigned char chrtmp;
							unsigned char chra;
							while (!feof (fpInput))
							{
								fread (&chrtmp, sizeof (unsigned char), 1, fpInput);
								chra = 0;
								for (unsigned char i = 0; i < 2; i++)
								{
									chra = (chra << 4) + (chrtmp & 0x80);
									chrtmp <<= 1;
								}
								fwrite (&chra, sizeof (unsigned char), 1, fpOutput);
								chra = 0;
								for (unsigned char i = 0; i < 2; i++)
								{
									chra = (chra << 4) + (chrtmp & 0x80);
									chrtmp <<= 1;
								}
								fwrite (&chra, sizeof (unsigned char), 1, fpOutput);
								chra = 0;
								for (unsigned char i = 0; i < 2; i++)
								{
									chra = (chra << 4) + (chrtmp & 0x80);
									chrtmp <<= 1;
								}
								fwrite (&chra, sizeof (unsigned char), 1, fpOutput);
								chra = 0;
								for (unsigned char i = 0; i < 2; i++)
								{
									chra = (chra << 4) + (chrtmp & 0x80);
									chrtmp <<= 1;
								}
								fwrite (&chra, sizeof (unsigned char), 1, fpOutput);
							}
							break;
						}
					case 8:
						{
							cout << "Converting the data" << endl;
							unsigned char chrtmp;
							unsigned char chrOutSwap[8];
							while (!feof (fpInput))
							{
								fread (&chrtmp, sizeof (unsigned char), 1, fpInput);
								for (unsigned char i = 0; i < 8; i++)
								{
									chrOutSwap[i] = chrtmp & 0x80;
									chrtmp <<= 1;
								}
								fwrite (&chrOutSwap, sizeof (unsigned char), 8, fpOutput);
							}
							break;
						}
					case 16:
						{
							cout << "Converting the data" << endl;
							unsigned char chrtmp;
							unsigned short int intOutSwap[8];
							while (!feof (fpInput))
							{
								fread (&chrtmp, sizeof (unsigned char), 1, fpInput);
								for (unsigned char i = 0; i < 8; i++)
								{
									intOutSwap[i] = (unsigned short int) (chrtmp & 0x80);
									intOutSwap[i] = (intOutSwap[i]) << 8;
									chrtmp <<= 1;
								}
								fwrite (&intOutSwap, sizeof (unsigned short int), 8,
												fpOutput);
							}
							break;
						}
					case 32:
						{
							cout << "Converting the data to 32 bit" << endl;

							unsigned char chrtmp;
							unsigned short int intA, intB;
							while (!feof (fpInput))
							{
								fread (&chrtmp, sizeof (unsigned char), 1, fpInput);
								for (unsigned char i = 0; i < 8; i++)
								{
									intB = (unsigned short int) (chrtmp & 0x80);
									intB = intB << 7;
									chrtmp <<= 1;
									intA = 0;
									fwrite (&intA, sizeof (unsigned short int), 1, fpOutput);
									fwrite (&intB, sizeof (unsigned short int), 1, fpOutput);
								}
							}
							break;
						}
					default:
						{
							cerr << "bit number with " << (int)
								chrOutPutBitNum << " is not suppoted" << endl;
							break;
						}
					}
					break;
				}
			case 2:									//input 2 bit
				{
					cout <<
					cout << "Input is a 2 bit data file" << endl;
					switch (chrOutPutBitNum)
					{
					case 1:							//1bit sampling 
						{
							cout << "Not supported yet!" << endl;
							break;
						}
					case 2:
						{
							cout << "It is already 2bit data" << endl;
							break;
						}
					case 4:
						{
							cout << "Not supported yet!" << endl;
							break;
						}
					case 8:
						{
							cout << "Converting the data" << endl;
							unsigned char chrtmp;
							unsigned char chrOutSwap[4];
							while (!feof (fpInput))
							{
								fread (&chrtmp, sizeof (unsigned char), 1, fpInput);
								for (unsigned char i = 0; i < 4; i++)
								{
									chrOutSwap[i] = chrtmp & 0xC0;
									chrtmp <<= 2;
								}
								fwrite (&chrOutSwap, sizeof (unsigned char), 4, fpOutput);
							}
							break;
						}
					case 16:
						{
							cout << "Not supported yet!" << endl;
							break;
						}
					case 32:
						{
							cout << "Not supported yet!" << endl;
							break;
						}
					default:
						{
							cerr << "bit number with " << (int)
								chrOutPutBitNum << " is not suppoted" << endl;
							break;
						}
					}
					break;
				}
			case 4:									//input 4 bit
				{
					cout <<
						"This is a 64 bit machine otherwise something is wrong!" << endl;
					cout << "Input is a 4 bit data file" << endl;
					switch (chrOutPutBitNum)
					{
					case 1:							//1bit sampling 
						{
							cout << "Not supported yet!" << endl;
							break;
						}
					case 2:
						{
							cout << "Not supported yet!" << endl;

							break;
						}
					case 4:
						{
							cout << "It is already 4bit data" << endl;
							break;
						}
					case 8:
						{
							cout << "Converting the data" << endl;
							unsigned char chrtmp;
							unsigned char chrOutSwap[2];
							while (!feof (fpInput))
							{
								fread (&chrtmp, sizeof (unsigned char), 1, fpInput);
								for (unsigned char i = 0; i < 2; i++)
								{
									chrOutSwap[i] = chrtmp & 0xF0;
									chrtmp <<= 4;
								}
								fwrite (&chrOutSwap, sizeof (unsigned char), 2, fpOutput);
							}
							break;
						}
					case 16:
						{
							cout << "Not supported yet!" << endl;
							break;
						}
					case 32:
						{
							cout << "Not supported yet!" << endl;
							break;
						}
					default:
						{
							cerr << "bit number with " << (int)
								chrOutPutBitNum << " is not suppoted" << endl;
							break;
						}
					}
					break;
				}
			case 8:									//input 8 bit
				{
					cerr << "Not implement yet!" << endl;
					break;
				}
			case 16:
				{
					cout <<
						"This is a 64 bit machine otherwise something is wrong!" << endl;
					cout << "Input is a 16 bit data file" << endl;
					switch (chrOutPutBitNum)
					{
					case 1:							//1bit sampling 
						{
							cout << "Not supported yet!" << endl;
							break;
						}
					case 2:
						{
							cout << "Not supported yet!" << endl;

							break;
						}
					case 4:
						{
							cout << "Not supported yet!" << endl;
							break;
						}
					case 8:
						{
							cout << "Not supported yet!" << endl;
							break;
						}
					case 16:
						{
							cout << "It is already 16bit data" << endl;
							break;
						}
					case 32:
						{
							cout << "Not supported yet!" << endl;
							break;
						}
					default:
						{
							cerr << "bit number with " << (int)
								chrOutPutBitNum << " is not suppoted" << endl;
							break;
						}
					}
					break;
				}
			case 32:
				{
					switch (chrOutPutBitNum)
					{
					case 1:							//1bit sampling 
						{
							cerr << "not implemented" << endl;
							break;
						}
					case 2:
						{
							cerr << "not implemented" << endl;
							break;
						}
					case 4:
						{
							cerr << "not implemented" << endl;
							break;
						}
					case 8:
						{
							//cout<<"Analyzing the data to output for 8bit"<<endl;
							/*number of data in one time stamps
							 * ndat|time= (number of channel) x (number of polarization).  
							 * This unit should be able to fit in one cache
							 */
#define BIT32DATA float
							int nunit = nifs * nchans;
							long int nsize = 0;
							try
							{
								BIT32DATA *pintmax = new BIT32DATA[nunit];	//max swap
								BIT32DATA *pintmin = new BIT32DATA[nunit];	//min swap
								
								BIT32DATA *pinttmp = new BIT32DATA[nunit];	//input series
								unsigned char *pchrtmp = new unsigned char[nunit];	//output series
								char *pchrMsk = new char[nunit];	//output series
								double *prange = new double[nunit];	//range
								double *pbandpass = new double[nunit];	//bandpass
								double *pbandpass1 = new double[nunit];	//bandpass residua
								CLS_Se_Ave_Var * pClsAV=new CLS_Se_Ave_Var[nunit];		//statistics
								fread (pinttmp, sizeof (BIT32DATA), nunit, fpInput);
								nsize++;
								for (int i = 0; i < nunit; i++)
								{
									pintmax[i] = pinttmp[i];
									pintmin[i] = pintmax[i];
									pbandpass1[i] = pinttmp[i];
									pbandpass[i] = 0;
									(pClsAV+i)->Add(pinttmp[i]);				//Add data to determine the mean and avg
								}
								while (!feof (fpInput))
								{
									fread (pinttmp, sizeof (BIT32DATA), nunit, fpInput);
									nsize++;
									for (int i = 0; i < nunit; i++)
									{
										pintmax[i] = pinttmp[i] > pintmax[i] ? pinttmp[i] : pintmax[i];
										pintmin[i] = pinttmp[i] < pintmin[i] ? pinttmp[i] : pintmin[i];
										pbandpass1[i] += pinttmp[i];
										if (pbandpass1[i] > 6e4)	//reduce the round off error
										{
											pbandpass[i] += pbandpass1[i];
											pbandpass1[i] = 0;
										}
										(pClsAV+i)->Add(pinttmp[i]);		//Add data to determine the mean and avg
									}
								}
								
								BIT32DATA *pintmaskmax =new BIT32DATA [nunit];			//max for mask
								BIT32DATA *pintmaskmin =new BIT32DATA[nunit];			//min for mask
								for (int i = 0; i < nunit; i++) pbandpass[i] += pbandpass1[i];
								double digithresh=3;
								//determine mask threshold
								if (Se_CMD_Key_Exist(argv, argc, "-omask")) digithresh=atof(Se_CMD_Key_Val(argv,argc, "-omask",2));
								for (int i = 0; i < nunit; i++)
								{
									pintmaskmin[i] = (pClsAV+i)->Ave() - ( (pClsAV+i)->Std() * digithresh );
									pintmaskmax[i] = (pClsAV+i)->Ave() + ( (pClsAV+i)->Std() * digithresh );
								}
								//determine digiterization threshold
								if (bolUsingVar)
								{
									digithresh=atof(Se_CMD_Key_Val(argv, argc, "-var"));
									for (int i = 0; i < nunit; i++)
									{
										pintmin[i] = (pClsAV+i)->Ave() - ( (pClsAV+i)->Std() * digithresh );
										pintmax[i] = (pClsAV+i)->Ave() + ( (pClsAV+i)->Std() * digithresh );
									}
								}
								/*If one needs to keep the bandpass shape*/
								if (bolKeepBand)
								{
									float ftmpmax, ftmpmin;
									ftmpmax = pintmax[0];
									ftmpmin = pintmin[0];
									for (int i = 1; i < nunit; i++)
									{
										ftmpmax = ftmpmax > pintmax[i] ? ftmpmax : pintmax[i];
										ftmpmin = ftmpmin < pintmin[i] ? ftmpmin : pintmin[i];
									}
									for (int i = 0; i < nunit; i++)
									{
										pintmax[i] = ftmpmax;
										pintmin[i] = ftmpmin;
									}
								}
								/*calculate the digitizing leveling*/
								for (int i = 0; i < nunit; i++) prange[i] = 255.0 / (pintmax[i] - pintmin[i]);
								if (fch1 != 0 && foff != 0.0)
								{
									for (int ichan = 0; ichan < nchans; ichan++)
										frequency_table[ichan] = fch1 + foff * ichan;
								}
								/*write band pass file */
								if (Se_CMD_Key_Exist (argv, argc, "-bandpass"))
								{
									ofstream foBand;
									foBand.open (Se_CMD_Key_Val (argv, argc, "-bandpass"), ios_base::out);
									int iunit = 0;
									for (int ichan = 0; ichan < nchans; ichan++)
									{
										foBand << frequency_table[ichan] << "\t";
										for (int ipol = 0; ipol < nifs; ipol++)
										{
											foBand << pbandpass[iunit] << "\t";
											iunit++;
										}
										foBand << endl;
									}
									foBand.close ();
								}

								/*extract RFI chanel information 								 */
								if (Se_CMD_Key_Exist (argv, argc, "-rfichan"))
								{
									int iAvrChanN;
									if (Se_CMD_Key_Exist (argv, argc, "-avrchan"))
									{
										iAvrChanN =
											atoi (Se_CMD_Key_Val (argv, argc, "-avrchan"));
										iAvrChanN = (int) (log ((double) (iAvrChanN)) / log (2));
									}
									else
										iAvrChanN = 3;
									if (iAvrChanN < 1)
									{
										cerr << "Number of averaging channel is wrong." << endl;
									}
									CLSdbRunningMedian clm[nifs];
									double **apBandPass = new double *[nifs];
									for (int ipol = 0; ipol < nifs; ipol++)
										apBandPass[ipol] = new double[nchans];
									//divide the bandpass into polarization
									int iunit = 0;
									for (int ichan = 0; ichan < nchans; ichan++)
									{
										for (int ipol = 0; ipol < nifs; ipol++)
										{
											(apBandPass[ipol])[ichan] = pbandpass[iunit];
											iunit++;
										}
									}
									//initiallize the Running Median filter
									for (int ipol = 0; ipol < nifs; ipol++)
										clm[ipol].Initialize (apBandPass[ipol], iAvrChanN);
									//half of the filter size
									int ishift = 2 << (iAvrChanN - 1);
									for (int ichan = (2 << iAvrChanN); ichan < nchans; ichan++)
									{
										for (int ipol = 0; ipol < nifs; ipol++)
										{
											clm[ipol].Insert ((apBandPass[ipol])[ichan]);
											apBandPass[ipol][ichan -
																			 (2 <<
																				iAvrChanN)] =
												apBandPass[ipol][ichan - ishift] - clm[ipol].value;
										}
									}
									//calculate the mean and variance of the difference
									double *pdbBase = new double[nifs];
									double *pdbVar = new double[nifs];
									for (int ipol = 0; ipol < nifs; ipol++)
									{
										pdbBase[ipol] = 0;
										pdbVar[ipol] = 0;
									}
									//mean
									for (int ichan = 0;
											 ichan < nchans - (2 << iAvrChanN); ichan++)
									{
										for (int ipol = 0; ipol < nifs; ipol++)
										{
											(pdbBase[ipol]) += apBandPass[ipol][ichan];
										}
									}

									for (int ipol = 0; ipol < nifs; ipol++)
										(pdbBase[ipol]) /= (nchans - (2 << iAvrChanN));
									//var
									for (int ichan = 0;
											 ichan < nchans - (2 << iAvrChanN); ichan++)
									{
										for (int ipol = 0; ipol < nifs; ipol++)
										{
											double dtmp = apBandPass[ipol][ichan] - pdbBase[ipol];
											(pdbVar[ipol]) += dtmp * dtmp;
										}
									}
									for (int ipol = 0; ipol < nifs; ipol++)
										(pdbVar[ipol]) =
											sqrt (pdbVar[ipol] / (nchans - (2 << iAvrChanN)));
									//set up RFI threshold
									double dbThreshold = 1.2;
									if (Se_CMD_Key_Exist (argv, argc, "-chanthre"))
										dbThreshold =
											atof (Se_CMD_Key_Val (argv, argc, "-chanthre"));
									int iNumNosChan = 0;
									for (int ichan = 0;
											 ichan < nchans - (2 << iAvrChanN); ichan++)
									{
										bool bolRFI = false;
										for (int ipol = 0; ipol < nifs; ipol++)
										{
											bolRFI = bolRFI
												||
												(fabs
												 (apBandPass[ipol][ichan] -
													pdbBase[ipol]) > dbThreshold * pdbVar[ipol]);
										}
										if (bolRFI)
										{
											iNumNosChan++;
										}
									}
									int *piNosChanNum = new int[iNumNosChan];
									int iNosChanInd = 0;
									for (int ichan = 0;
											 ichan < nchans - (2 << iAvrChanN); ichan++)
									{
										bool bolRFI = false;
										for (int ipol = 0; ipol < nifs; ipol++)
										{
											bolRFI = bolRFI
												||
												(fabs
												 (apBandPass[ipol][ichan] -
													pdbBase[ipol]) > dbThreshold * pdbVar[ipol]);
										}
										if (bolRFI)
										{
											piNosChanNum[iNosChanInd] = ichan + ishift;
											iNosChanInd++;
										}
									}
									ofstream
										orfichan (Se_CMD_Key_Val
															(argv, argc, "-rfichan"), ios_base::out);
									for (int i = 0; i < iNumNosChan; i++)
										orfichan << piNosChanNum[i] << "\t"
											<< frequency_table[piNosChanNum[i]] << endl;
									orfichan.close ();
									for (int ipol = 0; ipol < nifs; ipol++)
										delete[]apBandPass[ipol];
									delete[]apBandPass;
									delete[]pdbBase;
									delete[]pdbVar;
									delete[]piNosChanNum;


								}
								rewind (fpInput);
								unsigned char *chrswap =
									new unsigned char[intTotalHeaderBytes];
								fread (chrswap, sizeof (unsigned char),
											 intTotalHeaderBytes, fpInput);
								startbyte = (long int) ((long double) nsize * startpenc);
								endbyte = (long int) ((long double) nsize * endpenc);
								long int findex = 0;
								CLS_Se_Ave_Var * pClsAV2=new CLS_Se_Ave_Var[nunit];		//statistics
								while (!feof (fpInput))
								{
									fread (pinttmp, sizeof (BIT32DATA), nunit, fpInput);
									findex++;

									for (int i = 0; i < nunit; i++)
									{
										double val= ((double)(pinttmp[i]) -(double)( pintmin[i])) * prange[i];
										pchrMsk[i]= pinttmp[i]> pintmaskmax[i]? 
											2: 
											( pinttmp[i]< pintmaskmin[i]? 0:1);
										if (val<=0)
										{
											//pchrMsk[i]=0;
											val=0;
										}
										else if (val>=255)
										{
											val=255;
											//pchrMsk[i]=2;
										}
										//else pchrMsk[i]=1;
										pchrtmp[i] = (unsigned char) 	val;	
										(pClsAV2+i)->Add(val);				//Add data to determine the mean and avg
									}
									fwrite (pchrtmp, sizeof (unsigned char), nunit, fpOutput);
									if(bolMask) fwrite (pchrMsk, sizeof(char), nunit, fpMask);
									if (findex >= startbyte && findex <= endbyte && bit2ndfile)
										fwrite (pchrtmp, sizeof (unsigned char), nunit, fpOutput2);
								}
								/* minimal value and maximal value */
								if (Se_CMD_Key_Exist (argv, argc, "-maxmin"))
								{
									ofstream foMinMax;
									foMinMax.open (Se_CMD_Key_Val
																 (argv, argc, "-maxmin"), ios_base::out);
									int iunit = 0;
									for (int ichan = 0; ichan < nchans; ichan++)
									{
										for (int ipol = 0; ipol < nifs; ipol++)
										{
											foMinMax << pintmin[iunit] <<
												" " << pintmax[iunit] << "\t"<<(pClsAV2+iunit)->Ave()<<"\t"<< (pClsAV2+iunit)->Std();
											iunit++;
										}
										foMinMax << endl;
									}
									foMinMax.close ();
								}

								break;
							}
							catch (bad_alloc)
							{
								cerr << "Error in allocating memory!" << endl;
								exit (0);
							}
						}
					case 16:
						{
							cout << "Analyzing the data" << endl;
							unsigned int intmax;	//max value
							unsigned int intmin;	//min value
							unsigned int inttmp;
							double drange;
							fread (&inttmp, sizeof (unsigned int), 1, fpInput);
							intmin = intmax = inttmp;
							while (!feof (fpInput))
							{
								fread (&inttmp, sizeof (unsigned int), 1, fpInput);
								intmin = inttmp < intmin ? inttmp : intmin;
								intmax = inttmp > intmax ? inttmp : intmax;
							}
							drange = intmax - intmin;
							rewind (fpInput);
							unsigned char *chrswap = new unsigned char[intTotalHeaderBytes];
							fread (chrswap, sizeof (unsigned char),
										 intTotalHeaderBytes, fpInput);
							delete[]chrswap;
							unsigned short int intdat = 0;
							cout << "Converting the data" << endl;
							while (1)
							{
								intdat = 0;
								fread (&inttmp, sizeof (unsigned int), 1, fpInput);
								double dtmp = (inttmp - intmin) / drange * 65535.0;
								intdat = (unsigned short int) dtmp;
								fwrite (&intdat, sizeof (unsigned short int), 1, fpOutput);
								if (feof (fpInput))
									break;
							}
							break;
						}
					default:
						{
							cerr << "bit number with " << (int)
								chrOutPutBitNum << " is not suppoted" << endl;
							break;
						}
					}
					break;
				}

			default:
				{
					cerr <<
						"Input file not supported, maybe you need -inbit option" << endl;
				}
			}
		}
		else												//using running median
		{
			switch (inbit)
			{
			case 1:
				{
					break;
				}
			case 2:
				{
					break;
				}
			case 4:
				{
					break;
				}
			case 8:
				{
					break;
				}
			case 16:
				{
					break;
				}
			case 32:
				{
					switch (chrOutPutBitNum)
					{
					case 1:
						{
							cout << "not implemented" << endl;
							break;
						}
					case 2:
						{
							cout << "not implemented" << endl;
							break;
						}
					case 4:
						{
							cout << "not implemented" << endl;
							break;
						}
					case 8:
						{
							cout<<"not implemented"<<endl;
							break;
							cout << "Analyzing the data to output for 8bit" << endl;
							unsigned int nunit = nifs * nchans;	//number of data in one time stamps= (number of channel) x (number of polarization) 
							unsigned int nlevel = atoi (Se_CMD_Key_Val (argv, argc, "-nf"));
							unsigned int nfilter = (2 << (nlevel)) - 1;
							unsigned int nchunk = nunit * nfilter;
							try
							{
								CLSRunningMedian clm[nunit];
								double *pintmax = new double[nunit];	//max value for v-<v> swap
								double *pintmin = new double[nunit];	//min swap for v-<v> swap
								double *prange = new double[nunit];	//range=(max-min)*255
								unsigned int *pinttmp = new unsigned int[nchunk];	//input series nfilterx nunit
								unsigned int *pinttran = new unsigned int[nchunk];	//transpose of input series
								unsigned char *pchrtmp = new unsigned char[nchunk];	//output series
								fread (pinttmp, sizeof (unsigned int), nchunk, fpInput);
								unsigned int *pa;
								unsigned int *pb;
								unsigned char *pch;
								//Transpose the data
								for (unsigned int i = 0; i < nunit; i++)
								{
									pa = pinttran + i * nfilter;
									pb = pinttmp + i;
									for (unsigned int j = 0; j < nfilter; j++)
									{
										pa[j] = pb[0];
										pb += nunit;
									}
								}
								//now pinttrans hold data in nunit (row) by nfilter (col) ways, populate the 
								//RMD swap space
								for (unsigned int i = 0; i < nunit; i++)
								{
									clm[i].Initialize (pinttran + i * nfilter, nlevel);
									pintmax[i] = 0;
									pintmin[i] = 0;
								}
								unsigned int nreadsize;
								unsigned int nt;
								double val;
								while (!feof (fpInput))
								{
									nreadsize =
										fread (pinttmp, sizeof (unsigned int), nchunk, fpInput);
									nt = nreadsize / nunit;
									pa = pinttmp;
									for (unsigned int j = 0; j < nt; j++)	//at each time
									{
										for (unsigned int i = 0; i < nunit; i++)
										{
											clm[i].Insert (pa[i]);
											val = (double) (pa[i]) - (double) (clm[i].value);
											pintmax[i] = val > pintmax[i] ? val : pintmax[i];
											pintmin[i] = val < pintmin[i] ? val : pintmin[i];
										}
										pa += nunit;
									}
								}
								for (unsigned int i = 0; i < nunit; i++)
									prange[i] = 255.0 / (pintmax[i] - pintmin[i]);
								//go back and read the head 
								rewind (fpInput);
								unsigned char *chrswap =
									new unsigned char[intTotalHeaderBytes];
								fread (chrswap, sizeof (unsigned char),
											 intTotalHeaderBytes, fpInput);
								//populated the filter
								fread (pinttmp, sizeof (unsigned int), nchunk, fpInput);
								//Transpose the data
								for (unsigned int i = 0; i < nunit; i++)
								{
									pa = pinttran + i * nfilter;
									pb = pinttmp + i;
									for (unsigned int j = 0; j < nfilter; j++)
									{
										pa[j] = pb[0];
										pb += nunit;
									}
								}
								for (unsigned int i = 0; i < nunit; i++)
									clm[i].Initialize (pinttran + i * nfilter, nlevel);
								while (!feof (fpInput))
								{
									nreadsize =
										fread (pinttmp, sizeof (unsigned int), nchunk, fpInput);
									nt = nreadsize / nunit;
									pa = pinttmp;
									pch = pchrtmp;
									for (unsigned int j = 0; j < nt; j++)
									{
										for (unsigned int i = 0; i < nunit; i++)
										{
											clm[i].Insert (pa[i]);
											pch[i] =
												(unsigned
												 char) (((double) (pa[i]) -
																 (clm[i].value) - pintmin[i]) * (prange[i]));
										}
										pa += nunit;
										pch += nunit;
									}
									fwrite (pchrtmp, sizeof (unsigned char), nreadsize,
													fpOutput);
								}
								break;
							}
							catch (bad_alloc)
							{
								cerr << "Error in allocating memory!" << endl;
								exit (0);
							}
							break;
						}
					case 16:
						{
							cout << "not implemented" << endl;
							break;
						}
					}
					break;
				}
			}

		}
	}
/*	else
	{
		cerr<<"What machine you are using? There is issues with integer operation!"<<endl;
	}
*/ fclose (fpInput);
	fclose (fpOutput);
	if (Se_CMD_Key_Exist (argv, argc, "-o2")) fclose (fpOutput2);
	if (bolMask) fclose(fpMask);
	return (0);
}

#define _CHAR_SWAP_SIZE (100)
/** \brief get a string from the header of *.fil file.
 *
 * This code is stealed from sigproc
 */
void get_string (FILE * inputfile, string & strtmp)
{
	int nchar;
	strtmp = "ERROR";
	fread (&nchar, sizeof (int), 1, inputfile);
	if (feof (inputfile))
	{
		cerr << "Error in reading the header of File" << endl;
		exit (0);
	}
	if (nchar > 80 || nchar < 1)
		return;
	char chrtmp[_CHAR_SWAP_SIZE];
	fread (chrtmp, nchar, 1, inputfile);
	chrtmp[nchar] = '\0';
	strtmp = chrtmp;
}

void put_string (FILE * outputfile, string & strtmp)
{
	int nchar = strtmp.length ();
	fwrite (&nchar, sizeof (int), 1, outputfile);
	fwrite (strtmp.c_str (), nchar, 1, outputfile);
}

void printhelp(char * cmdname)
{
		cout << "usage " << cmdname <<
		 	 " -f input.fil [-o2 smaller_file] [-start percentace_to_start (default value be 10) "<<"\n"
			<<" -end percentage_to_end (default value be 20)]-o output.fil -nbit Number_of_output_bit"<<"\n"
			<<"[-bandpass bandpass_file] [-maxmin scale_file] [-rfichan RFIlist] [-chanthre threshold_for_RFI]"<<"\n" <<"[-avrchan running_median_filter_size_for_bandpass] [-kb] [-var sigma] [-omask mask.fil sigma_of_mask]"
			<< endl;
		cout << endl;
		cout<<"-bandpass The original bandpass of the file will be write to bandpass_file"<<endl;
		cout<<"-maxmin Minimum and maximum of digiterizing levels will be write to scale_file"<<endl;
		cout<<"-rfichan Possible RFI channel will be write to RFIlistm where the threshold is specified by"<<endl;
		cout<<"-chanthre, where the threshold of the RFI level is default to be 1.2 sigma, which works well."<< endl;
		cout << "-avrchan The default running median filter size for RFI channel is 8." << endl;
		cout << endl;
		cout << "-kb to keep the bandpass" << endl;
		cout << endl;
		cout << "[-var sigma] use variance of each channel to determine the digitizing model, the sigma is the dynamical range"<<endl;
		cout<<endl;
		cout<< " [-omask mask.fil sigma_of_mask] generate a mask for signal beyond and below given threshold, where 1--- data is OK, 2 --- data is beyond threshold, 0 --- data is below threshold"<<endl;
		cout << "For simplicity one can use command line like this" << endl;
		cout << cmdname <<
			" -f 0329.fil -o 8bit.fil -nbit 8 -o2 smaller.fil -bandpass 0329_bandpass -maxmin 0329_scale -rfichan 0329_rfi -var 5"
			<< endl;
}
