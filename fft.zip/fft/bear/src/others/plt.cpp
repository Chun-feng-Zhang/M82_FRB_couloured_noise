#include <iostream>
#include <sedge.h>
#include <math.h>
#include "filterbank.h"
#include "aux.h"
using namespace std;

void printhelp(int argc, char * argv[]);

int	main(int argc, char * argv[])
{
		if(cpgbeg(0,Se_CMD_Key_Val(argv, argc, "-g") , 1, 1) != 1)
		exit(0);
	cpgask(0);
	cpgscr(0, 1,1,1);
	cpgscr(1, 0,0,0);

	cpgpap(8.3, 1.41);
		Se_PgText("\\Gamma_{\\int_{a}^{b} y^2 dy}^{bc} x^{2} dx",0.5,0.5,0, "fontsize=65");
	cpgend();
	exit(0);

	MATRIX2D mxres;
	SEQUENCE vdm, vw, vt;
	SEQUENCE vt_snr, vdm_snr;
	
		

	LoadFromTextFile(mxres, "dm_snr");
	vdm=mxres.ColVect(0);
	vdm_snr=mxres.ColVect(1);
	long int maxdmi=MaxIndex(vdm_snr);
	double OptDM=vdm(maxdmi);

	LoadFromTextFile(mxres, "t_snr");
	vt=mxres.ColVect(0);
	vt_snr=mxres.ColVect(1);
	long int maxti=MaxIndex(vt_snr);
	double OptT=vt(maxti);


	double thre1=30;
	double thre2=32;
	double thre3=35;

		//Plot DM-w-SNR
	cpgsvp(0.65, 0.9, 0.1, 0.15);
	VPlot(vdm, vdm_snr, "noymargin,fontsize=5,xlab=DM,ylab=S");
	VPlot(vdm,Ones(vdm)*thre1, "color=b,holdon");
	VPlot(vdm,Ones(vdm)*thre2, "color=g,holdon");
	VPlot(vdm,Ones(vdm)*thre3, "color=r,holdon");
	cpgsvp(0.65, 0.9, 0.15,0.30);
	LoadFromTextFile(mxres,"mxdmw", '#', 40000);
	LoadFromTextFile(vdm, "vdm");
	LoadFromTextFile(vw, "vw");
	Se_PgPcolor(vdm, log(vw)/log(10.0), mxres.T(), "noy,nox,colormap=parula,fontsize=5");
	SEQUENCE vsnr_w;
	vsnr_w=Zeros(mxres.Col);
	for (long int i=0;i<mxres.Col;i++)
		vsnr_w(i)=Max(mxres.ColVect(i));
	long int maxwi=MaxIndex(vsnr_w);
	double OptW=vw(maxwi);
	cpgsvp(0.55, 0.65, 0.15,0.30);
	VPlot(vsnr_w,log(vw)/log(10.0), "noymargin,fontsize=5,ylab=W,ylog,xlab=S");
	VPlot(Ones(vsnr_w)*thre1,log(vw)/log(10.0), "color=b,holdon");
	VPlot(Ones(vsnr_w)*thre2,log(vw)/log(10.0), "color=g,holdon");
	VPlot(Ones(vsnr_w)*thre3,log(vw)/log(10.0), "color=r,holdon");
	


	//plot orignal data and t-SNR
	//	detection SNR
	cpgsvp(0.3,0.9,0.45,0.55);
	VPlot(vt,vt_snr, "noxmargin,fontsize=5,xlab=t (s),ylab=S");
	VPlot(vt,Ones(vt)*thre1, "color=b,holdon");
	VPlot(vt,Ones(vt)*thre2, "color=g,holdon");
	VPlot(vt,Ones(vt)*thre3, "color=r,holdon");
		//oridat
	cpgsvp(0.3, 0.9, 0.75,0.95);
	LoadFromTextFile(mxres,"a.txt", '#', 100000);
	SEQUENCE vf,vfo;
	SEQUENCE vchan;
	LoadFromTextFile(vt, "vt");

	mxres=mxres.T();
	long int Nf_down=40;
	float dT_down=2e-3;
	float Tsamp=65e-6;
	float BW=-1;
	LoadFromTextFile(vf, "vf");
	vchan=Series(0,1,mxres.Row-1);
	vfo=vf;
	Se_DownSample_Average(vf, (long int )( (float)(mxres.Row) / Nf_down ));
	Se_MatDownSample_Average(mxres, (long int )( (float)(mxres.Row) / Nf_down ), (long int)(dT_down/Tsamp));
	Se_DownSample_Average(vt, (long int)(dT_down/Tsamp));

	Se_PgPcolor(vt,vf, mxres, "colormap=parula,nox,noy,fontsize=5");
	SaveToTextFile(mxres, "zz");
	SaveToTextFile(vt, "za");
	SaveToTextFile(vf, "zb");
		//t-dm-SNR
	LoadFromTextFile(vt, "vt");
	Se_DownSample_Average(vt, (long int)(dT_down/Tsamp));
	LoadFromTextFile(mxres,"mxdmt", '#', 1000000 );
	Se_MatDownSample_Average(mxres, 1, (long int)(dT_down/Tsamp));
	cpgsvp(0.3,0.9,0.55,0.75);
	Se_PgPcolor(vt,vdm, mxres, "colormap=parula,ylab=DM,nox,fontsize=5,bar");
	SEQUENCE xp(1),yp(1);
	xp(0)=OptT;
	yp(0)=OptDM;
	cout<<OptT<<"\t"<<OptDM<<endl;
	VPlot(xp,yp, "s=907,holdon,nox,noy,color=r,symbolsize=7");
		//t-prof
	SEQUENCE vprof;
	LoadFromTextFile(vprof,"vprof");
	Se_DownSample_Average(vprof, (long int)(dT_down/Tsamp));
	cpgsvp(0.3,0.9,0.35,0.45);
	VPlot(vt,vprof, "ylab=flux,fontsize=5,noxmargin,xlab=t (s)");

	//Plot f-Stat
	cpgsvp(0.1,0.3,0.75,0.95);
	SEQUENCE vsf;
	LoadFromTextFile(vsf, "vsf");
	LoadFromTextFile(vfo, "vf");
	VPlot(vsf,vfo, "reversey,reversex,xlab=S,ylab=f (MHz),fontsize=5");

	cpgsch(1.2);
	cpgsvp(0.1,0.9,0.95,1.0);
	cpgmtxt("BL",-1,0.5,0.5, "This is the title");

	cpgsvp(0.1,0.45,0.1,0.3);
	cpgmtxt("BL",0,0,0, "lalilalilala");


	cpgend();
	//DM-T
		/*
	MatComb(&vdm, &vsnr)
	DMvsSNR(vdm,vsnr, &fil);

	DM_w_vsSNR(vdm, vw, mxres,& fil);
	SaveToTextFile(mxres, "mxdmw");
	SaveToTextFile(vdm, "vdm");
	SaveToTextFile(vw, "vw");
	SaveToTextFile(mxres, "mxdmw");
	t_SNR(vt, vsnr, & fil);
	SaveToTextFile(MatComb(&vt,&vsnr), "t_snr");
	DM_t_vsSNR(vdm, vt, mxres, & fil);
	SaveToTextFile(vt, "vt");
	SaveToTextFile(mxres, "mxdmt");
	exit(0);

	exit(0);
	*/
}

void printhelp(int argc, char * argv[])
{
	cout<<"Usage :"<<endl;
	cout<<argv[0]<<" [arguments]"<<endl;
	cout<<"Where:"<<endl;
	cout<<
	    "   -f  input           Input filterbank file \n"<<
	    "   -z                  Use zero-DM RFI filter \n"<<

	    "   [-dms]      [0   ]  Dispersion Start value\n"<<
	    "   [-ddm]      [1   ]  Dispersion Step value\n"<<
	    "   [-dde]      [1000]  Dispersion End value\n"<<

	    "   [-nbox]     [15]    Number of boxcar filter\n"<<
	    "   [-snrloss]  [0.15]  Tolerent SNR loss for boxcar\n"<<
	    "   -o                  Output filterbank files\n"<<
	    endl;
}


