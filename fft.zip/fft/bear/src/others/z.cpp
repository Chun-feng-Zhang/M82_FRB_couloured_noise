/**\brief
 *
 * =====================================================================================
 *
 *       Filename:  aux.cpp
 *
 *    Description:  auxiliary functions
 *
 *        Version:  1.0
 *        Created:  2014年12月17日 17时28分04秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  K.J.Lee (),
 *   Organization:
 *
 * =====================================================================================
 */
#include "aux.h"


void DMvsSNR(SEQUENCE & vdm, SEQUENCE & snr, FilterBankData * pfil)
{
	vdm.New(pfil->Ndm);
	snr.New(pfil->Ndm);
	long int n=0;
	for (long int i=0; i<pfil->Nsubband; i++)
	{
		SubBandData * psub=pfil->pSubband+i;
		for (long int j=0; j<psub->NDM; j++)
		{
			TimeSeries * ptim=psub->pTim+j;
			TimeSeries * ftpt=(ptim->plink);
			double maxv=ftpt->ptim[0];
			for (long int k=0;k<ptim->Nbox;k++)
			{
				for (long int l=0;l<(ftpt+k)->Nsamples;l++)
				{
					if (maxv<(ftpt+k)->ptim[l])
						maxv=(ftpt+k)->ptim[l];
				}
			}
			vdm(n)=psub->pDM[j];
			snr(n)=maxv;
			n++;
		}
	}
}

void DM_w_vsSNR(SEQUENCE & vdm, SEQUENCE & vw, MATRIX2D & res, FilterBankData * pf)
{
	res.New(pf->Ndm, pf->Nbox);
	vw.New(pf->Nbox);
	vdm.New(pf->Ndm);
	long int n=0;
	for (long int i=0; i<pf->Nsubband; i++)
	{
		SubBandData * psub=pf->pSubband+i;
		for (long int j=0; j<psub->NDM; j++)
		{
			TimeSeries * ptim=psub->pTim+j;
			for (long int k=0; k<ptim->Nbox; k++)
			{
				TimeSeries * ftpt=(ptim->plink+k);
				float * pt=ftpt->ptim;
				long int m=ftpt->Nsamples;
				float maxv=pt[0];
				for (long int l=0; l<m; l++)
				{
					maxv=maxv>pt[l]?maxv:pt[l];
				}
				res(n,k)=maxv;
				vdm(n)=psub->pDM[j];
				vw(k)=pf->vBin[k]*pf->Tsamp;
			}
			n++;
		}
	}
}

void t_SNR(SEQUENCE & vt, SEQUENCE & vsnr, FilterBankData * pf)
{
	vt.New(pf->Nsamples);
	vsnr.New(pf->Nsamples);
	for(long int i=0; i<pf->Nsamples; i++)
		vt(i)=i*pf->Tsamp;

	long int n=0;
	for (long int l=0; l<pf->Nsamples; l++)
	{
		float maxv;
		maxv=pf->pSubband->pTim->plink->ptim[0];
		for (long int i=0; i<pf->Nsubband; i++)
		{
			SubBandData * psub=pf->pSubband+i;
			for (long int j=0; j<psub->NDM; j++)
			{
				TimeSeries * ptim=psub->pTim+j;
				TimeSeries * ftpt=(ptim->plink);
				for (long int k=0;k<ptim->Nbox;k++)
				{
					float * pt=(ftpt+k)->ptim;
					if (l<(ftpt+k)->Nsamples)
						if (maxv<pt[l])
							maxv=pt[l];
				}
			}
		}
		vsnr(l)=maxv;
	}

}
void DM_t_vsSNR(SEQUENCE & vdm, SEQUENCE & vt, MATRIX2D & res, FilterBankData * pf)
{
	res=Zeros(pf->Ndm, pf->Nsamples);
	vt.New(pf->Nsamples);
	vdm.New(pf->Ndm);
	for(long int i=0; i<pf->Nsamples; i++)
		vt(i)=i*pf->Tsamp;

	long int n=0;
	for (long int i=0; i<pf->Nsubband; i++)
	{
		SubBandData * psub=pf->pSubband+i;
		for (long int j=0; j<psub->NDM; j++)
		{
			//Get to the particular DM trial
			TimeSeries * ptim=psub->pTim+j;
			//l is the time index
			for (long int l=0; l<pf->Nsamples; l++)
			{
				float maxv;
				TimeSeries * ftpt=(ptim->plink);
				float * pt=ftpt->ptim;
				if (l<ftpt->Nsamples)
					maxv=pt[l];
				else
					maxv=pt[ftpt->Nsamples-1];

				for (long int k=1; k<ptim->Nbox; k++)
				{
					if (l<(ftpt+k)->Nsamples)
						if (maxv<(ftpt+k)->ptim[l])
							maxv=(ftpt+k)->ptim[l];
				}
				res(n,l)=maxv;
				vdm(n)=psub->pDM[j];
			}
			n++;
		}
	}
}
/**\brief calculate the statistical threshold of statistics
 * \param n the number of tries, i.e. Nsample*Ndm*Nbox
 * \param p the threshold of probability, i.e. 1e-3, 1e-4 etc.*/
double GetStatThreshold(double n, double p)
{
	double x=1;
	for (char i=0;i<40;i++)
		x=2*log(n)-0.4516-log(x)-log(p);
	return x;
}

void GetProfile(SEQUENCE & prof, FilterBankData * pfil)
{
	prof.New(pfil->Obj1D.Nsamples);
	for (long int i=0;i<prof.n;i++)
		prof(i)=pfil->Obj1D.ptim[i];
}
void GetfvsS(SEQUENCE & vf, SEQUENCE & s, double t, double dmv, double w, FilterBankData * pfil)
{
	s.New(pfil->Nchans);
	vf.New(pfil->Nchans);

	int fti;
	double maxf=pfil->frequency_table[0];
	for(long int i=0; i<pfil->Nchans; i++)
	{
		maxf=maxf>pfil->frequency_table[i]?maxf:pfil->frequency_table[i];
	}
	double ib=t/pfil->Tsamp;

	int maxdelay=0;
	long int ileft, iright;
	double res=0;
	long int dn=round(w/pfil->Tsamp);

	double frac=1.0/(dn*pfil->Sig_0DM);
	for (long int ich=0;ich<s.n;ich++)
	{
		vf(ich)=pfil->frequency_table[ich];
		ileft=round( (t+ DMDelay(dmv, pfil->frequency_table[ich], maxf)-w*0.5)/pfil->Tsamp );
		iright=round( (t+ DMDelay(dmv, pfil->frequency_table[ich], maxf)+w*0.5)/pfil->Tsamp );
		//confine the boundary
		ileft=ileft<0?0:ileft;
		iright=iright>pfil->Nsamples-1?pfil->Nsamples-1:iright;
		double mean=0;
		for (long int i=0;i<pfil->Nsamples;i++)
			mean+=pfil->pData[i*pfil->Nchans*pfil->Nifs + ich*pfil->Nifs+0];
		mean/=pfil->Nsamples;
		double tmp;
		for (long int i=ileft;i<iright;i++)
		{
			tmp=pfil->pData[i*pfil->Nchans*pfil->Nifs + ich*pfil->Nifs+0]-mean;
			res+=tmp;
		}
		s(ich)=res*res*frac;
	}
}
bool GetParVec(FilterBankData * pf, SEQUENCE & vdm, SEQUENCE & vw, SEQUENCE & vt)
{
	vt=Series(0,1,pf->Nsamples-1)*pf->Tsamp;
	vdm.New(pf->Ndm);
	vw.New(pf->Nbox);
	long int k=0;
	for (long int i=0; i<pf->Nsubband; i++)
	{
		SubBandData * psub=pf->pSubband+i;
		for (long int j=0; j<psub->NDM; j++)
		{
			vdm(k)=psub->pDM[j];
			k++;
		}
	}
	for (long int k=0; k<pf->Nbox;k++)
	{
		vw(k)=pf->vBin[k]*pf->Tsamp;
	}
}
float * FormSCube(FilterBankData * pfil)
{
	FilterBankData * pf=pfil;
	float * pto=new float [pf->Ndm*pf->Nbox*pf->Nsamples];
	//SEQUENCE tmp;
	//tmp.New(pf->Ndm*pf->Nbox*pf->Nsamples);
	long int ichan=0;
	for (long int i=0; i<pf->Nsubband; i++)
	{
		SubBandData * psub=pf->pSubband+i;
		for (long int j=0; j<psub->NDM; j++)
		{
			//Get to the particular DM trial
			TimeSeries * ptim=psub->pTim+j;
			//l is the time index
			for (long int isamp=0; isamp<pf->Nsamples; isamp++)
			{
				float maxv;
				TimeSeries * ftpt=(ptim->plink);
				float * pt=ftpt->ptim;
				for (long int ibox=0; ibox<ptim->Nbox; ibox++)
				{
					float *objpt=pto+ibox*(pf->Ndm)*(pf->Nsamples) + ichan*(pf->Nsamples) +isamp;
					if (isamp<(ftpt+ibox)->Nsamples)
					{
						objpt[0]=(ftpt+ibox)->ptim[isamp];
						//tmp( ibox*(pf->Ndm)*(pf->Nsamples) + ichan*(pf->Nsamples) 
						//+isamp)=objpt[0];
					}
					else
					{
						objpt[0]=0;
						//tmp(ibox*(pf->Ndm)*(pf->Nsamples) + ichan*(pf->Nsamples) 
						//+isamp)=0;
					}
				}
			}
			ichan++;
		}
	}
	//SaveToTextFile(tmp, "lala");
	return pto;
}
bool SearchForNextEvents(double thre, float * pt, char * mask, long int nt, long int ndm, long int nw, long int & it, long int & idm, long int & iw)
{
	long int ntot=nt*ndm*nw;
	float maxv=0;
	long int maxind=0;
	long int ind=0;
	bool getit=false;
	double mean=0;
	double var=0;
	for (long int i=0;i<ntot;i++) 
	{
		mean+=pt[i];
		var+=pt[i]*pt[i];
	}
	mean/=ntot;
	var/=ntot;
	double rms=sqrt(var-mean*mean);

	for (long int i=0;i<nw;i++)
	{
		for (long int j=0;j<ndm;j++)
		{
			for (long int k=0;k<nt;k++)
			{
				if (pt[ind]>maxv && mask[ind]==0)
				{
					maxv=pt[ind];
					maxind=ind;
					it=k;
					idm=j;
					iw=i;
					getit=true;
				}
				ind++;
			}
		}
	}
	if (!getit) return false;
	if (maxv<thre) return false;
	//Extend to the boundary
	LINKEDLIST<long int> Neib;
	Neib.Add(maxind);
	Neib._MoveToHead();
	mask[maxind]=1;
	while(Neib.p!=NULL)
	{
		//Get neighbor see if they satisfy the condition
		long int ic=*(Neib.p->Body);
		Neib.Delete();
		for(long int dws=-4; dws<=4; dws++)
		{
			for(long int ddm=-10; ddm<=10; ddm++)
			{
				for (long int dt=-10; dt<=10;dt++)
				{
					long int delta=dws*nt*ndm+ddm*nt+dt;
					long int ic1=ic+delta;
					if (ic1>=0 && ic1<ntot)
					{
						if (pt[ic1]> thre && pt[ic1]<pt[ic]+rms*0.3 && mask[ic1]==0)
						{
							mask[ic1]=1;
							Neib.Add(ic1);
						}
					}
				}
			}
		}
		//Add neihbor to the list
		Neib._MoveToHead();
	}
	//
	return true;
}
bool SearchForIsolatedEvents(double thre, float * pt, long int nt, long int ndm, long int nw, MATRIX2D & mxevt, long int maxNevt)
{
	long int ntot=nt*ndm*nw;
	char * mask=new char [ntot];
	for (long int i=0;i<ntot;i++) mask[i]=0;
	long int nevt=0;
	mxevt.New(maxNevt,3);
	long int it, idm, iw;
	while(SearchForNextEvents(thre, pt, mask, nt, ndm, nw, it, idm, iw))
	{
		mxevt(nevt, 0)=it;
		mxevt(nevt, 1)=idm;
		mxevt(nevt, 2)=iw;
		nevt++;
		if (nevt==maxNevt)
			break;
	}
	delete [] mask;
	if (nevt==0) 
	{
		mxevt.Free();
		return false;
	}
	else
	{
		mxevt=mxevt.Part(0,nevt-1, 0,2);
		return true;
	}
}

