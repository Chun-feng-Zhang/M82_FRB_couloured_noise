/**\brief
 *
 * =====================================================================================
 *
 *       Filename:  tst_shm.cpp
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2016年04月30日 20时39分27秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  K.J.Lee (), 
 *   Organization:  
 *
 * =====================================================================================
 */



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sedge.h>
using namespace std;
//#define SHM_SIZE 1000000000  /* make it a 1K shared memory segment */
#define SHM_SIZE 1073741824
#define SHFILE "lalala"
int main(int argc, char *argv[])
{
		void * add_r=NULL;
		void * add_w=NULL;
		int fd=-1;
		if (argc==1)
		{
				fd=shm_open(SHFILE, O_RDWR|O_CREAT, 0777);
				if (fd==-1)
				{
					perror("shm failed: ");
					exit(1);
				}
				if(ftruncate(fd,SHM_SIZE)==-1)
				{
					perror("ftruncate faile: ");
					exit(1);
				}
				add_r=mmap(NULL, SHM_SIZE, PROT_READ, MAP_SHARED, fd, SEEK_SET);
				if (add_r==NULL)
				{
					perror("mmap failed: ");
					exit(1);
				}
				for (long int i=0;i<SHM_SIZE/sizeof(long int);i++)
				{
					if (((long int * ) add_r)[i]!=i)
						cerr<<"mem error"<<endl;
				}
				if (munmap(add_r, SHM_SIZE)==-1)
				{
					perror("munmap failed: ");
					exit(1);
				}
				if (shm_unlink(SHFILE)==-1)
				{
					perror("shm_unlink failed: ");
					exit(1);
				}

		}
		else
		{
			fd=shm_open(SHFILE, O_RDWR|O_CREAT, 0777);
			if (fd==-1)
			{
				perror("shm failed: ");
				exit(1);
			}
			if(ftruncate(fd,SHM_SIZE)==-1)
			{
				perror("ftruncate faile: ");
				exit(1);
			}
			add_w=mmap(NULL, SHM_SIZE, PROT_WRITE, MAP_SHARED, fd, SEEK_SET);
			if (add_w==NULL)
			{
				perror("mmap failed: ");
				exit(1);
			}
			memcpy(add_w, argv[1], strlen(argv[1]));
			for (long int i=0;i<SHM_SIZE/sizeof(long int);i++)
				((long int *) add_w)[i]=i;
			
			if (munmap(add_w, SHM_SIZE)==-1)
			{
				perror("munmap failed: ");
				exit(1);
			}
			
		}
    return 0;
}
