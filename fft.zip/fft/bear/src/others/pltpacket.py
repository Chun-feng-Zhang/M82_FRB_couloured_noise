#!/usr/bin/python
import numpy as np
import pylab as plt
from os import *
import sys
system('grep \'lost\' %s | awk \'{print $6}\' > lost.txt' % sys.argv[1])
system('grep \'void\' %s | awk \'{print $6}\' > void.txt' % sys.argv[1])
system('grep \'block\' %s | awk \'{print $6}\' > block.txt' % sys.argv[1])
system('grep \'MJD time is\' %s | awk \'{print $3}\' | awk \'BEGIN{FS=\":\"}{print  $2}\' > mjd.txt' % sys.argv[1])
void=np.loadtxt('void.txt');
n=len(void)
block=np.loadtxt('block.txt');
n=np.min([len(block), n])
lost=np.loadtxt('lost.txt');
n=np.min([len(lost), n])
vt=np.loadtxt('mjd.txt');
n=np.min([len(vt), n])

ind=range(0,n);
vt=vt[ind]
block=block[ind]
void=void[ind]
lost=lost[ind]
print "packet lost rate", float(np.sum(lost))/(len(lost)*26.e4)
vt=(vt-vt[0])*24;
plt.figure()
plt.subplot(3,1,1)
plt.plot(vt,void)
plt.subplot(3,1,2)
plt.plot(vt, block)
plt.subplot(3,1,3)

plt.plot(vt, lost, '*')
plt.title("lost packet="+str( np.sum(lost)))
plt.show()

