/*
 ============================================================================
 Name        : 
 Author      :
 Version     :
 Copyright   :
 Description :
 ============================================================================
 */
//gcc threads_ringbuffer.c  -I/usr/include/python2.6 -shared -L/usr/bin -fpic -lpython2.6 -lpthread -o threads_ringbuffer.so
#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <sedge.h>
using namespace std;
#define NMAX 100000 //size of buffer:NMAX*FRAME,200MBytes
#define UDP_IP "127.0.0.1" //hpc address and port
#define UDP_PORT 6000
#define FRAME 1000 //2048 bytes data + 8 bytes time information

pthread_t thread[2]; //defined two threads
pthread_mutex_t mut;
int size=0; //data size
int igrab=0; //for write
int iwrite=0; //for read
int n=0; //number of frame
int dataWrite_flag,dataGrab_flag;
FILE *sfp; //file for data storage
char data[NMAX][FRAME]; //memory buffer for fast data exchange
char data_frame[FRAME];
int serverSocket;
struct sockaddr_in serverAddr;
unsigned int serverAddr_len=sizeof(serverAddr);//16
struct timeval currenttime,starttime,finishtime;

int main(void)
{

	int val=1;
	int nRecvBuf=65536;	
	serverSocket = socket(AF_INET, SOCK_DGRAM	, 0); // built and set Socket	
	if (serverSocket==-1)
	{
		cerr<<"Can not get socket descriptor"<<endl;
		exit(0);
	}
	setsockopt(serverSocket, SOL_SOCKET, SO_REUSEADDR, &val, sizeof(val)); // set socket option
	setsockopt(serverSocket, SOL_SOCKET, SO_RCVBUF, &nRecvBuf, sizeof(float)); // set size of receive buffer
	// address binding
	bzero(&serverAddr,sizeof(serverAddr));
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(UDP_PORT);
	serverAddr.sin_addr.s_addr = inet_addr(UDP_IP);
	int rc = bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr));
	if (rc == -1) {
	 printf("Bad bind\n");
	 return 0;
	}
	cout<<"Start getting data"<<endl;
	serverAddr_len=sizeof(serverAddr);
	while(true)
	{
	int rev_num=recvfrom(serverSocket,data_frame,FRAME,0,(struct sockaddr*)&serverAddr, &serverAddr_len);
	cout<<"Received byte"<<rev_num<<endl;
	data_frame[rev_num]='\0';
	cout<<data_frame<<endl;
	}
	sizeof(serverSocket);
}
