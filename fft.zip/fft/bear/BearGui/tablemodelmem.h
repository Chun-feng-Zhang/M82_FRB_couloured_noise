//============================================================================
// Name        : tablemodelmem.h
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#ifndef TABLEMODELMEM_H
#define TABLEMODELMEM_H

#include <QAbstractTableModel>
#include <QStringList>
#include <QProcess>
#include <QTimerEvent>
#include <QDebug>

#include <dialogsettings.h>
#include <ui_dialogsettings.h>

class TableModelMem : public QAbstractTableModel
{
public:
    TableModelMem(QObject * parent=0);
    ~TableModelMem();
    virtual int rowCount(const QModelIndex & parent=QModelIndex()) const;
    virtual int columnCount(const QModelIndex &parent=QModelIndex()) const;
    QVariant data(const QModelIndex &index, int role) const;
    QVariant headerData(int section, Qt::Orientation orientation, int role) const;
    void timerEvent(QTimerEvent * event);
    void updateModel();

private:
    void getMemInfo();

public:
    QStringList * pMemInfo;
    QStringList Header;
    int rows;
    int columns;

private:
    int m_timerId;
};

#endif // TABLEMODELMEM_H
