//============================================================================
// Name        : applicationplus.cpp
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#include "applicationplus.h"

applicationplus::applicationplus(int& argc, char** argv) :
    QApplication(argc, argv) {}


bool applicationplus::notify(QObject* receiver, QEvent* event)
{
    bool done = true;
    try
    {
        done = QApplication::notify(receiver, event);
    }
    catch (const std::exception& ex)
    {
        //qDebug()<<tr("Warning: something wrong!!!");
    }

    return done;
}
