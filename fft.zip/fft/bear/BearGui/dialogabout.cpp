//============================================================================
// Name        : dialogabout.cpp
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#include "dialogabout.h"
#include "ui_dialogabout.h"

DialogAbout::DialogAbout(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogAbout)
{
    ui->setupUi(this);
    connect(ui->pushButtonClose, SIGNAL(clicked(bool)), this, SLOT(accept()));
}

DialogAbout::~DialogAbout()
{
    delete ui;
}
