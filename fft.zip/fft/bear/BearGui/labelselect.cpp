//============================================================================
// Name        : labelselect.cpp
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#include "labelselect.h"

LabelSelect::LabelSelect(QWidget *parent):QLabel(parent)
{
    x=0;
    y=0;
    w=0;
    h=0;
}

void LabelSelect::paintEvent(QPaintEvent *event)
{
    QLabel::paintEvent(event);//先调用父类的paintEvent为了显示'背景'!!!
    QPainter painter(this);
    painter.setPen(QPen(Qt::red,2));
    painter.drawRect(QRect(x-w/2,y-h/2,w,h));
}
