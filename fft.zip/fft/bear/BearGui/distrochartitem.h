//============================================================================
// Name        : distrochartitem.h
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#ifndef DISTROCHARTITEM_H
#define DISTROCHARTITEM_H

#include <QWidget>

#include <qwt_plot_barchart.h>
#include <qwt_column_symbol.h>

class DistroChartItem : public QwtPlotBarChart
{
public:
    DistroChartItem();
    void addDistro( const QString &distro, const QColor &color );
    virtual QwtColumnSymbol *specialSymbol(int index, const QPointF& ) const;
    virtual QwtText barTitle( int sampleIndex ) const;

private:
    QList<QColor> d_colors;
    QList<QString> d_distros;
};

#endif // DISTROCHARTITEM_H
