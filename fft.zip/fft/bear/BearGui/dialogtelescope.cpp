//============================================================================
// Name        : dialogtelescope.cpp
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#include "dialogtelescope.h"
#include "ui_dialogtelescope.h"

DialogTelescope::DialogTelescope(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogTelescope)
{
    ui->setupUi(this);

    // Assign a title
    ui->qwtPlotPower->setTitle( "Power vs time" );

    //qwtPlotPower
    QwtPlotCanvas * power_canvas = new QwtPlotCanvas();
    power_canvas->setFrameStyle( QFrame::Box | QFrame::Plain );
    power_canvas->setLineWidth( 1 );
    power_canvas->setPalette( Qt::white );

    ui->qwtPlotPower->setCanvas(power_canvas);

    // Insert grid
    QwtPlotGrid * power_grid = new QwtPlotGrid();
    power_grid->attach(ui->qwtPlotPower);

    // Insert curve
    power_curve = new QwtPlotCurve( "Data Moving Right" );
    power_curve->setPen( Qt::black );

    DialogSettings tmp;
    RingBuffer *buffer = new RingBuffer( tmp.ui->lineEditNpoints->text().toLongLong() );
    power_curve->setData(buffer);
    QPen pen;
    pen.setColor(QColor("red"));
    pen.setWidth(5);
    power_curve->setPen(pen);
    power_curve->attach(ui->qwtPlotPower);

    // Axis
    double timelen = 60;
    ui->qwtPlotPower-> setAxisTitle( QwtPlot::xBottom, "time (s)" );
    ui->qwtPlotPower->setAxisScale( QwtPlot::xBottom, -timelen, 0.0 );

    double powermin = 0;
    double powermax = 128;
    ui->qwtPlotPower-> setAxisTitle( QwtPlot::yLeft, "power" );
    ui->qwtPlotPower->setAxisScale( QwtPlot::yLeft, powermin, powermax );

    //
    proctrl=new ProcCtrl(this);
    proctrl->StartProcMemory();
    proctrl->StartProcDumpStat();
    proctrl->StartProUdpRecv();

    QObject::connect(proctrl->ProcDumpStat, SIGNAL(readyReadStandardOutput()), this, SLOT(onpowerchg()));
    QObject::connect(ui->lineEditTimelen, SIGNAL(returnPressed()), this, SLOT(onaxischg()));
    QObject::connect(ui->lineEditPowerMin, SIGNAL(returnPressed()), this, SLOT(onaxischg()));
    QObject::connect(ui->lineEditPowerMax, SIGNAL(returnPressed()), this, SLOT(onaxischg()));

}

DialogTelescope::~DialogTelescope()
{
    delete ui;
    delete proctrl;
}

void DialogTelescope::onpowerchg()
{
    QString StrMJD;
    QString StrPower;

    QString StrPowerInfo=QString::fromLocal8Bit(proctrl->ProcDumpStat->readAllStandardOutput());
    QStringList ListPowerInfo = StrPowerInfo.split("\n",QString::SkipEmptyParts);
    for (long int i=0; i<ListPowerInfo.size(); i++)
    {
        //qDebug()<<ListPacketInfo.at(i);
        if (ListPowerInfo.at(i).startsWith("MJD"))
            StrMJD=ListPowerInfo.at(i).split(":",QString::SkipEmptyParts).at(1).simplified();
        else if (ListPowerInfo.at(i).startsWith("power"))
            StrPower=ListPowerInfo.at(i).split(":",QString::SkipEmptyParts).at(1).simplified();
    }

    //qDebug()<<StrPower<<endl;

    double mjd = StrMJD.toDouble();
    double power = StrPower.toDouble();

    ui->lcdNumberPower->display(power);

    RingBuffer *buffer = static_cast<RingBuffer *>(power_curve->data());
    buffer->setSample(mjd, power);
    buffer->setReferenceTime(mjd);

    ui->qwtPlotPower->replot();
}

void DialogTelescope::onaxischg()
{
    double timelen = ui->lineEditTimelen->text().toDouble();

    ui->qwtPlotPower->setAxisScale( QwtPlot::xBottom, -timelen, 0.0 );

    double powermin = ui->lineEditPowerMin->text().toDouble();
    double powermax = ui->lineEditPowerMax->text().toDouble();

    ui->qwtPlotPower->setAxisScale( QwtPlot::yLeft, powermin, powermax );
}

