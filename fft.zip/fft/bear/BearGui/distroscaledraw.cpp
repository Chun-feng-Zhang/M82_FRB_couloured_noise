//============================================================================
// Name        : distroscaledraw.cpp
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#include "distroscaledraw.h"

DistroScaleDraw::DistroScaleDraw( Qt::Orientation orientation, const QStringList &labels ):d_labels( labels )
{
    setTickLength( QwtScaleDiv::MinorTick, 0 );
    setTickLength( QwtScaleDiv::MediumTick, 0 );
    setTickLength( QwtScaleDiv::MajorTick, 2 );

    enableComponent( QwtScaleDraw::Backbone, false );

    if ( orientation == Qt::Vertical )
    {
        setLabelRotation( -60.0 );
    }
    else
    {
        setLabelRotation( -20.0 );
    }

    setLabelAlignment( Qt::AlignLeft | Qt::AlignVCenter );
}

QwtText DistroScaleDraw::label( double value ) const
{
    QwtText lbl;

    const int index = qRound( value );
    if ( index >= 0 && index < d_labels.size() )
    {
        lbl = d_labels[ index ];
    }

    return lbl;
}
