1. Follow libaries need to be install first.

	/* For ubuntu */

		libqt4-dev: sudo apt-get install libqt4-dev

		libwcstools-dev: sudo apt-get install libwcstools-dev
                        
			edit bear.pro replace lwcs by lwcstools

			add in /usr/local/wcstools/wcs.h (line 584)

			void fk52gal (      /* Convert J2000(FK5) to galactic coordinates */
			double *dtheta, /* Right ascension in degrees (J2000 in) */
			double *dphi);  /* Declination in degrees (J2000 in) */ 

		libqwt-dev: sudo apt-get install libqwt-dev

	/* For centos */
	
		libqt4-dev: Download source from "download.qt.io/archive/qt/4.8/4.8.6"
                    	    sudo ./configure -prefix /usr/local
                    	    sudo gmake
                    	    sudo gmake install

        	libwcstools-dev: Download source from "http://tdc-www.harvard.edu/software/wcstools/wcstools-3.9.4.tar.gz"
                         	 sudo make all
                         	 cp libwcs/*.a in /usr/local/lib
                         	 cp libwcs/*.h in /usr/local/include
                         	 edit bear.pro replace lwcstools by lwcs

	                	 add in wcs.h (line 584)

        	        	 void fk52gal (      /* Convert J2000(FK5) to galactic coordinates */
                		 double *dtheta, /* Right ascension in degrees (J2000 in) */
                		 double *dphi);  /* Declination in degrees (J2000 in) */

        	libqwt-dev: yum install qwt-devel.x86_64

2. You must install the latest BEAR.

3. Install

	qmake (qmake-qt4)             /* qmake version must be qt4 (/usr/lib/x86_64-linux-gnu/qt4/bin/qmake)*/
	make
	make clean
