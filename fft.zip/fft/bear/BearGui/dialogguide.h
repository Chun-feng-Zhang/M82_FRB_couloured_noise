//============================================================================
// Name        : dialogguide.h
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#ifndef DIALOGGUIDE_H
#define DIALOGGUIDE_H

#include <QDialog>

namespace Ui {
class DialogGuide;
}

class DialogGuide : public QDialog
{
    Q_OBJECT

public:
    explicit DialogGuide(QWidget *parent = 0);
    ~DialogGuide();

public:
    Ui::DialogGuide *ui;
};

#endif // DIALOGGUIDE_H
