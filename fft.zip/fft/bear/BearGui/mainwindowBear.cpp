//============================================================================
// Name        : mainwindowBear.cpp
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#include "mainwindowBear.h"
#include "ui_mainwindowBear.h"

MainWindowBear::MainWindowBear(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindowBear)
{
    ui->setupUi(this);

    dlgset= new DialogSettings(this);
    QString nchans=dlgset->ui->lineEditNchans->text();
    npacketlen=nchans.toInt()*4+8;

    dlgtest = NULL;

    ModelMem=new TableModelMem();
    ui->tableViewMem->setModel(ModelMem);
    ui->tableViewMem->verticalHeader()->hide();

    connect(ModelMem, SIGNAL(modelReset()), this, SLOT(onmemchg()));

    counts=0;
    tmpcounts=0;

    ui->DialPacket->setScale(0,32);
    ui->DialPacket->setScaleMaxMinor(16);
    //ui->DialPacket->setScaleMaxMajor(10);
    ui->DialPacket->setScaleStepSize(4);
    ui->DialPacket->setValue(0);

    ui->labelPng->setScaledContents(true);

    ui->labelRadioSky->setScaledContents(true);

    if (!ShowPng(ui->labelRadioSky, "RadioSky.gif"))
        QMessageBox::information(this, "Warning", "Warning: Can't show radio sky map!!!");

    ui->statusBar->setSizeGripEnabled(false);

    ui->tableViewMem->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->tableViewMem->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    ui->LedDisk->setOnColor1(QColor(0, 255, 0));
    ui->LedDisk->setOnColor2(QColor(0, 255, 0));
    ui->LedDisk->setOffColor1(QColor(255, 0, 0));
    ui->LedDisk->setOffColor2(QColor(255, 0, 0));

    ui->LedMem->setOnColor1(QColor(0, 255, 0));
    ui->LedMem->setOnColor2(QColor(0, 255, 0));
    ui->LedMem->setOffColor1(QColor(255, 0, 0));
    ui->LedMem->setOffColor2(QColor(255, 0, 0));

    ui->LedFig->setOnColor1(QColor(0, 255, 0));
    ui->LedFig->setOnColor2(QColor(0, 255, 0));
    ui->LedFig->setOffColor1(QColor(25, 46, 65));
    ui->LedFig->setOffColor2(QColor(25, 46, 65));

    if((m_timerId1=startTimer(1000)) == 0)
    {
        QMessageBox::information(this, "Error", "Error: Can't start the timer!!!");
    }
}

MainWindowBear::~MainWindowBear()
{
    if (proctrl != NULL)
        delete proctrl;

    delete ui;
    delete dlgset;
    if (dlgtest != NULL)
    {
        delete dlgtest;
        dlgtest = NULL;
    }
    delete ModelMem;
}

bool MainWindowBear::ShowPng(QLabel * label, QString filename)
{
    QImage * frbpng=new QImage;
    if (!(frbpng->load(filename)))
    {
        //QMessageBox::information(this,tr("Failed"),tr("Can't open output image"));
        delete frbpng;
        return false;
    }

    label->setPixmap(QPixmap::fromImage(*frbpng));

    delete frbpng;

    return true;
}

bool MainWindowBear::ShowPng(LabelSelect * label, QString filename)
{
    QImage * frbpng=new QImage;
    if (!(frbpng->load(filename)))
    {
        QMessageBox::information(this,tr("Failed"),tr("Can't open output image"));
        delete frbpng;
        return false;
    }

    label->setPixmap(QPixmap::fromImage(*frbpng));

    delete frbpng;

    return true;
}

void MainWindowBear::ondirpngchg()
{
    if (proctrl->ProcSearch ==NULL)
        return;
    if (proctrl->ProcSearch->state()==QProcess::NotRunning)
        return;

    QString StrNewGraphs=QString::fromLocal8Bit(proctrl->ProcSearch->readAllStandardOutput());
    //qDebug()<<StrNewGraphs;
    QStringList ListNewGraphs=StrNewGraphs.split("\n", QString::SkipEmptyParts);
    QStringList ListPNGs;
    for (long int i=0; i<ListNewGraphs.size(); i++)
    {
        if (ListNewGraphs.at(i).startsWith("GraphName"))
        {
            ListPNGs<<ListNewGraphs.at(i).split(":",QString::SkipEmptyParts).at(1).simplified();
        }
    }
    QString path=dlgset->ui->lineEditFigPath->text();
    if (ListPNGs.size()==0) return;
    for (long int i=0; i<ListPNGs.size(); i++)
    {
        QString pathpng=path+QDir::separator()+ListPNGs.at(i);
        qDebug()<<pathpng;
        ShowPng(ui->labelPng, pathpng);
    }

    if (ListPNGs.size() > 0)
        ui->LedFig->setChecked(true);
}

void MainWindowBear::timerEvent(QTimerEvent * event)
{
    if (event->timerId() == m_timerId1)
    {
        GetDiskInfo();
    }
    else if (event->timerId() == m_timerDisk)
    {
        ui->LedDisk->toggle();
    }
    else if (event->timerId() == m_timerMem)
    {
        ui->LedMem->toggle();
    }
    else if (event->timerId() == m_timerFig)
    {
        ui->LedFig->setChecked(false);
    }
    else if (event->timerId() == m_timerId2)
    {
        counts++;
        ui->lineEditRunTime->setText(QString::number(counts)+tr("s"));
    }
}

void MainWindowBear::GetPacketInfo()
{
    QString StrPacketInfo=QString::fromLocal8Bit(proctrl->ProcUdp->readAllStandardOutput());
    QStringList ListPacketInfo= StrPacketInfo.split("\n",QString::SkipEmptyParts);
    for (long int i=0; i<ListPacketInfo.size(); i++)
    {
        //qDebug()<<ListPacketInfo.at(i);
        if (ListPacketInfo.at(i).startsWith("PacketSend"))
            StrPacketSend=ListPacketInfo.at(i).split(":",QString::SkipEmptyParts).at(1).simplified();
        else if (ListPacketInfo.at(i).startsWith("PacketRecv"))
            StrPacketRecv=ListPacketInfo.at(i).split(":",QString::SkipEmptyParts).at(1).simplified();
        else if (ListPacketInfo.at(i).startsWith("PacketLost"))
            StrPacketLost=ListPacketInfo.at(i).split(":",QString::SkipEmptyParts).at(1).simplified();
        else if (ListPacketInfo.at(i).startsWith("LostRate"))
            StrPacketRate=ListPacketInfo.at(i).split(":",QString::SkipEmptyParts).at(1).simplified();
    }
    ui->lineEditPacketSend->setText(StrPacketSend);
    ui->lineEditPacketRecv->setText(StrPacketRecv);
    ui->lineEditPacketLost->setText(StrPacketLost);
    ui->lineEditPacketLostrate->setText(StrPacketRate);

}

void MainWindowBear::on_actionGeneral_Settings_triggered()
{
    dlgset->show();
    QString nchans=dlgset->ui->lineEditNchans->text();
    npacketlen=nchans.toInt()*4+8;
}

void MainWindowBear::on_actionSend_Test_Udp_Packets_triggered()
{
    dlgtest= new DialogTest(this);
    dlgtest->exec();
}

void MainWindowBear::on_actionStart_triggered()
{
    proctrl = new ProcCtrl(this);

    if (dlgset->ui->lineEditNch->text() != dlgset->ui->lineEditBanduse->text())
    {
        QMessageBox::information(this, "Error", "Error: The search parameter 'nch' must be equal to the socket parameter 'Banduse'!!!");
        return;
    }

    ui->lineEditBlockNumber->setText(dlgset->ui->lineEditBlockNumber->text());
    ui->lineEditBlockSize->setText(dlgset->ui->lineEditBlockSize->text()+dlgset->ui->comboBoxUnit->currentText());
    ui->lineEditProcessNumber->setText(dlgset->ui->lineEditProcess->text());

    proctrl->StartProcMemory();
    if (!dlgset->ui->checkBoxRaw->isChecked())
        proctrl->StartProcSearch();
        for (long int i=0; i<proctrl->nprocsch; i++)
        {
            QObject::connect(&proctrl->ProcSearch[i], SIGNAL(readyReadStandardOutput()), this, SLOT(ondirpngchg()));
        }

    proctrl->StartProcSave();
    proctrl->StartProUdpRecv();
    QObject::connect(proctrl->ProcUdp, SIGNAL(readyReadStandardOutput()), this, SLOT(onpacketchg()));

    counts=0;

    if((m_timerFig=startTimer(1000)) == 0)
    {
        QMessageBox::information(this, "Error", "Error: Can't start the timer!!!");
    }
    if((m_timerId2=startTimer(1000)) == 0)
    {
        QMessageBox::information(this, "Error", "Error: Can't start the timer!!!");
    }

    ui->actionStart->setEnabled(false);
    ui->actionStop->setEnabled(true);

}

void MainWindowBear::on_actionStop_triggered()
{
    killTimer(m_timerId1);
    killTimer(m_timerId2);

    ui->DialPacket->setValue(0);

    delete proctrl;
    if (dlgtest != NULL)
    {
        delete dlgtest;
        dlgtest = NULL;
    }

    proctrl = NULL;

    ui->actionStart->setEnabled(true);
    ui->actionStop->setEnabled(false);

}

void MainWindowBear::on_actionGuide_triggered()
{
    DialogGuide tmp;
    tmp.ui->textEditGuide->setReadOnly(true);
    tmp.exec();
}

bool MainWindowBear::GetDiskInfo()
{
    QString StrDatPath=dlgset->ui->lineEditDatPath->text();
    QString path=QDir::currentPath();
    QDir::setCurrent(StrDatPath);

    if (!QFile::exists("tmp.dat"))
    {
        QFile file("tmp.dat");
        if (!file.open(QIODevice::WriteOnly))
            return false;
        file.close();
    }

    struct statvfs buf;

    if (statvfs("tmp.dat", &buf) == -1)
        return false;

    long int freespace=buf.f_bfree*buf.f_bsize;
    long int totspace=buf.f_blocks*buf.f_frsize;

    int freeratio=freespace*100/totspace;

    QString strfree;
    if (freespace >= 1024)
    {
        freespace/=1024;
        strfree=QString::number(freespace)+tr("KB");
        if (freespace >= 1024)
        {
            freespace/=1024;
            strfree=QString::number(freespace)+tr("MB");
            if (freespace >= 1024)
            {
                freespace/=1024;
                strfree=QString::number(freespace)+tr("GB");
                if (freespace >=1024)
                {
                    freespace/=1024;
                    strfree=QString::number(freespace)+tr("TB");
                }
            }
        }
    }

    ui->lineEditFreeDiskSpace->setText(strfree);

    ui->progressBarDisk->setValue(freeratio);

    if (freeratio < 10)
    {
        m_timerDisk=startTimer(500);
    }
    else
    {
        killTimer(m_timerDisk);

        ui->LedDisk->setChecked(true);
    }

    QDir::setCurrent(path);

    return true;
}

void MainWindowBear::onpacketchg()
{
    if (!ui->lineEditPacketSend->text().isEmpty())
    {
        double npacketsend0=ui->lineEditPacketSend->text().toDouble();
        GetPacketInfo();
        double npacketsend1=ui->lineEditPacketSend->text().toDouble();
        double netspeed=(npacketsend1-npacketsend0)*npacketlen/1048576/(counts-tmpcounts);

        tmpcounts=counts;

        //qDebug()<<QString::number(netspeed);

        ui->DialPacket->setValue(netspeed);
    }
    else
    {
        tmpcounts=counts;
        GetPacketInfo();
    }
}

void MainWindowBear::onmemchg()
{
    int ne=0,no=0,ns=0,nw=0,nr=0;
    for (long int i=0; i<ModelMem->rows; i++)
    {
        QString tmp=ModelMem->pMemInfo[i].at(2);
        if (tmp == "E")
            ++ne;
        else if (tmp == "O")
            ++no;
        else if (tmp == "S")
            ++ns;
        else if (tmp == "W")
            ++nw;
        else if (tmp == "R")
            ++nr;
    }

    ui->StatMem->HintsMem[0]=ne;
    ui->StatMem->HintsMem[1]=no;
    ui->StatMem->HintsMem[2]=ns;
    ui->StatMem->HintsMem[3]=nw;
    ui->StatMem->HintsMem[4]=nr;
    ui->StatMem->updateHits();

    if ((ne+no+ns+nw+nr) == 0)
    {
        ui->LedMem->setChecked(false);
    }
    else if ((ne+no+ns+nw+nr)>0 && ne<1)
    {
        m_timerMem=startTimer(500);
    }
    else
    {
        killTimer(m_timerMem);

        ui->LedMem->setChecked(true);
    }
}

void MainWindowBear::GetSrcGalCoor()
{
    char rastr0[32];
    char decstr0[32];

    strcpy(rastr0, StrRa.toStdString().c_str());
    strcpy(decstr0, StrDec.toStdString().c_str());

    double dtheta=str2ra(rastr0);
    double dphi=str2dec(decstr0);

    fk52gal(&dtheta, &dphi);

    StrGL=QString::number(dtheta, 'g', 8);
    StrGB=QString::number(dphi,'g', 8);
}

void MainWindowBear::on_lineEditRA_textChanged(const QString &arg1)
{
    StrRa=ui->lineEditRA->text();
    StrDec=ui->lineEditDec->text();
    GetSrcGalCoor();
    QString StrMessage=tr("GL= ")+StrGL+tr("    ")+tr("GB= ")+StrGB;
    ui->statusBar->showMessage(StrMessage);

    GetPosition();
}

void MainWindowBear::on_lineEditDec_textChanged(const QString &arg1)
{
    StrRa=ui->lineEditRA->text();
    StrDec=ui->lineEditDec->text();
    GetSrcGalCoor();
    QString StrMessage=tr("GL= ")+StrGL+tr("    ")+tr("GB= ")+StrGB;
    ui->statusBar->showMessage(StrMessage);

    GetPosition();
}

void MainWindowBear::GetPosition()
{
    double gl=StrGL.toDouble();
    double gb=StrGB.toDouble();

    if (gl<180)
        gl=-gl;
    else
        gl=360-gl;

    gl=gl/180*3.1415926;
    gb=gb/180*3.1415926;

    double x=cos(gb)*sin(gl/2)/sqrt(1+cos(gb)*cos(gl/2));
    double y=sin(gb)/sqrt(1+cos(gb)*cos(gl/2));

    x=ui->labelRadioSky->width()/2.*x;
    y=ui->labelRadioSky->height()/2.*y;

    x=x+ui->labelRadioSky->width()/2.;
    y=-y+ui->labelRadioSky->height()/2.;

    ui->labelRadioSky->x=(int) x;
    ui->labelRadioSky->y=(int) y;
    ui->labelRadioSky->w=20;
    ui->labelRadioSky->h=20;

    ui->labelRadioSky->update();
}


void MainWindowBear::on_actionAbout_BearGui_triggered()
{
    DialogAbout tmp;
    tmp.exec();
}

void MainWindowBear::closeEvent(QCloseEvent *event)
{
    QMessageBox message(QMessageBox::Warning,"Exit","Really to exit?",QMessageBox::Yes|QMessageBox::No,NULL);
    if (message.exec()==QMessageBox::Yes)
    {
        event->accept();
    }
    else
    {
        event->ignore();
    }
}

void MainWindowBear::on_actionTelescope_Monitoring_triggered()
{
    proctrl = new ProcCtrl(this);

    ui->actionStart->setEnabled(false);
    ui->actionStop->setEnabled(true);

    DialogTelescope dlgtelescope;
    dlgtelescope.exec();
}
