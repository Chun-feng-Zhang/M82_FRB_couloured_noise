//============================================================================
// Name        : dialogsettings.cpp
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#include "dialogsettings.h"
#include "ui_dialogsettings.h"

DialogSettings::DialogSettings(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogSettings)
{
    ui->setupUi(this);
//read initial parameters
    QDir dir;
    QString path=QDir::homePath()+QDir::separator()+tr(".config");
    dir.setPath(path);

    if(!dir.exists())
    {
        dir.mkdir(path);
    }

    path+=QDir::separator()+tr("bear");
    dir.setPath(path);

    if (!dir.exists())
    {
        dir.mkdir(path);
    }

    fname=path+QDir::separator()+ tr("parameters");

    QFile file(fname);

    if (file.exists() && ReadXML());
        //qDebug()<<tr("Read parameters from ")+fname;
    else
    {
        //
        ui->lineEditBlockNumber->setText("8");
        ui->lineEditBlockSize->setText("32");
        ui->comboBoxUnit->setCurrentIndex(2);
        ui->lineEditProcess->setText("1");
        ui->lineEditRfi->setText("zdot");
        ui->lineEditDms->setText("1");
        ui->lineEditDdm->setText("1");
        ui->lineEditDme->setText("2000");
        ui->lineEditDs->setText("10");
        ui->lineEditNbox->setText("5");
        ui->lineEditThre->setText("0.3 0.05 1e-7");
        ui->lineEditMinw->setText("2e-4");
        ui->lineEditSnrloss->setText("0.15");
        ui->lineEditFch1->setText("1800");
        ui->lineEditFoff->setText("-1");
        ui->lineEditNch->setText("512");
        ui->lineEditTsamp->setText("64e-6");
        ui->lineEditNif->setText("1");
        ui->checkBoxDebug->setChecked(false);
        ui->checkBoxInfo->setChecked(false);
        ui->checkBoxCand->setChecked(false);
        ui->checkBoxScube->setChecked(false);
        ui->checkBoxStd->setChecked(false);
        //
        ui->lineEditFileName->setText("frb");
        ui->lineEditSavProNum->setText("1");
        ui->checkBoxRaw->setChecked(false);
        //
        ui->lineEditIP->setText("127.0.0.1");
        ui->lineEditPort->setText("6666");
        ui->lineEditNchans->setText("512");
        ui->lineEditBanduse->setText("512");
        ui->lineEditNifs->setText("1");
        //
        ui->lineEditDm->setText("500");
        ui->lineEditSnr->setText("10");
        ui->lineEditPeriod->setText("1");
        ui->lineEditW->setText("0.005");
        ui->lineEditPh->setText("0.5");
        //
        ui->lineEditSum->setText("0");
        ui->lineEditFl->setText("1400");
        ui->lineEditFh->setText("1700");
        ui->lineEditNpoints->setText("4096");
        //
        ui->lineEditBearPath->setText("");
        ui->lineEditFigPath->setText(QDir::currentPath());
        ui->lineEditDatPath->setText(QDir::currentPath());

        WriteXML();
        //qDebug()<<tr("Set default parameters");
    }
//input constrain


    connect(ui->listWidgetSettings, SIGNAL(currentRowChanged(int)), ui->stackedWidgetSettings, SLOT(setCurrentIndex(int)));
    connect(this, SIGNAL(rejected()), this, SLOT(ondlgrej()));

}

DialogSettings::~DialogSettings()
{
    delete ui;
}

bool DialogSettings::WriteXML()
{
    QFile file(fname);
    if (! file.open(QIODevice::WriteOnly | QIODevice::Truncate))
        return false;

    QTextStream out(&file);
    QDomDocument doc;
    QDomElement element;
    QDomText text;
    QDomAttr attr;
    QDomProcessingInstruction instruction;

    instruction=doc.createProcessingInstruction("xml", "version = \'1.0\' encoding=\'UTF-8\'");
    doc.appendChild(instruction);
//memory settings
    QDomElement elementMemory=doc.createElement("Memory");
    element=doc.createElement("BlockNumber");
    text=doc.createTextNode(ui->lineEditBlockNumber->text());
    element.appendChild(text);
    elementMemory.appendChild(element);
    element=doc.createElement("BlockSize");
    text=doc.createTextNode(ui->lineEditBlockSize->text());
    element.appendChild(text);
    elementMemory.appendChild(element);
    element=doc.createElement("BlockUnit");
    text=doc.createTextNode(QString::number(ui->comboBoxUnit->currentIndex()));
    element.appendChild(text);
    elementMemory.appendChild(element);
//search settings
    QDomElement elementSearch=doc.createElement("Search");
    element=doc.createElement("ProcessNumber");
    text=doc.createTextNode(ui->lineEditProcess->text());
    element.appendChild(text);
    elementSearch.appendChild(element);
    element=doc.createElement("Rfi");
    text=doc.createTextNode(ui->lineEditRfi->text());
    element.appendChild(text);
    elementSearch.appendChild(element);
    element=doc.createElement("Dms");
    text=doc.createTextNode(ui->lineEditDms->text());
    element.appendChild(text);
    elementSearch.appendChild(element);
    element=doc.createElement("Ddm");
    text=doc.createTextNode(ui->lineEditDdm->text());
    element.appendChild(text);
    elementSearch.appendChild(element);
    element=doc.createElement("Dme");
    text=doc.createTextNode(ui->lineEditDme->text());
    element.appendChild(text);
    elementSearch.appendChild(element);
    element=doc.createElement("Ds");
    text=doc.createTextNode(ui->lineEditDs->text());
    element.appendChild(text);
    elementSearch.appendChild(element);
    element=doc.createElement("Nbox");
    text=doc.createTextNode(ui->lineEditNbox->text());
    element.appendChild(text);
    elementSearch.appendChild(element);
    element=doc.createElement("Thre");
    text=doc.createTextNode(ui->lineEditThre->text());
    element.appendChild(text);
    elementSearch.appendChild(element);
    element=doc.createElement("Minw");
    text=doc.createTextNode(ui->lineEditMinw->text());
    element.appendChild(text);
    elementSearch.appendChild(element);
    element=doc.createElement("Snrloss");
    text=doc.createTextNode(ui->lineEditSnrloss->text());
    element.appendChild(text);
    elementSearch.appendChild(element);
    element=doc.createElement("Fch1");
    text=doc.createTextNode(ui->lineEditFch1->text());
    element.appendChild(text);
    elementSearch.appendChild(element);
    element=doc.createElement("Foff");
    text=doc.createTextNode(ui->lineEditFoff->text());
    element.appendChild(text);
    elementSearch.appendChild(element);
    element=doc.createElement("Nch");
    text=doc.createTextNode(ui->lineEditNch->text());
    element.appendChild(text);
    elementSearch.appendChild(element);
    element=doc.createElement("Tsamp");
    text=doc.createTextNode(ui->lineEditTsamp->text());
    element.appendChild(text);
    elementSearch.appendChild(element);
    element=doc.createElement("Nifs");
    text=doc.createTextNode(ui->lineEditNif->text());
    element.appendChild(text);
    elementSearch.appendChild(element);
    element=doc.createElement("bolDebug");
    if (ui->checkBoxDebug->isChecked())
        text=doc.createTextNode("Yes");
    else
        text=doc.createTextNode("No");
    element.appendChild(text);
    elementSearch.appendChild(element);
    element=doc.createElement("bolInfo");
    if (ui->checkBoxInfo->isChecked())
        text=doc.createTextNode("Yes");
    else
        text=doc.createTextNode("No");
    element.appendChild(text);
    elementSearch.appendChild(element);
    element=doc.createElement("bolCand");
    if (ui->checkBoxCand->isChecked())
        text=doc.createTextNode("Yes");
    else
        text=doc.createTextNode("No");
    element.appendChild(text);
    elementSearch.appendChild(element);
    element=doc.createElement("bolScube");
    if (ui->checkBoxScube->isChecked())
        text=doc.createTextNode("Yes");
    else
        text=doc.createTextNode("No");
    element.appendChild(text);
    elementSearch.appendChild(element);

    element=doc.createElement("bolStd");
    if (ui->checkBoxStd->isChecked())
        text=doc.createTextNode("Yes");
    else
        text=doc.createTextNode("No");
    element.appendChild(text);
    elementSearch.appendChild(element);

//save settings
    QDomElement elementSave=doc.createElement("Save");
    element=doc.createElement("FileName");
    text=doc.createTextNode(ui->lineEditFileName->text());
    element.appendChild(text);
    elementSave.appendChild(element);
    element=doc.createElement("SavProNum");
    text=doc.createTextNode(ui->lineEditSavProNum->text());
    element.appendChild(text);
    elementSave.appendChild(element);
    element=doc.createElement("bolRaw");
    if (ui->checkBoxRaw->isChecked())
        text=doc.createTextNode("Yes");
    else
        text=doc.createTextNode("No");
    element.appendChild(text);
    elementSave.appendChild(element);
//socket settings
    QDomElement elementSocket=doc.createElement("Socket");
    element=doc.createElement("IP");
    text=doc.createTextNode(ui->lineEditIP->text());
    element.appendChild(text);
    elementSocket.appendChild(element);
    element=doc.createElement("Port");
    text=doc.createTextNode(ui->lineEditPort->text());
    element.appendChild(text);
    elementSocket.appendChild(element);
    element=doc.createElement("Nchans");
    text=doc.createTextNode(ui->lineEditNchans->text());
    element.appendChild(text);
    elementSocket.appendChild(element);
    element=doc.createElement("Banduse");
    text=doc.createTextNode(ui->lineEditBanduse->text());
    element.appendChild(text);
    elementSocket.appendChild(element);
    element=doc.createElement("Nifs");
    text=doc.createTextNode(ui->lineEditNifs->text());
    element.appendChild(text);
    elementSocket.appendChild(element);
//test settings
    QDomElement elementTest=doc.createElement("Test");
    element=doc.createElement("Dm");
    text=doc.createTextNode(ui->lineEditDm->text());
    element.appendChild(text);
    elementTest.appendChild(element);
    element=doc.createElement("Snr");
    text=doc.createTextNode(ui->lineEditSnr->text());
    element.appendChild(text);
    elementTest.appendChild(element);
    element=doc.createElement("Period");
    text=doc.createTextNode(ui->lineEditPeriod->text());
    element.appendChild(text);
    elementTest.appendChild(element);
    element=doc.createElement("W");
    text=doc.createTextNode(ui->lineEditW->text());
    element.appendChild(text);
    elementTest.appendChild(element);
    element=doc.createElement("Ph");
    text=doc.createTextNode(ui->lineEditPh->text());
    element.appendChild(text);
    elementTest.appendChild(element);
//dumpstat settings
    QDomElement elementDumpStat=doc.createElement("DumpStat");
    element=doc.createElement("Sum");
    text=doc.createTextNode(ui->lineEditSum->text());
    element.appendChild(text);
    elementDumpStat.appendChild(element);
    element=doc.createElement("Fl");
    text=doc.createTextNode(ui->lineEditFl->text());
    element.appendChild(text);
    elementDumpStat.appendChild(element);
    element=doc.createElement("Fh");
    text=doc.createTextNode(ui->lineEditFh->text());
    element.appendChild(text);
    elementDumpStat.appendChild(element);
    element=doc.createElement("Npoints");
    text=doc.createTextNode(ui->lineEditNpoints->text());
    element.appendChild(text);
    elementDumpStat.appendChild(element);
//path settings
    QDomElement elementPath=doc.createElement("Path");
    element=doc.createElement("BearPath");
    text=doc.createTextNode(ui->lineEditBearPath->text());
    element.appendChild(text);
    elementPath.appendChild(element);
    element=doc.createElement("FigPath");
    text=doc.createTextNode(ui->lineEditFigPath->text());
    element.appendChild(text);
    elementPath.appendChild(element);
    element=doc.createElement("DatPath");
    text=doc.createTextNode(ui->lineEditDatPath->text());
    element.appendChild(text);
    elementPath.appendChild(element);
//
    QDomElement root=doc.createElement("Settings");
    root.appendChild(elementMemory);
    root.appendChild(elementSearch);
    root.appendChild(elementSave);
    root.appendChild(elementSocket);
    root.appendChild(elementTest);
    root.appendChild(elementDumpStat);
    root.appendChild(elementPath);
    doc.appendChild(root);

    doc.save(out, 4);
    return true;
}

bool DialogSettings::ReadXML()
{
    QDomDocument doc;
    QFile file(fname);
    QString error="";
    int row=0, column=0;
    if (!file.open(QIODevice::ReadOnly))
        return false;
    if (!doc.setContent(&file, false, &error, &row, &column))
    {
        file.close();
        return false;
    }
    file.close();

    QMap<QString, QString> map;

    QDomElement root= doc.documentElement();
    QDomNode node = root.firstChild();
    while (!node.isNull())
    {
        QDomElement element = node.toElement();
        QDomNode nodeson=element.firstChild();
        while (!nodeson.isNull())
        {
            QDomElement elementson = nodeson.toElement();
            map.insert(elementson.tagName(), elementson.text());
            nodeson=nodeson.nextSibling();
        }
        node=node.nextSibling();
    }
//
    ui->lineEditBlockNumber->setText(map["BlockNumber"]);
    ui->lineEditBlockSize->setText(map["BlockSize"]);
    ui->comboBoxUnit->setCurrentIndex(map["BlockUnit"].toInt());
    ui->lineEditProcess->setText(map["ProcessNumber"]);
    ui->lineEditRfi->setText(map["Rfi"]);
    ui->lineEditDms->setText(map["Dms"]);
    ui->lineEditDdm->setText(map["Ddm"]);
    ui->lineEditDme->setText(map["Dme"]);
    ui->lineEditDs->setText(map["Ds"]);
    ui->lineEditNbox->setText(map["Nbox"]);
    ui->lineEditThre->setText(map["Thre"]);
    ui->lineEditMinw->setText(map["Minw"]);
    ui->lineEditSnrloss->setText(map["Snrloss"]);
    ui->lineEditFch1->setText(map["Fch1"]);
    ui->lineEditFoff->setText(map["Foff"]);
    ui->lineEditNch->setText(map["Nch"]);
    ui->lineEditTsamp->setText(map["Tsamp"]);
    ui->lineEditNif->setText(map["Nifs"]);
    if (map["bolDebug"]==tr("Yes"))
        ui->checkBoxDebug->setChecked(true);
    else
        ui->checkBoxDebug->setChecked(false);
    if (map["bolInfo"]==tr("Yes"))
        ui->checkBoxInfo->setChecked(true);
    else
        ui->checkBoxInfo->setChecked(false);
    if (map["bolCand"]==tr("Yes"))
        ui->checkBoxCand->setChecked(true);
    else
        ui->checkBoxCand->setChecked(false);
    if (map["bolScube"]==tr("Yes"))
        ui->checkBoxScube->setChecked(true);
    else
        ui->checkBoxScube->setChecked(false);

    if (map["bolStd"]==tr("Yes"))
        ui->checkBoxStd->setChecked(true);
    else
        ui->checkBoxStd->setChecked(false);
//
    ui->lineEditFileName->setText(map["FileName"]);
    ui->lineEditSavProNum->setText(map["SavProNum"]);
    if (map["bolRaw"]==tr("Yes"))
        ui->checkBoxRaw->setChecked(true);
    else
        ui->checkBoxRaw->setChecked(false);
//
    ui->lineEditIP->setText(map["IP"]);
    ui->lineEditPort->setText(map["Port"]);
    ui->lineEditNchans->setText(map["Nchans"]);
    ui->lineEditBanduse->setText(map["Banduse"]);
    ui->lineEditNifs->setText(map["Nifs"]);
//
    ui->lineEditDm->setText(map["Dm"]);
    ui->lineEditSnr->setText(map["Snr"]);
    ui->lineEditPeriod->setText(map["Period"]);
    ui->lineEditW->setText(map["W"]);
    ui->lineEditPh->setText(map["Ph"]);
//
    ui->lineEditSum->setText(map["Sum"]);
    ui->lineEditFl->setText(map["Fl"]);
    ui->lineEditFh->setText(map["Fh"]);
    ui->lineEditNpoints->setText(map["Npoints"]);
//
    ui->lineEditBearPath->setText(map["BearPath"]);
    ui->lineEditFigPath->setText(map["FigPath"]);
    ui->lineEditDatPath->setText(map["DatPath"]);

    return true;
}

void DialogSettings::on_buttonBoxSettings_accepted()
{
    if(!WriteXML())
        qDebug()<<tr("WriteXML failed");

    QDir dirdat(ui->lineEditDatPath->text());
    QDir dirfig(ui->lineEditFigPath->text());

    if(!dirdat.exists())
    {
        dirdat.mkdir(ui->lineEditDatPath->text());
    }
    if(!dirfig.exists())
    {
        dirfig.mkdir(ui->lineEditFigPath->text());
    }
}

void DialogSettings::on_buttonBoxSettings_rejected()
{
    if(!ReadXML())
        qDebug()<<tr("ReadXML failed");
}

void DialogSettings::ondlgrej()
{
    if(!ReadXML())
        qDebug()<<tr("ReadXML failed");
}

void DialogSettings::on_toolButtonBearPath_clicked()
{
    QString dirname=QFileDialog::getExistingDirectory(this, tr("Open Directory"), QDir::homePath(), QFileDialog::ShowDirsOnly);
    ui->lineEditBearPath->setText(dirname);
}

void DialogSettings::on_toolButtonFigPath_clicked()
{
    QString dirname=QFileDialog::getExistingDirectory(this, tr("Open Directory"), QDir::homePath(), QFileDialog::ShowDirsOnly);
    ui->lineEditFigPath->setText(dirname);
}

void DialogSettings::on_toolButtonDatPath_clicked()
{
    QString dirname=QFileDialog::getExistingDirectory(this, tr("Open Directory"), QDir::homePath(), QFileDialog::ShowDirsOnly);
    ui->lineEditDatPath->setText(dirname);
}
