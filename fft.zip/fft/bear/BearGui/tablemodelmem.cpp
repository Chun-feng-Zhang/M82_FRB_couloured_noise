//============================================================================
// Name        : tablemodelmem.cpp
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#include "tablemodelmem.h"

TableModelMem::TableModelMem(QObject * parent):QAbstractTableModel(parent)
{
    pMemInfo=NULL;
    rows=0;
    columns=0;

    getMemInfo();

    m_timerId=startTimer(1000);
}

TableModelMem::~TableModelMem()
{
    if (pMemInfo != NULL)
    {
        delete [] pMemInfo;
        pMemInfo=NULL;
    }

    killTimer(m_timerId);
}

void TableModelMem::getMemInfo()
{

    QProcess * ProcShowMemory=new QProcess;

    DialogSettings tmp;
    QString bearpath=tmp.ui->lineEditBearPath->text();
    QString CommandShowMemory=bearpath + tr("/bin/shman.exe -l");
    ProcShowMemory->start(CommandShowMemory);
    ProcShowMemory->waitForStarted();
    ProcShowMemory->waitForFinished();
    QString StrMem=QString::fromLocal8Bit(ProcShowMemory->readAllStandardOutput());

    //qDebug()<<bearpath;
    //qDebug()<<StrMem;

    if (StrMem.isEmpty())
    {
        pMemInfo=NULL;
        rows=0;
        columns=0;
        return;
    }

    QStringList listmem=StrMem.split("\n");

    Header=listmem.at(2).split(" ",QString::SkipEmptyParts);

    //qDebug()<<Header;

    columns=Header.size();
    rows=listmem.size()-6;

    //qDebug()<<rows;

    if (pMemInfo != NULL)
    {
        delete [] pMemInfo;
        pMemInfo=NULL;
    }

    pMemInfo=new QStringList [rows];
    for (long int i=0; i<rows; i++)
    {
        pMemInfo[i]=listmem.at(i+4).split(" ",QString::SkipEmptyParts);
        //qDebug()<<pMemInfo[i];
    }

    delete ProcShowMemory;
}

int TableModelMem::rowCount(const QModelIndex & parent) const
{
    return rows;
}

int TableModelMem::columnCount(const QModelIndex & parent) const
{
    return columns;
}

QVariant TableModelMem::data(const QModelIndex &index, int role) const
{
    if (!index.isValid())
        return QVariant();

    if (role==Qt::DisplayRole)
    {
        if (pMemInfo != NULL)
            return pMemInfo[index.row()].at(index.column());
    }

    return QVariant();
}

QVariant TableModelMem::headerData(int section, Qt::Orientation orientation, int role) const
{
    if (role==Qt::DisplayRole && orientation==Qt::Horizontal)
        return Header.at(section);
    return QAbstractTableModel::headerData(section,orientation,role);
}

void TableModelMem::timerEvent(QTimerEvent * event)
{
    if (event->timerId() == m_timerId)
    {
        getMemInfo();
        updateModel();
    }
}

void TableModelMem::updateModel()
{
    beginResetModel();
    endResetModel();
}
