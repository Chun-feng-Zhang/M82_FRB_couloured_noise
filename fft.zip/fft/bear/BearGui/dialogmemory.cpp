//============================================================================
// Name        : dialogmemory.cpp
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#include "dialogmemory.h"
#include "ui_dialogmemory.h"

DialogMemory::DialogMemory(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogMemory)
{
    ui->setupUi(this);
}

DialogMemory::~DialogMemory()
{
    delete ui;
}

bool DialogMemory::StartProcMemory()
{
    QProcess ProcOpenMemory;

    QString BlockNumber=ui->lineEditBlockNumber->text();
    QString BlockSize=ui->lineEditBlockSize->text();
    int index=ui->comboBoxUnit->currentIndex();

    long int totblksz=0;
    switch(index)
    {
    case 0: totblksz=BlockNumber.toLong()*BlockSize.toLong()/4;break;
    case 1: totblksz=BlockNumber.toLong()*BlockSize.toLong()*1024/4;break;
    case 2: totblksz=BlockNumber.toLong()*BlockSize.toLong()*1024*1024/4;break;
    case 3: totblksz=BlockNumber.toLong()*BlockSize.toLong()*1024*1024*1024/4;break;
    }
    QString TotalBlockSize=QString::number(totblksz);

    DialogSettings tmp;
    QString bearpath=tmp.ui->lineEditBearPath->text();
    QString CommandOpenMemory=bearpath+tr("/bin/shman.exe ");
    CommandOpenMemory+=tr("-c ")+BlockNumber+tr(" ")+TotalBlockSize;
    qDebug()<<CommandOpenMemory;
    ProcOpenMemory.start(CommandOpenMemory);
    if (!ProcOpenMemory.waitForStarted())
    {
        QMessageBox::information(this, "Error", "Error: Can't open shared memory!!!");
        return false;
    }
    if (!ProcOpenMemory.waitForFinished())
    {
        //QMessageBox::information(this, "Error", "Error: Process shman.exe has some problem when running!!!");
        return false;
    }

    return true;
}

void DialogMemory::on_buttonBox_accepted()
{
    StartProcMemory();
}
