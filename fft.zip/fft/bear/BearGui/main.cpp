//============================================================================
// Name        : main.cpp
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#include "mainwindowBear.h"
#include "dialogsettings.h"
#include "dialogmemory.h"
#include "applicationplus.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    //QApplication a(argc, argv);
    applicationplus a(argc, argv);
    MainWindowBear w;
    w.show();

    //DialogSettings w;
    //w.show();
    //DialogMemory w;
    //w.show();
    return a.exec();
}
