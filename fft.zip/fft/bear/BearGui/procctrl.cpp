//============================================================================
// Name        : procctrl.cpp
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#include "procctrl.h"

ProcCtrl::ProcCtrl(QWidget *parent) : QWidget (parent)
{
    dlgset = new DialogSettings(this);

    nprocsch = 1;
    ProcOpenMemory = NULL;
    ProcSearch = NULL;
    ProcSave = NULL;
    ProcUdp = NULL;
    ProcTest = NULL;
    ProcDumpStat = NULL;
}

ProcCtrl::~ProcCtrl()
{
    if (ProcSearch != NULL)
    {
        for (long int i=0; i<nprocsch; i++)
        {
            if (ProcSearch[i].state() != QProcess::NotRunning)
            {
                QObject::disconnect(&ProcSearch[i], SIGNAL(error(QProcess::ProcessError)), 0, 0);
                ProcSearch[i].close();
            }
        }
        delete [] ProcSearch;
        ProcSearch= NULL;
    }
    if (ProcSave != NULL)
    {
            if (ProcSave->state() != QProcess::NotRunning)
            {
                QObject::disconnect(ProcSave, SIGNAL(error(QProcess::ProcessError)), 0, 0);
                ProcSave->close();
            }
        delete ProcSave;
        ProcSave= NULL;
    }
    if (ProcUdp != NULL)
    {
        if (ProcUdp->state() != QProcess::NotRunning)
        {
            QObject::disconnect(ProcUdp, SIGNAL(error(QProcess::ProcessError)), 0, 0);
            ProcUdp->close();
        }
        delete ProcUdp;
        ProcUdp= NULL;
    }

    if (ProcTest != NULL)
    {
        if (ProcTest->state() != QProcess::NotRunning)
        {
            QObject::disconnect(ProcTest, SIGNAL(error(QProcess::ProcessError)), 0, 0);
            ProcTest->close();
        }
        delete ProcTest;
        ProcTest= NULL;
    }

    if (ProcDumpStat != NULL)
    {
        if (ProcDumpStat->state() != QProcess::NotRunning)
        {
            QObject::disconnect(ProcDumpStat, SIGNAL(error(QProcess::ProcessError)), 0, 0);
            ProcDumpStat->close();
        }
        delete ProcDumpStat;
        ProcDumpStat= NULL;
    }

    if (ProcOpenMemory != NULL)
    {
        if (ProcOpenMemory->state() != QProcess::NotRunning)
        {
            QObject::disconnect(ProcOpenMemory, SIGNAL(error(QProcess::ProcessError)), 0, 0);
            ProcOpenMemory->close();
        }
        delete ProcOpenMemory;
        ProcOpenMemory= NULL;

        QString bearpath=dlgset->ui->lineEditBearPath->text();

        QProcess ProcDeleteMem;
        QString CommandDeleteMem=bearpath+tr("/bin/shman.exe -r");
        ProcDeleteMem.start(CommandDeleteMem);

        ProcDeleteMem.waitForStarted();
        ProcDeleteMem.waitForFinished();
    }

    delete dlgset;
}

bool ProcCtrl::StartProcMemory()
{
    ProcOpenMemory=new QProcess;

    QString BlockNumber=dlgset->ui->lineEditBlockNumber->text();
    QString BlockSize=dlgset->ui->lineEditBlockSize->text();
    int index=dlgset->ui->comboBoxUnit->currentIndex();

    long int totblksz=0;
    switch(index)
    {
    case 0: totblksz=BlockNumber.toLong()*BlockSize.toLong()/sizeof(FILTYPE);break;
    case 1: totblksz=BlockNumber.toLong()*BlockSize.toLong()*1024/sizeof(FILTYPE);break;
    case 2: totblksz=BlockNumber.toLong()*BlockSize.toLong()*1024*1024/sizeof(FILTYPE);break;
    case 3: totblksz=BlockNumber.toLong()*BlockSize.toLong()*1024*1024*1024/sizeof(FILTYPE);break;
    }
    QString TotalBlockSize=QString::number(totblksz);

    QString bearpath=dlgset->ui->lineEditBearPath->text();

    QString CommandOpenMemory=bearpath+tr("/bin/shman.exe ");
    CommandOpenMemory+=tr("-c ")+BlockNumber+tr(" ")+TotalBlockSize;

    qDebug()<<CommandOpenMemory;

    QObject::connect(ProcOpenMemory, SIGNAL(error(QProcess::ProcessError)), this, SLOT(onprocerror(QProcess::ProcessError)));

    ProcOpenMemory->start(CommandOpenMemory);

    ProcOpenMemory->waitForStarted();
    ProcOpenMemory->waitForFinished();

    return true;
}

bool ProcCtrl::StartProcSearch()
{
    QString processnumber=dlgset->ui->lineEditProcess->text();
    int numprocsch=processnumber.toInt();
    ProcSearch=new QProcess [numprocsch];

    nprocsch=numprocsch;

    QString rfi=dlgset->ui->lineEditRfi->text();
    QString dms=dlgset->ui->lineEditDms->text();
    QString ddm=dlgset->ui->lineEditDdm->text();
    QString dme=dlgset->ui->lineEditDme->text();
    QString ds=dlgset->ui->lineEditDs->text();
    QString nbox=dlgset->ui->lineEditNbox->text();
    QString thre=dlgset->ui->lineEditThre->text();
    QString snrloss=dlgset->ui->lineEditSnrloss->text();
    QString minw=dlgset->ui->lineEditMinw->text();
    QString fch1=dlgset->ui->lineEditFch1->text();
    QString foff=dlgset->ui->lineEditFoff->text();
    QString nch=dlgset->ui->lineEditNch->text();
    QString tsamp=dlgset->ui->lineEditTsamp->text();
    QString nif=dlgset->ui->lineEditNif->text();

    QString bearpath=dlgset->ui->lineEditBearPath->text();
    QString figpath=dlgset->ui->lineEditFigPath->text();

    QString CommandSearch=bearpath+tr("/bin/dedisp_sub.exe ");

    CommandSearch+=tr("-share");
    CommandSearch+=tr(" -fch1 ")+fch1;
    CommandSearch+=tr(" -foff ")+foff;
    CommandSearch+=tr(" -nch ")+nch;
    CommandSearch+=tr(" -tsamp ")+tsamp;
    CommandSearch+=tr(" -nif ")+nif;
    CommandSearch+=tr(" -rfi ")+rfi;
    CommandSearch+=tr(" -dms ")+dms;
    CommandSearch+=tr(" -ddm ")+ddm;
    CommandSearch+=tr(" -dme ")+dme;
    CommandSearch+=tr(" -ds ")+ds;
    CommandSearch+=tr(" -nbox ")+nbox;
    CommandSearch+=tr(" -thre ")+thre;
    CommandSearch+=tr(" -snrloss ")+snrloss;
    CommandSearch+=tr(" -minw ")+minw;
    if (dlgset->ui->checkBoxDebug->isChecked())
    {
        CommandSearch.append(" -debug");
    }
    if (dlgset->ui->checkBoxCand->isChecked())
    {
        CommandSearch.append(" -cand");
    }
    if (dlgset->ui->checkBoxInfo->isChecked())
    {
        CommandSearch.append(" -info");
    }
    if (dlgset->ui->checkBoxScube->isChecked())
    {
        CommandSearch.append(" -scube");
    }
    if (dlgset->ui->checkBoxStd->isChecked())
    {
        CommandSearch.append(" -std");
    }

    qDebug()<<CommandSearch;

    for (long int i=0; i<numprocsch; i++)
    {
        ProcSearch[i].setWorkingDirectory(figpath);

        QObject::connect(&ProcSearch[i], SIGNAL(error(QProcess::ProcessError)), this, SLOT(onprocerror(QProcess::ProcessError)));

        ProcSearch[i].start(CommandSearch);

        ProcSearch[i].waitForStarted();
    //ProcSearch->waitForFinished();
    }

    return true;
}

bool ProcCtrl::StartProcSave()
{
    ProcSave=new QProcess;

    QString filename=dlgset->ui->lineEditFileName->text();
    QString fch1=dlgset->ui->lineEditFch1->text();
    QString foff=dlgset->ui->lineEditFoff->text();
    QString nch=dlgset->ui->lineEditNch->text();
    QString tsamp=dlgset->ui->lineEditTsamp->text();
    QString nif=dlgset->ui->lineEditNif->text();

    QString bearpath=dlgset->ui->lineEditBearPath->text();
    QString datpath=dlgset->ui->lineEditDatPath->text();

    QString CommandSave=bearpath+tr("/bin/saveshm.exe");

    CommandSave+=tr(" -s ")+filename;
    CommandSave+=tr(" -fch1 ")+fch1;
    CommandSave+=tr(" -foff ")+foff;
    CommandSave+=tr(" -nch ")+nch;
    CommandSave+=tr(" -tsamp ")+tsamp;
    CommandSave+=tr(" -nif ")+nif;
    if (dlgset->ui->checkBoxRaw->isChecked())
    {
        CommandSave.append(" -raw");
    }

    qDebug()<<CommandSave;

    QObject::connect(ProcSave, SIGNAL(error(QProcess::ProcessError)), this, SLOT(onprocerror(QProcess::ProcessError)));

    ProcSave->setWorkingDirectory(datpath);
    ProcSave->start(CommandSave);
    ProcSave->waitForStarted();

    //ProcSave->waitForFinished();

    return true;
}

bool ProcCtrl::StartProcDumpStat()
{
    ProcDumpStat=new QProcess;

    QString fch1=dlgset->ui->lineEditFch1->text();
    QString foff=dlgset->ui->lineEditFoff->text();
    QString nch=dlgset->ui->lineEditNch->text();
    QString tsamp=dlgset->ui->lineEditTsamp->text();
    QString nif=dlgset->ui->lineEditNif->text();

    QString sum=dlgset->ui->lineEditSum->text();
    QString fl=dlgset->ui->lineEditFl->text();
    QString fh=dlgset->ui->lineEditFh->text();

    QString bearpath=dlgset->ui->lineEditBearPath->text();
    QString datpath=dlgset->ui->lineEditDatPath->text();

    QString CommandDumpStat=bearpath+tr("/bin/dumpstat.exe");

    CommandDumpStat+=tr(" -fch1 ")+fch1;
    CommandDumpStat+=tr(" -foff ")+foff;
    CommandDumpStat+=tr(" -nch ")+nch;
    CommandDumpStat+=tr(" -tsamp ")+tsamp;
    CommandDumpStat+=tr(" -nif ")+nif;
    CommandDumpStat+=tr(" -sum ")+sum;
    CommandDumpStat+=tr(" -fl ")+fl;
    CommandDumpStat+=tr(" -fh ")+fh;

    qDebug()<<CommandDumpStat;

    QObject::connect(ProcDumpStat, SIGNAL(error(QProcess::ProcessError)), this, SLOT(onprocerror(QProcess::ProcessError)));

    ProcDumpStat->start(CommandDumpStat);
    ProcDumpStat->waitForStarted();

    //ProcDumpStat->waitForFinished();

    return true;
}


bool ProcCtrl::StartProUdpRecv()
{
    ProcUdp=new QProcess;

    QString ip=dlgset->ui->lineEditIP->text();
    QString port=dlgset->ui->lineEditPort->text();
    QString nchans=dlgset->ui->lineEditNchans->text();
    QString banduse=dlgset->ui->lineEditBanduse->text();
    QString nifs=dlgset->ui->lineEditNifs->text();

    //npacketlen=nchans.toInt()*4+8;

    QString bearpath=dlgset->ui->lineEditBearPath->text();

    QString CommandUdp=bearpath+tr("/bin/udpgrab_format.exe ");
    CommandUdp+=tr("-ip ")+ip;
    CommandUdp+=tr(" -port ")+port;
    CommandUdp+=tr(" -nchans ")+nchans;
    CommandUdp+=tr(" -banduse ")+banduse;
    CommandUdp+=tr(" -nifs ")+nifs;

    qDebug()<<CommandUdp;
    QObject::connect(ProcUdp, SIGNAL(error(QProcess::ProcessError)), this, SLOT(onprocerror(QProcess::ProcessError)));

    ProcUdp->start(CommandUdp);
    ProcUdp->waitForStarted();

    //ProcUdp->waitForFinished();

    return true;
}

bool ProcCtrl::StartProcTest()
{
    ProcTest=new QProcess;

    QString ip=dlgset->ui->lineEditIP->text();
    QString port=dlgset->ui->lineEditPort->text();

    QString fch1=dlgset->ui->lineEditFch1->text();
    QString foff=dlgset->ui->lineEditFoff->text();
    QString nch=dlgset->ui->lineEditNch->text();
    QString tsamp=dlgset->ui->lineEditTsamp->text();
    QString nif=dlgset->ui->lineEditNif->text();

    QString dm=dlgset->ui->lineEditDm->text();
    QString snr=dlgset->ui->lineEditSnr->text();
    QString period=dlgset->ui->lineEditPeriod->text();
    QString w=dlgset->ui->lineEditW->text();
    QString ph=dlgset->ui->lineEditPh->text();


    QString bearpath=dlgset->ui->lineEditBearPath->text();
    QString CommandTest=bearpath+tr("/bin/udp_test.exe");

    CommandTest+=tr(" -ip ")+ip;
    CommandTest+=tr(" -port ")+port;

    CommandTest+=tr(" -fch1 ")+fch1;
    CommandTest+=tr(" -foff ")+foff;
    CommandTest+=tr(" -nch ")+nch;
    CommandTest+=tr(" -tsamp ")+tsamp;
    CommandTest+=tr(" -nif ")+nif;

    CommandTest+=tr(" -snr ")+snr;
    CommandTest+=tr(" -w ")+w;
    CommandTest+=tr(" -period ")+period;
    CommandTest+=tr(" -phase ")+ph;
    CommandTest+=tr(" -dm ")+dm;

    qDebug()<<CommandTest;

    QObject::connect(ProcTest, SIGNAL(error(QProcess::ProcessError)), this, SLOT(onprocerror(QProcess::ProcessError)));

    ProcTest->start(CommandTest);

    ProcTest->waitForStarted();

    return true;
}

void ProcCtrl::onprocerror(QProcess::ProcessError error)
{
    qDebug()<<error<<endl;

    QString errortitle;
    QString errortext;

    QObject * sender = QObject::sender();

    if (sender == ProcOpenMemory)  errortext = tr("Process open memory");
    else if (sender == ProcSave)  errortext = tr("Process save");
    else if (sender == ProcUdp)  errortext = tr("Process udpgrb");
    else if (sender == ProcTest)  errortext = tr("Process test");
    else if (sender == ProcDumpStat)  errortext = tr("Process dumpstat");
    else
    {
        for (long int i=0; i<nprocsch; i++)
        {
            if (sender == &ProcSearch[i])
            {
                errortext = tr("Process search ") + QString::number(i);
            }
        }
    }

    if (error == QProcess::FailedToStart)
    {
        errortitle = tr("FailedToStart");
    }
    else if (error == QProcess::Crashed)
    {
        errortitle = tr("Crashed");
    }
    else if (error == QProcess::Timedout)
    {
        errortitle = tr("Timedout");
    }
    else if (error == QProcess::WriteError)
    {
        errortitle = tr("WriteError");
    }
    else if (error == QProcess::ReadError)
    {
        errortitle = tr("ReadError");
    }
    else if (error == QProcess::UnknownError)
    {
        errortitle = tr("UnknownError");
    }

    qDebug()<<errortitle<<" : "<<errortext<<endl;
    QMessageBox::information(this, errortitle, errortext);

}
