//============================================================================
// Name        : ringbuffer.cpp
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#include "ringbuffer.h"

RingBuffer::RingBuffer(size_t numPoints):
    d_referenceTime( 0.0 )
{
    index = 0;
    npoints = numPoints;
    mjds.resize( npoints );
    mjds.fill( 0.0 );
    powers.resize( npoints );
    powers.fill( 0.0 );
}

void RingBuffer::setReferenceTime( double timeStamp )
{
    d_referenceTime = timeStamp;
}

double RingBuffer::referenceTime() const
{
    return d_referenceTime;
}

void RingBuffer::setSample(double mjd, double power)
{
    size_t i = index%npoints;
    mjds[i] = mjd;
    powers[i] = power;
    index++;
}

size_t RingBuffer::size() const
{
    return npoints;
}

QPointF RingBuffer::sample( size_t i ) const
{
    size_t ii = (i + index % npoints) % npoints;
    const double x = (mjds.data()[ii] - d_referenceTime)*24*3600;
    const double y = powers.data()[ii];

    return QPointF( x, y );
}

QRectF RingBuffer::boundingRect() const
{
    return QRectF( -3600.0, 128.0, 0.0, 0.0 );
}
