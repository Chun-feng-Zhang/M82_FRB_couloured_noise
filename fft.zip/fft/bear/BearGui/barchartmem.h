//============================================================================
// Name        : barchartmem.h
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#ifndef BARCHARTMEM_H
#define BARCHARTMEM_H

#include <QWidget>
#include <QApplication>

#include <qwt_plot.h>
#include <qwt_plot_canvas.h>
#include <qwt_legend.h>
#include <qwt_plot_layout.h>
#include <qwt_plot_renderer.h>

#include "distrochartitem.h"
#include "distroscaledraw.h"

class BarChartMem : public QwtPlot
{
public:
    BarChartMem(QWidget * = NULL);
    void updateHits();

public:
    QVector <double> HintsMem;

private:
    void render( QPainter* painter, const QRectF & targetRect );
    void setOrientation( int );

private:
    DistroChartItem *d_barChartItem;
    QStringList d_distros;
};

#endif // BARCHARTMEM_H
