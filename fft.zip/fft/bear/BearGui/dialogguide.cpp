//============================================================================
// Name        : dialogguide.cpp
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#include "dialogguide.h"
#include "ui_dialogguide.h"

DialogGuide::DialogGuide(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogGuide)
{
    ui->setupUi(this);

    ui->textEditGuide->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    connect(ui->pushButtonClose, SIGNAL(clicked(bool)), this, SLOT(accept()));
}

DialogGuide::~DialogGuide()
{
    delete ui;
}
