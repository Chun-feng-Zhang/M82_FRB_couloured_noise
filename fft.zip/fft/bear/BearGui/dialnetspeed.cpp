//============================================================================
// Name        : dialnetspeed.cpp
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#include "dialnetspeed.h"

DialNetSpeed::DialNetSpeed(QWidget *parent):QwtDial( parent ), d_label( "MB/s" )
{
    QwtRoundScaleDraw *scaleDraw = new QwtRoundScaleDraw();
    scaleDraw->setSpacing( 8 );
    scaleDraw->enableComponent( QwtAbstractScaleDraw::Backbone, false );
    scaleDraw->setTickLength( QwtScaleDiv::MinorTick, 0 );
    scaleDraw->setTickLength( QwtScaleDiv::MediumTick, 4 );
    scaleDraw->setTickLength( QwtScaleDiv::MajorTick, 8 );
    setScaleDraw( scaleDraw );

    setWrapping( false );
    setReadOnly( true );

    setOrigin( 135.0 );
    setScaleArc( 0.0, 270.0 );

    QPalette canvasPalette( QColor(0, 0, 0));
    canvasPalette.setColor( QPalette::Foreground, QColor(0, 0, 0));
    canvasPalette.setColor( QPalette::Background, QColor(255, 255, 255));
    canvasPalette.setColor( QPalette::Text, QColor(255, 255, 255));
    setPalette(canvasPalette);

    QwtDialSimpleNeedle *needle = new QwtDialSimpleNeedle(QwtDialSimpleNeedle::Arrow, true, Qt::red, QColor(Qt::gray).light(130));
    setNeedle( needle );
}

void DialNetSpeed::setLabel( const QString &label )
{
    d_label = label;
    update();
}

QString DialNetSpeed::label() const
{
    return d_label;
}

void DialNetSpeed::drawScaleContents( QPainter *painter,
    const QPointF &center, double radius ) const
{
    QRectF rect( 0.0, 0.0, 2.0 * radius, 2.0 * radius - 10.0 );
    rect.moveCenter( center );

    const QColor color = palette().color( QPalette::Text );
    painter->setPen( color );

    const int flags = Qt::AlignBottom | Qt::AlignHCenter;
    painter->drawText( rect, flags, d_label );
}
