//============================================================================
// Name        : dialogsettings.h
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#ifndef DIALOGSETTINGS_H
#define DIALOGSETTINGS_H

#include <QDialog>
#include <QDebug>
#include <QDir>
#include <QMessageBox>
#include <QTextStream>
#include <QtXml/QDomDocument>
#include <QFileDialog>

namespace Ui {
class DialogSettings;
}

class DialogSettings : public QDialog
{
    Q_OBJECT

public:
    explicit DialogSettings(QWidget *parent = 0);
    ~DialogSettings();
    bool WriteXML();
    bool ReadXML();

private slots:
    void on_buttonBoxSettings_accepted();
    void on_toolButtonBearPath_clicked();
    void on_buttonBoxSettings_rejected();

    void ondlgrej();

    void on_toolButtonFigPath_clicked();

    void on_toolButtonDatPath_clicked();

public:
    Ui::DialogSettings *ui;
    QString fname;
};

#endif // DIALOGSETTINGS_H
