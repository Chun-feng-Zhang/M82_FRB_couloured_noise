//============================================================================
// Name        : distroscaledraw.h
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#ifndef DISTROSCALEDRAW_H
#define DISTROSCALEDRAW_H

#include <QWidget>

#include <qwt_scale_draw.h>

class DistroScaleDraw : public QwtScaleDraw
{
public:
    DistroScaleDraw(Qt::Orientation orientation, const QStringList &labels);
    virtual QwtText label( double value ) const;

private:
    const QStringList d_labels;
};

#endif // DISTROSCALEDRAW_H
