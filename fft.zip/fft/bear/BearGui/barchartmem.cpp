//============================================================================
// Name        : barchartmem.cpp
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#include "barchartmem.h"

BarChartMem::BarChartMem( QWidget *parent ):QwtPlot( parent ),HintsMem(5)
{


    setAutoFillBackground( true );
    //setPalette( QColor( "Linen" ) );
    setPalette( QColor( 25, 46, 65 ) );

    QwtPlotCanvas *canvas = new QwtPlotCanvas();
    canvas->setLineWidth( 2 );
    canvas->setFrameStyle( QFrame::Box | QFrame::Sunken );
    canvas->setBorderRadius( 10 );

    //QPalette canvasPalette( QColor( "Plum" ) );
    //canvasPalette.setColor( QPalette::Foreground, QColor( "Indigo" ) );
    QPalette canvasPalette( QColor(25, 46, 65));
    canvasPalette.setColor( QPalette::Foreground, QColor(255, 255, 255));
    canvas->setPalette( canvasPalette );

    setCanvas( canvas );

    setTitle( "Number of Different Block Status" );
//////////////////////////////////////////////////////////////
    d_barChartItem = new DistroChartItem();

    for (long int i=0; i<5; i++)
        HintsMem[i]=0;
//////////////////////////////////////////////////////////////
    const struct
    {
        const char *distro;
        QColor color;

    } pageHits[] =
    {
        { "Empty", QColor( "DodgerBlue" ) },
        { "Ready", QColor( "SteelBlue" ) },
        { "Save",  QColor( 183, 255, 183 ) },
        { "Write", QColor( 115, 186, 37 ) },
        { "Read",  QColor( "LightSkyBlue" ) },
    };

    for ( uint i = 0; i < sizeof( pageHits ) / sizeof( pageHits[ 0 ] ); i++ )
    {
        d_distros += pageHits[i].distro;
        d_barChartItem->addDistro(pageHits[i].distro, pageHits[i].color );
    }

    d_barChartItem->setSamples(HintsMem);
    d_barChartItem->attach(this);

    insertLegend( new QwtLegend() );

    setOrientation( 0 );
    setAutoReplot( false );

}

void BarChartMem::setOrientation( int o )
{
    const Qt::Orientation orientation =
        ( o == 0 ) ? Qt::Vertical : Qt::Horizontal;

    int axis1 = QwtPlot::xBottom;
    int axis2 = QwtPlot::yLeft;

    if ( orientation == Qt::Horizontal )
        qSwap( axis1, axis2 );

    d_barChartItem->setOrientation( orientation );

    setAxisTitle( axis1, "Block Status" );
    setAxisMaxMajor(axis1, 5);
    setAxisScaleDraw( axis1, new DistroScaleDraw( orientation, d_distros ) );

    setAxisTitle( axis2, "Number" );
    setAxisMaxMinor( axis2, 1 );

    QwtScaleDraw *scaleDraw = new QwtScaleDraw();
    scaleDraw->setTickLength( QwtScaleDiv::MediumTick, 4 );
    setAxisScaleDraw( axis2, scaleDraw );

    plotLayout()->setCanvasMargin( 0 );
    replot();
}

void BarChartMem::render( QPainter* painter, const QRectF & targetRect )
{
    const int r = 20;
    const QRectF plotRect = targetRect.adjusted( 0.5 * r, 0.5 * r, -0.5 * r, -0.5 * r );

    QwtPlotRenderer renderer;

    if ( qApp->styleSheet().isEmpty() )
    {
        renderer.setDiscardFlag( QwtPlotRenderer::DiscardBackground, true );

        painter->save();
        painter->setRenderHint( QPainter::Antialiasing, true );
        //painter->setPen( QPen( Qt::darkGray, 1 ) );
        painter->setPen( QPen( Qt::white, 1 ) );
        //painter->setBrush( QColor( "WhiteSmoke" ) );
        painter->setBrush( QColor(255, 255, 255) );
        painter->drawRoundedRect( targetRect, r, r );
        painter->restore();
    }

    renderer.render( this, painter, plotRect );
}

void BarChartMem::updateHits()
{
    d_barChartItem->setSamples(HintsMem);
    replot();
}
