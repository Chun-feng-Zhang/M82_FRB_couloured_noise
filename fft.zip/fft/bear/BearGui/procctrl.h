//============================================================================
// Name        : procctrl.h
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#ifndef PROCCTRL_H
#define PROCCTRL_H


#include <QObject>
#include <QProcess>
#include <QFileSystemWatcher>
#include <QDebug>
#include <QMessageBox>

#include "dialogsettings.h"
#include "ui_dialogsettings.h"

//typedef char FILTYPE;

#ifdef HAVE_CONFIG_H
/* include Autoconf-generated header */
#include "../config.h"
#endif

#ifdef FILTYPE_CHAR
  typedef char FILTYPE;
#elif FILTYPE_UCHAR
  typedef unsigned char FILTYPE;
#elif FILTYPE_FLOAT
  typedef float FILTYPE;
#endif

class ProcCtrl : public QWidget
{
    Q_OBJECT
public:
    explicit ProcCtrl(QWidget *parent);
    ~ProcCtrl();

public:
    bool StartProcMemory();
    bool StartProcSearch();
    bool StartProcSave();
    bool StartProUdpRecv();
    bool StartProcTest();
    bool StartProcDumpStat();

private slots:
    void onprocerror(QProcess::ProcessError error);

private:

    DialogSettings * dlgset;

public:
    QProcess * ProcOpenMemory;
    QProcess * ProcSearch;
    QProcess * ProcSave;
    QProcess * ProcUdp;
    QProcess * ProcTest;
    QProcess * ProcDumpStat;

    int nprocsch;
};

#endif // PROCCTRL_H
