//============================================================================
// Name        : labelselect.h
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#ifndef LABELSELECT_H
#define LABELSELECT_H

#include <QObject>
#include <QPainter>
#include <QLabel>
#include <QDebug>

class LabelSelect : public QLabel
{
public:
    LabelSelect(QWidget *parent = 0);
    virtual void paintEvent(QPaintEvent *event);
public:
    int x, y, w, h;
};

#endif // LABELSELECT_H
