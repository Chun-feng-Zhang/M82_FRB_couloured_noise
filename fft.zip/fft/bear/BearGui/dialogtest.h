//============================================================================
// Name        : dialogtest.h
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#ifndef DIALOGTEST_H
#define DIALOGTEST_H

#include <QDialog>
#include <QProcess>

#include "procctrl.h"

namespace Ui {
class DialogTest;
}

class DialogTest : public QDialog
{
    Q_OBJECT

public:
    explicit DialogTest(QWidget *parent = 0);
    ~DialogTest();
    void Free(void);

private slots:
    void on_buttonBoxTest_accepted();

public:
    Ui::DialogTest *ui;

public:
    ProcCtrl * proctrl;
};

#endif // DIALOGTEST_H
