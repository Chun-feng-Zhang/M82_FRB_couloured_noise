//============================================================================
// Name        : dialogtelescope.h
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#ifndef DIALOGTELESCOPE_H
#define DIALOGTELESCOPE_H

#include <QDialog>
#include <qwt_plot.h>
#include <QProcess>

#include <qwt_plot_canvas.h>
#include <qwt_plot_grid.h>
#include <qwt_plot_curve.h>

#include "dialogsettings.h"
#include "ui_dialogsettings.h"

#include "procctrl.h"
#include "ringbuffer.h"

namespace Ui {
class DialogTelescope;
}

class DialogTelescope : public QDialog
{
    Q_OBJECT

public:
    explicit DialogTelescope(QWidget *parent = 0);
    ~DialogTelescope();

private:
    Ui::DialogTelescope *ui;

    QwtPlotCurve * power_curve;

private slots:
    void onpowerchg();

    void onaxischg();


public:
    ProcCtrl * proctrl;

};

#endif // DIALOGTELESCOPE_H
