//============================================================================
// Name        : mainwindowBear.h
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#ifndef MAINWINDOWBEAR_H
#define MAINWINDOWBEAR_H

#include <sys/statvfs.h>
#include <sys/types.h>
#include "wcs.h"

#include <QMainWindow>

#include <QObject>
#include <QProcess>
#include <QFileSystemWatcher>
#include <QDebug>
#include <QMessageBox>

#include "tablemodelmem.h"
#include "dialogsettings.h"
#include "ui_dialogsettings.h"
#include "dialogmemory.h"
#include "labelselect.h"
#include "ledindicator.h"
#include "dialogtest.h"
#include "ui_dialogtest.h"
#include "dialogguide.h"
#include "ui_dialogguide.h"
#include "dialogabout.h"
#include "ui_dialogabout.h"
#include "dialogtelescope.h"
#include "ui_dialogtelescope.h"

#include "procctrl.h"

namespace Ui {
class MainWindowBear;
}

class MainWindowBear : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindowBear(QWidget *parent = 0);
    ~MainWindowBear();
    void timerEvent(QTimerEvent * event);

private:
    bool ShowPng(QLabel * label, QString filename);
    bool ShowPng(LabelSelect * label, QString filename);

    void GetPacketInfo();
    bool GetDiskInfo();

    void GetSrcGalCoor();
    void GetPosition();

protected:
    void closeEvent(QCloseEvent *event);

private slots:
    void ondirpngchg();

    void onpacketchg();

    void onmemchg();

    void on_actionGeneral_Settings_triggered();

    void on_actionStart_triggered();

    void on_actionStop_triggered();

    void on_lineEditRA_textChanged(const QString &arg1);

    void on_lineEditDec_textChanged(const QString &arg1);

    void on_actionSend_Test_Udp_Packets_triggered();

    void on_actionGuide_triggered();

    void on_actionAbout_BearGui_triggered();

    void on_actionTelescope_Monitoring_triggered();

private:
    Ui::MainWindowBear *ui;

    TableModelMem * ModelMem;

    DialogSettings * dlgset;

    DialogTest * dlgtest;

    ProcCtrl * proctrl;

    QString StrPacketSend;
    QString StrPacketRecv;
    QString StrPacketLost;
    QString StrPacketRate;

    QString StrRa;
    QString StrDec;

    QString StrGL;
    QString StrGB;

    long unsigned int counts;
    int npacketlen;

    int tmpcounts;

public:
    int m_timerId1;
    int m_timerId2;
    int m_timerDisk;
    int m_timerMem;
    int m_timerFig;
};

#endif // MAINWINDOWBEAR_H
