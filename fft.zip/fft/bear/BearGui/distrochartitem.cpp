//============================================================================
// Name        : distrochartitem.cpp
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#include "distrochartitem.h"

DistroChartItem::DistroChartItem():QwtPlotBarChart( "Page Hits" )
{
    setLegendMode( QwtPlotBarChart::LegendBarTitles );
    setLegendIconSize( QSize( 10, 14 ) );
    setLayoutPolicy( AutoAdjustSamples );
    setLayoutHint( 4.0 ); // minimum width for a single bar

    setSpacing( 10 ); // spacing between bars
}

void DistroChartItem::addDistro( const QString &distro, const QColor &color )
{
    d_colors += color;
    d_distros += distro;
    itemChanged();
}

QwtColumnSymbol * DistroChartItem::specialSymbol(int index, const QPointF& ) const
{
    // we want to have individual colors for each bar

    QwtColumnSymbol *symbol = new QwtColumnSymbol( QwtColumnSymbol::Box );
    symbol->setLineWidth( 2 );
    symbol->setFrameStyle( QwtColumnSymbol::Raised );

    QColor c( Qt::white );
    if ( index >= 0 && index < d_colors.size() )
        c = d_colors[ index ];

    symbol->setPalette( c );

    return symbol;
}
QwtText DistroChartItem::barTitle( int sampleIndex ) const
{
    QwtText title;
    if ( sampleIndex >= 0 && sampleIndex < d_distros.size() )
        title = d_distros[ sampleIndex ];

    return title;
}
