//============================================================================
// Name        : dialnetspeed.h
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#ifndef DIALNETSPEED_H
#define DIALNETSPEED_H

#include <QObject>
#include <QPainter>

#include <qwt_dial.h>
#include <qwt_round_scale_draw.h>
#include <qwt_dial_needle.h>

class DialNetSpeed : public QwtDial
{
public:
    DialNetSpeed(QWidget *parent = NULL);

    void setLabel( const QString & );
    QString label() const;

protected:
    virtual void drawScaleContents( QPainter *painter, const QPointF &center, double radius ) const;

private:
    QString d_label;
};

#endif // DIALNETSPEED_H
