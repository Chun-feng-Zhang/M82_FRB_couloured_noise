//============================================================================
// Name        : applicationplus.h
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#ifndef APPLICATIONPLUS_H
#define APPLICATIONPLUS_H

#include <QObject>
#include <QApplication>
#include <QDebug>
#include <exception>

class applicationplus : public QApplication
{
public:
    applicationplus(int& argc, char** argv);
    bool notify(QObject* receiver, QEvent* event);
};

#endif // APPLICATIONPLUS_H
