//============================================================================
// Name        : dialogtest.cpp
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#include "dialogtest.h"
#include "ui_dialogtest.h"

DialogTest::DialogTest(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogTest)
{
    ui->setupUi(this);

    proctrl=new ProcCtrl(this);

    DialogSettings dlgset;

    ui->lineEditSnr->setText(dlgset.ui->lineEditSnr->text());
    ui->lineEditDm->setText(dlgset.ui->lineEditDm->text());
    ui->lineEditPeriod->setText(dlgset.ui->lineEditPeriod->text());
    ui->lineEditW->setText(dlgset.ui->lineEditW->text());
    ui->lineEditPh->setText(dlgset.ui->lineEditPh->text());

    ui->lineEditIP->setText(dlgset.ui->lineEditIP->text());
    ui->lineEditPort->setText(dlgset.ui->lineEditPort->text());

    ui->lineEditFch1->setText(dlgset.ui->lineEditFch1->text());
    ui->lineEditFoff->setText(dlgset.ui->lineEditFoff->text());
    ui->lineEditTsamp->setText(dlgset.ui->lineEditTsamp->text());
    ui->lineEditNch->setText(dlgset.ui->lineEditNchans->text());
    ui->lineEditNif->setText(dlgset.ui->lineEditNif->text());

}

DialogTest::~DialogTest()
{
    Free();
    delete ui;
}

void DialogTest::Free(void)
{
    delete proctrl;
}

void DialogTest::on_buttonBoxTest_accepted()
{
    if (proctrl->StartProcTest())
        ui->buttonBoxTest->setEnabled(false);
}
