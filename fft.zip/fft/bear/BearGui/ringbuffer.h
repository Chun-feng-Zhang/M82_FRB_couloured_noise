//============================================================================
// Name        : ringbuffer.h
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#ifndef RINGBUFFER_H
#define RINGBUFFER_H

#include <QObject>
#include <qwt_series_data.h>
#include <qvector.h>

class RingBuffer : public QwtSeriesData<QPointF>
{
public:
    RingBuffer(size_t numPoints = 1000);

    void setReferenceTime( double );
    double referenceTime() const;
    void setSample(double mjd, double power);

    virtual size_t size() const;
    virtual QPointF sample( size_t i ) const;
    virtual QRectF boundingRect() const;

private:
    size_t index;
    size_t npoints;
    double d_referenceTime;
    QVector<double> mjds;
    QVector<double> powers;
};

#endif // RINGBUFFER_H
