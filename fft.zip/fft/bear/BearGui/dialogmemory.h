//============================================================================
// Name        : dialogmemory.h
// Author      : Yunpeng Men
// Version     : 0.1
// Copyright   : GPL v3.0
// Description : BEAR GUI in C++, Ansi-style
//============================================================================

#ifndef DIALOGMEMORY_H
#define DIALOGMEMORY_H

#include <QDialog>
#include <QProcess>
#include "dialogsettings.h"
#include "ui_dialogsettings.h"

namespace Ui {
class DialogMemory;
}

class DialogMemory : public QDialog
{
    Q_OBJECT

public:
    explicit DialogMemory(QWidget *parent = 0);
    ~DialogMemory();

private slots:
    void on_buttonBox_accepted();

private:
    bool StartProcMemory();

private:
    Ui::DialogMemory *ui;
};

#endif // DIALOGMEMORY_H
